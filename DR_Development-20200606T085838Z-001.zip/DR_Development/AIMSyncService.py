#!/usr/bin/env python
# coding: utf-8
__version__ = "1.1"

import threading
from threading import Thread
import datetime
import os
import AIMDatabase
import ZipFunction
from configfile import *
import FTPSync
import csv
import XMLReader
import time


IsSyncing = False

####------------- FTP Information------------------------------------------------------------------------------------
ftpHost = ''
ftpUser = ''
ftpPass = ''
ftpHost1 = ''
ftpUser1 = ''
ftpPass1 = ''
ftpRemoteDir = ''
autoSync = True
autoTimeSync = 0
####-----------------------------------------------------------------------------------------------------------------

class ReadXMLData():
   @staticmethod
   def ReadAdminConfigData():
       global ftpHost
       global ftpHost1
       global ftpPass
       global ftpPass1
       global ftpUser
       global ftpUser1
       global ftpRemoteDir
       global autoSync
       global autoTimeSync
       dFiles = []
       try:
           dFiles = os.listdir(configDirName)
           #------- This is for Admin Config Files
           for df in dFiles:
               adminConfig_path = configDirName + "/" + drAdminConfigFileName
               if os.path.isfile(adminConfig_path):
                    cData = XMLReader.ReadAdminConfigFile(adminConfig_path)
                    if (len(cData) > 0):
                        #print cData.get('FTP_Host')
                        #print cData.get('FTP_User')
                        #print cData.get('FTP_Pass')
                        #print cData.get('FTP1_Host')
                        #print cData.get('FTP1_User')
                        #print cData.get('FTP1_Pass')
                        #print cData.get('FTP_DrData')

                        ftpHost = cData.get('FTP_Host')
                        ftpHost1 = cData.get('FTP1_Host')

                        ftpUser = cData.get('FTP_User')
                        ftpUser1 = cData.get('FTP1_User')

                        ftpPass = cData.get('FTP_Pass')
                        ftpPass1 = cData.get('FTP1_Pass')

                        ftpRemoteDir = cData.get('FTP_DrData')
                        if (cData.get('ManualSync') == "1"):
                            autoSync = True
                        else:
                            autoSync = False
                        autoTimeSync = int(cData.get('XTimeSync'))
                    break
       except Exception as e:
           print(e)

   @staticmethod
   def ReadConfigData():
        dFiles = []
        global cData
        global totDataCount
        global totLoopCount
        global aimCSVHeader
        try:
            dFiles = os.listdir(configDirName)
            for df in dFiles:
                cFilePath = configDirName + "/" + drConfigFileName
                if os.path.isfile(cFilePath):
                    cData = XMLReader.ReadConfigFile(cFilePath)
                    if (len(cData) > 0):
                        break
        except Exception as e:
            print(e)

class SyncService():
    @staticmethod
    def SyncData():
        global IsSyncing
        if (IsSyncing == False):
            try:
                IsSyncing = True
                fileName = 'DRout'
                csvFileName = fileName+'.csv'
                zipFileName = fileName+'.zip'
                if os.path.exists(zipFileName):
                    print "DRout file exists"
                    AutoMaticallySync(zipFileName)

                totDataCount = 0
                aimCSVMainHeader =''
                aimCSVHeader = ''

                cursorLocation = AIMDatabase.GetAllLocation()
                for location in cursorLocation:
                    print str(location[0])
                    if os.path.exists(zipFileName):
                        print "DRout file exists"
                        AutoMaticallySync(zipFileName)
                        break
                    else:
                        cursorDrMainHead = AIMDatabase.Select_DrMainHeadByLocation(str(location[0]), location[1], location[2])
                        for drMainHead in cursorDrMainHead:
                            aimCSVMainHeader = str(drMainHead[0]) + "*" + drMainHead[1] + "*" + drMainHead[2] + "*" + drMainHead[3] + "*" + drMainHead[4]

                        if (aimCSVMainHeader.strip() != ''):
                            cursorDrColumnHead = AIMDatabase.Select_DrColumnHeadByLocation(str(location[0]), location[1], location[2])
                            for drColumnHead in cursorDrColumnHead:
                                aimCSVHeader = drColumnHead[0] + ",Active"
                                totDataCount = drColumnHead[1]

                            if (aimCSVHeader.strip() != ''):
                                cursorDRData = AIMDatabase.Select_DRDataByLocation(str(location[0]), location[1], location[2])
                                aimCSVValue = ''
                                for drData in cursorDRData:
                                    aimConcatDataValue = ''
                                    aimFinalValue = ''
                                    for m in range(int(totDataCount)):
                                        aimConcatDataValue = aimConcatDataValue + drData[m+1] + ","

                                    #print aimConcatDataValue
                                    aimFinalValue = drData[0] + "," + aimConcatDataValue +  drData[11] + "," + drData[12] + "," + str(drData[13]) + '\n'
                                    aimCSVValue = aimCSVValue + aimFinalValue

                                if (aimCSVValue.strip() != ''): 
                                    if os.path.exists(zipFileName):
                                        print "DRout file exists"
                                        AutoMaticallySync(zipFileName)
                                        break
                                    else:
                                        if os.path.exists(csvFileName):
                                           os.remove(csvFileName) 
                                        with open(csvFileName, 'wb') as csvfile:
                                            csvwriter = csv.writer(csvfile, delimiter=' ', escapechar='|', quoting=csv.QUOTE_NONE)
                                            csvwriter.writerow(aimCSVMainHeader + "\n" + aimCSVHeader + "\n" + aimCSVValue)
                                            aimCSVValue = ''
                                        time.sleep(0.10)
                                        if os.path.isfile(csvFileName):
                                            if (ZipFunction.ZipFile(csvFileName,  zipFileName)):
                                                UpdateSyncStatus(str(location[0]), location[1], location[2], '1')
                                                AutoMaticallySync(zipFileName)
                                                print "DROut.zip created successfully"
            except Exception as e:
                print(e)
            finally:
                IsSyncing = False

def UpdateSyncStatus(groupId, location, ScheudleCode, flag):
    try:
        currSyncTime = str(time.strftime("%d-%m-%Y %H:%M:%S"))
        AIMDatabase.Update_DRDataSyncStatus(groupId, location, ScheudleCode, flag, currSyncTime)
        AIMDatabase.Update_DrMainHeadSyncStatus(groupId, location, ScheudleCode, flag, currSyncTime)
        AIMDatabase.Update_DrColumnHeadSyncStatus(groupId, location, ScheudleCode, flag, currSyncTime)
    except Exception as e:
        print(e)


def AutoMaticallySync(zipFileName):
    global ftpRemoteDir
    try:
        global ftpHost
        global ftpUser
        global ftpPass
        isErrorFound = False
        isFileFound = False
        ftp = FTPSync.getFTPConnection(ftpHost, ftpUser, ftpPass, ftpRemoteDir)
        try:
            if (FTPSync.CheckFileExist(zipFileName, ftp)):
                isFileFound = True
                isErrorFound = True
            if (isFileFound == False):
                if (FTPSync.uploadFile(zipFileName,'', ftp)):
                    os.remove(zipFileName)
                else:
                    isErrorFound = True
        except Exception as e:
            print(e)
            isErrorFound = True
    except Exception as e:
        print(e)
        isErrorFound = True
    finally:
        if (isErrorFound):
            global ftpHost1
            global ftpUser1
            global ftpPass1
            isErrorFound = False
            ftp1 = FTPSync.getFTPConnection(ftpHost1, ftpUser1, ftpPass1, ftpRemoteDir)
            try:
                if (FTPSync.CheckFileExist(zipFileName, ftp1)):
                    isFileFound = True
                if (isFileFound == False):
                    if (FTPSync.uploadFile(zipFileName,'', ftp1)):
                        os.remove(zipFileName)
                    else:
                        isErrorFound = True
            except Exception as e:
                print(e)
                isErrorFound = True


def PeriodicallySync(sec):
    while 1:
        try:
            time.sleep(sec)
            print datetime.datetime.now()
            SyncService.SyncData()
        except Exception as e:
            print 'get sync Exception: {}'.format(e)
    

if __name__ == '__main__':
    AIMDatabase.CreateAllTable()
    ReadXMLData.ReadAdminConfigData()
    #SyncService.SyncData()
    if (autoSync):
        if (autoTimeSync > 0):
            totalSec = autoTimeSync * 60
            th = threading.Thread(target=PeriodicallySync(totalSec))
            th.setDaemon(1)
            th.start()
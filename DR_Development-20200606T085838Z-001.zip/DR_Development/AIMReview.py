#!/usr/bin/env python
# coding: utf-8
__version__ = "1.9"
__Date__ = "09SEP2018"

from Tkinter import *   ## notice capitalized T in Tkinter
import Tkinter as tk
import pickle
import os
from configfile import *
import threading
from threading import Thread
import time
import sys
import XMLReader
import tkMessageBox
import AIMDatabase
from PIL import ImageTk, Image
import DR_Key_GPIO as gpio

AimReview = tk.Tk()
AimReview.title("Review Data")
AimReview.resizable(0, 0)
w, h = 480, 320
AimReview.geometry("%dx%d+0+0" % (w, h))
AimReview.wm_attributes('-fullscreen', 'true')

#-------- Global Variable Start Here
fontName = "Helvetica"
fontSize = 14
statusFontSize = 18
bottomTextSize = 16

downIdText = StringVar()
headlblText = StringVar()
lblCountText = StringVar()
lblHeadText = StringVar()
lblValueText = StringVar()
ScannerId = '0'
currentId = 0
currentPointer = 1
totRecord = 0
cData = {}
totDataCount = 0
ScheduleCode = ''
DROutUnique_Id = 1 
aimLocation = ''
isAutoPriceFound = False
listItemCount = 0
currentIndex = 0
#-------- Global Variable Ends Here-----------------------------------------------------------------------------------------------

####---------------------- Select Starts ----------------------------------------------------------------------------------------
def select(value):
    global currentId, currentIndex, currentPointer
    try:
        print value        
        if value == "ESC":
            AimReview.destroy()
        elif value == "CLO":            
            AimReview.destroy()
        elif value == "2nd1":            
            Show2ndStatus()
        elif value == "2nd2":            
            ShowDefaultStatus()
        elif (value == "UP"):
             if (currentIndex > 0):
                currentIndex = currentIndex - 1
                listbox.selection_clear(0, END)
                listbox.selection_set(currentIndex)
                listbox.event_generate("<<ListboxSelect>>")
        elif (value == "DOWN"):
            if (currentIndex < listItemCount-1):
                currentIndex = currentIndex + 1
                listbox.selection_clear(0, END)
                listbox.selection_set(currentIndex)
                listbox.event_generate("<<ListboxSelect>>")
        elif (value == "LEFT"):
            if (currentPointer > 0):
                currentId = AIMDatabase.GetPreviousMaxId(str(currentId), str(DROutUnique_Id), aimLocation)
                currentPointer = AIMDatabase.GetMaxCountId(str(currentId), str(DROutUnique_Id), aimLocation)
                ShowBottomInfo()
        elif (value == "RIGHT"):
            if (currentPointer < totRecord):
                currentId = AIMDatabase.GetNextMaxId(str(currentId), str(DROutUnique_Id), aimLocation)
                currentPointer = AIMDatabase.GetMaxCountId(str(currentId), str(DROutUnique_Id), aimLocation)
                ShowBottomInfo()
    except Exception as e:
        print 'get key value Exception: {}'.format(e)
####---------------------- GPIO Ends ----------------------------------------------------------------------------------------

class ReadXMLData():
   @staticmethod
   def ReadConfigData():
        global cData, totDataCount, ScheduleCode, isAutoPriceFound
        try:
            cData = XMLReader.ReadDRConfigData()
            if (len(cData) > 0):
                ScheduleCode = cData.get('ScheduleId')
                print ScheduleCode
                print cData.get('StoreName')
                print cData.get('DownloadCode')
                downIdText.set(cData.get('DownloadCode') + "-" + cData.get('StoreName') + "#" + ScannerId)
                totDataCount = int(cData.get('I_RowCount')) 
                if (cData.get('P_DefaultPrice') == "0"):
                    isAutoPriceFound = True
        except Exception as e:
            print(e)
            AIMDatabase.Insert_DrLog("13." + e.message)

##------------------------- Status bar ---------------------------------------------------------
frameStatus = Frame(AimReview, bd=1, relief=SUNKEN, height=18)
frameStatus.pack(side=BOTTOM, fill='x')

lblSta2nd = Label(frameStatus, font=(fontName, statusFontSize))
lblSta2nd.pack(side=LEFT)
#img = ImageTk.PhotoImage(Image.open(secondIcon))
#lblSta2nd.configure(image=img)
#lblSta2nd.image= img

lblStaDownId = Label(frameStatus, textvariable=downIdText, font=(fontName, statusFontSize))
lblStaDownId.pack(side=LEFT)

lblStaWifi = Label(frameStatus, font=(fontName, statusFontSize))
lblStaWifi.pack(side=RIGHT)
img1 = ImageTk.PhotoImage(Image.open(wgIcon))
lblStaWifi.configure(image=img1)

lblStaFTP = Label(frameStatus, font=(fontName, statusFontSize))
lblStaFTP.pack(side=RIGHT)
img2 = ImageTk.PhotoImage(Image.open(fgIcon))
lblStaFTP.configure(image=img2)

lblStaBlue = Label(frameStatus, font=(fontName, statusFontSize))
lblStaBlue.pack(side=RIGHT)
img3 = ImageTk.PhotoImage(Image.open(bgIcon))
lblStaBlue.configure(image=img3)

lblStaVersion = Label(frameStatus, text=__version__, font=(fontName, statusFontSize))
lblStaVersion.pack(side=RIGHT)

def ShowDefaultStatus():
   lblSta2nd.configure(image='')
   lblSta2nd.image= ''

def Show2ndStatus():
   img = ImageTk.PhotoImage(Image.open(secondIcon))
   lblSta2nd.configure(image=img)
   lblSta2nd.image= img


##------------------------- Status bar ---------------------------------------------------------
def SelectList(evt):
    # Note here that Tkinter passes an event object to onselect()
    w = evt.widget
    index = int(w.curselection()[0])
    value = w.get(index)
    w.see(index)
    #print 'You selected item %d: "%s"' % (index, value)
    aimArray = []
    if (value.strip() !=''):
      aimArray = value.split(':')
    if (len(aimArray) > 0):
        global currentId, DROutUnique_Id, aimLocation, currentPointer
        currentPointer = 1
        aimLocation = aimArray[0]
        DROutUnique_Id = aimArray[1]
        currentId = AIMDatabase.GetDrDataMinId(str(DROutUnique_Id), aimLocation)
        ShowBottomInfo()


lblHeader = Label(AimReview, textvariable=headlblText, font=(fontName, statusFontSize))
lblHeader.pack()
headlblText.set("Review")

frameList = Frame(AimReview, width=5, bd=1)
frameList.pack(side=LEFT, fill=Y)

scrollbar = Scrollbar(frameList)
scrollbar.pack(side=RIGHT, fill=Y)

listbox = Listbox(frameList, width=8, height=4, font=(fontName, statusFontSize))
listbox.bind('<<ListboxSelect>>', SelectList)
listbox.pack(side=LEFT, fill=Y)


# attach listbox to scrollbar
listbox.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=listbox.yview)

##------------------------ Bottom Panel ---------------------------------------------------
frameBottom = Frame(AimReview)
frameBottom.pack(fill='x')

#lblCountText.set("1 of 27")
lblCount = Label(frameBottom, textvariable =lblCountText, font=(fontName, bottomTextSize))
lblCount.pack(side=RIGHT, anchor=NW)

#lblHeadText.set("Area Number:\nPrice:\nQtyanity:")
lblHead = Label(frameBottom, textvariable =lblHeadText, font=(fontName, bottomTextSize), anchor=W, justify=LEFT, padx=5)
lblHead.pack(side=LEFT)

#lblValueText.set("765\n134.23\n45")
lblValue = Label(frameBottom, textvariable =lblValueText, wraplength=240, font=(fontName, bottomTextSize), anchor=W, justify=LEFT, padx=2)
lblValue.pack(side=TOP, anchor=W)

##------------------------ Bottom Panel --------------------------------------------------------

def submitOK():
    global currentId
    if (currentId > 0):
        currentId = AIMDatabase.GetPreviousMaxId(str(currentId), str(DROutUnique_Id), aimLocation)
        ShowBottomInfo()
         
def submitCancel():
    global currentId
    if (currentId < totRecord):
        currentId = AIMDatabase.GetNextMaxId(str(currentId), str(DROutUnique_Id), aimLocation)
        ShowBottomInfo()

#frameButton = Frame(AimReview, pady=5)
#frameButton.pack()

#btnOK = Button(frameButton, text='<', width=12, font=(fontName, fontSize), command = submitOK) 
#btnOK.bind("<Return>", lambda event:submitOK())
#btnOK.pack(side = LEFT)

#btnCancel = Button(frameButton, text ='>', width=12, font=(fontName, fontSize), command = submitCancel) 
#btnCancel.bind("<Return>", lambda event:submitCancel())
#btnCancel.pack(side = RIGHT)

#----------------------------------------------------GPIO-----------------------------------------------------------------------
def ping():
    try:
        while 1:
            time.sleep(0.06)
            AimReview.event_generate('<<Ping>>', when='tail')
    except:
        pass

def gotPing(event):
    gpiovalue = gpio.get_keypad_value()
    try:
        if (gpiovalue.strip() !=''):
            select(gpiovalue)
    except:
        pass

AimReview.bind('<<Ping>>', gotPing)
th = threading.Thread(target=ping)
th.setDaemon(1)
th.start()
#-----------------------------------------------------GPIO---------------------------------------------------------------------
ScannerId = AIMDatabase.GetRegistrerScannerId()
ReadXMLData.ReadConfigData()

def ShowBottomInfo():
    try:
        global totRecord
        lblColHeadText = ''
        lblColValueText = ''
        lblHeadText.set("")
        lblValueText.set("")
        lblCountText.set("")
        totRecord = AIMDatabase.GetTotalRecord(str(DROutUnique_Id), aimLocation)
        if (totRecord > 0):
            cursor = AIMDatabase.Select_DRDataById(str(DROutUnique_Id), aimLocation, str(currentId))
            for row in cursor:
                lblCountText.set(str(currentPointer) + " of " + str(totRecord))
                #lblColHeadText = cData.get('L_Description') + ":\n"
                lblColHeadText = "L" + ":\n"
                lblColValueText = row[0] + "\n"

                for x in range(totDataCount):            
                    if (row[x+1].strip() !=''):
                        #lblColHeadText = lblColHeadText + cData.get('I' + str(x) + '_Description')  + ":\n"
                        lblColHeadText = lblColHeadText + "D" + str(x+1) + ":\n"
                        lblColValueText = lblColValueText + row[x+1] + "\n"
        
                if (isAutoPriceFound == False):
                    #lblColHeadText = lblColHeadText + cData.get('P_Description') + ":\n"
                    lblColHeadText = lblColHeadText + "P" + ":\n"
                    lblColValueText = lblColValueText + row[11] + "\n"
                #lblColHeadText = lblColHeadText + cData.get('Q_Description')
                lblColHeadText = lblColHeadText + "Q" + ":\n"
                lblColValueText = lblColValueText + row[12]

                lblHeadText.set(lblColHeadText)
                lblValueText.set(lblColValueText)
        else:
            lblCountText.set("No Records")
    except Exception as e:
        print 'get key value Exception: {}'.format(e)


# Fill the listbox with all location
cursor = AIMDatabase.GetReviewReportData(ScheduleCode, 'Location, GroupId', 'Location, GroupId', "ScheduleCode='" + ScheduleCode + "'")
for row in cursor:                    
    listbox.insert(END, row[0] + ":" + str(row[1]))
if (listbox.size() > 0):
    listItemCount = listbox.size()
    listbox.selection_set(currentIndex)
    listbox.event_generate("<<ListboxSelect>>")

gpio.SECOND_KEY_VALUE = 1
Show2ndStatus()
AimReview.mainloop()

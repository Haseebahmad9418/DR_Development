import sysv_ipc

queue_key = 111
mq = sysv_ipc.MessageQueue(queue_key)

counter = 0
while True:
    (message, priority) = mq.receive(10)
    print message

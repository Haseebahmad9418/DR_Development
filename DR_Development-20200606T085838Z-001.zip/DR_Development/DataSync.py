import sysv_ipc
# Set queue
queue_key = 115
mq = sysv_ipc.MessageQueue(queue_key, sysv_ipc.IPC_CREAT)
mq.send("Hansat Test")
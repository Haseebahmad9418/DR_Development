#!/usr/bin/env python
# coding: utf-8
__version__ = "2.6"
__Date__ = "27MAR2018"

import logging
import socket
import time
from configfile import *

def WriteToLog(comments):
    if (IsLogging):
        try:
            logData = " " + socket.gethostname() + " : " + str(time.strftime("%d-%m-%Y %H:%M:%S")) + " :  " + __file__ + " :  " + comments
            logging.debug(logData)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

LOG_FILENAME = 'aimdr.log'
logging.basicConfig(filename=LOG_FILENAME,level=logging.DEBUG)
#WriteToLog('First Line Started')

try:
    from Tkinter import *   ## notice capitalized T in Tkinter
    import Tkinter as tk
    import ttk
    import os
    import bluetooth
    from bluetoothctl import *
    from PIL import ImageTk, Image
    import sys
    import threading
    from threading import Thread
    import datetime
    import time
    import XMLReader
    import AIMDatabase
    import FTPSync
    import DR_Key_GPIO as gpio
    from ttk import Separator
except Exception as e:
    exc_type, exc_obj, exc_tb = sys.exc_info()
    logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

AimScaner = tk.Tk()
AimScaner.title("AIM CU Scanner Settings")
AimScaner.resizable(0, 0)
w, h = 480, 320
AimScaner.geometry("%dx%d+0+0" % (w, h))
#AimScaner.iconbitmap(iconPath)
AimScaner.wm_attributes('-fullscreen', 'true')

#-------- Global Variable Start Here
fontName = "Helvetica"
fontSize = 19
statusFontSize = (fontName, 12, 'bold')
doubleStatusFontSize = (fontName, 10, 'bold')
btnFontSize =22

lblLoginText = StringVar()
lblUserText = StringVar()
lblNextText = StringVar()
lblStatus = StringVar()
lblInfoText = StringVar()
enUserText = StringVar(AimScaner, value='')
totMacCount = 0
cData = {}
ftpHost = FtpIp
ftpUser = ''
ftpPass = ''
PrevCloseValue = ''
isProcessDone = False
isProcessing = False
isRegisterButtonShows = False
downIdText = StringVar()
wifiScannerText = StringVar()
ipVerText = StringVar()
timeText = StringVar()
stoNameText = StringVar()

ssid = ''
ipaddress = ''

#-------- Global Variable Ends Here
def GetMacConfigData():
   #WriteToLog('GetMacConfigData Functions Starts')
   global totMacCount
   global cData 
   dFiles = []
   try:
       dFiles = os.listdir(configDirName)
       #------- This is for Admin Config Files
       for df in dFiles:
           adminConfig_path = configDirName + "/" + drMacConfigFileName
           if os.path.isfile(adminConfig_path):
                cData = XMLReader.ReadMacConfigFile(adminConfig_path)
                if (len(cData) > 0):
                    totMacCount = int(cData.get('M_RowCount')) 
                    print "Mac Config Read Done"
                break
   except Exception as e:
       exc_type, exc_obj, exc_tb = sys.exc_info()
       logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
   #finally:
        #WriteToLog('GetMacConfigData Functions Ends')

def GetConfigData():
   #WriteToLog('GetConfigData Functions Starts')
   try:
       global ftpHost, ftpPass, ftpUser
       cData = XMLReader.ReadAdminConfigData()
       if (len(cData) > 0):
           ftpHost = cData.get('FTP_Host')
           ftpUser = cData.get('FTP_User')
           ftpPass = cData.get('FTP_Pass')
           
           print ftpHost 
           print ftpUser 
           print ftpPass 
           
       cData1 = XMLReader.ReadDRConfigData()
       if (len(cData1) > 0):
           print cData1.get('StoreName')
           print cData1.get('DownloadCode')
           downIdText.set(cData1.get('DownloadCode'))
           stoNameText.set(cData1.get('StoreName')) 
   except Exception as e:
       exc_type, exc_obj, exc_tb = sys.exc_info()
       logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
   #finally:
       #WriteToLog('GetConfigData Functions Starts')

def read_data():
   #WriteToLog('read_data Functions Starts')
   try:
        server_sock=bluetooth.BluetoothSocket(bluetooth.L2CAP)
        port = 0x1001
        server_sock.bind(("",port))
        server_sock.listen(1)

        client_sock,address = server_sock.accept()
        print "Accepted connection from ",address

        data = client_sock.recv(1024)
        print "received [%s]" % data

        client_sock.close()
        server_sock.close()
   except Exception as e:
       exc_type, exc_obj, exc_tb = sys.exc_info()
       logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
   #finally:
       #WriteToLog('read_data Functions Ends')

def submitLogin():
    #WriteToLog('submitLogin Functions Starts')
    global cData
    global totMacCount, isProcessing
    isFound = False
    isConnected = False
    try:
        if (totMacCount > 0):
            for x in xrange(totMacCount):
                macVal = cData.get('M' + str(x) + '_Mac_Value')
                if (macVal == enScanId.get().strip()):
                    isFound = True
                    macNo = cData.get('M' + str(x) + '_Mac_No')
                    if (macNo.strip() !=''):
                        UnRegisteredScannerById(macNo.strip())
                        if (pairing_devices(macNo.strip())):
                            #pairing_devices("58:51:00:00:16:C2")
                            #pairing_devices("DC:2C:26:EA:5B:65")
                            isConnected = True
                            AIMDatabase.Insert_DrScannerInfo(macNo, macVal) 
                            break
        else:
            ShowNotSuccessStatus()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    finally:
       if (isConnected):
          ShowSuccessStatus()
          GetConfigData()
          ShowFinalScreen()
       else:
          ShowNotSuccessStatus()
       isProcessing = False
       #WriteToLog('submitLogin Functions Ends')

####---------------------- GPIO Start ----------------------------------------------------------------------------------------
entry = None

def currentEntry(userEntry):
    global entry
    entry = userEntry
    print entry

def CheckingCloseCombination(value):
    global PrevCloseValue
    clKey = "CLO"
    stKey1 = "DOWN"
    stKey2 = "LEFT"
    stKey3 = "RIGHT"
    if (value == clKey):
        PrevCloseValue = value
    elif value == stKey1 and PrevCloseValue == clKey:
        PrevCloseValue = PrevCloseValue + value
    elif value == stKey2 and PrevCloseValue == clKey + stKey1:
        PrevCloseValue = PrevCloseValue + value
    elif value == stKey3 and PrevCloseValue == clKey + stKey1 + stKey2:
        os._exit(1)
    else:
        PrevCloseValue = ''

def select(value):
    global entry, isRegisterButtonShows
    try:
        print value
        CheckingCloseCombination(value)
        if value == "DEL":
           pos= entry.index(INSERT)
           entry.delete(pos-1, pos)
        elif value == "ESC":
           if (isProcessing == False):
               lengthText = len(entry.get())
               #print("lengthText=" + str(lengthText))
               if (lengthText > 0):
                  entry.delete(0, END)
               else:            
                  Show1stScreen()
        elif value == "LEFT":
           pos= entry.index(INSERT)
           entry.icursor(pos-1)
        elif value == "RIGHT":
           pos= entry.index(INSERT)
           entry.icursor(pos+1)
        elif value == "UP":
           entry.icursor(0)
        elif value == "DOWN":
           entry.icursor(len(entry.get()))
        elif value == "F2":
           if (isProcessing == False):              
              if (isRegisterButtonShows):
                 ProcessWork(1)
              else:
                 btnNexts()                
        elif value == "2nd1":
           Show2ndStatus()
        elif value == "2nd2":
           ShowDefaultStatus()
        elif value == "NEX":
           if (isProcessing == False):              
              if (isRegisterButtonShows):
                 ProcessWork(1)
              else:
                 btnNexts()
        elif value == "HID":
           Show2ndScreen()               
        #elif value == "CLO":
           #os._exit(1)
        elif (value == "0" or value == "1" or value == "2" or value == "3"  or value == "4" or value == "5" or 
                value == "6" or value == "7" or value == "8" or value == "9"):
           if (isRegisterButtonShows):
               pos= entry.index(INSERT)
               entry.insert(pos,value)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
####---------------------- GPIO Ends ----------------------------------------------------------------------------------------

def Show1stScreen():
    global isRegisterButtonShows
    isRegisterButtonShows = False
    lblInfoText.set("Register scanner 2nd + 1")
    #frameUser.pack_forget()
    lblUser.pack_forget()
    enScanId.pack_forget()
    #btnLogin.pack_forget()
    frameButton.pack_forget()
    frameButton1.pack()    

def Show2ndScreen():
    global isRegisterButtonShows
    isRegisterButtonShows = True
    lblInfoText.set("")
    #frameUser.pack()
    lblUser.pack(side = LEFT)
    enScanId.pack(side = LEFT)
    #btnLogin.pack()
    lblNextText.set("Cancel")
    frameButton1.pack_forget()
    frameButton.pack()
    gpio.SECOND_KEY_VALUE = 0
    ShowDefaultStatus()
    enScanId.focus()

def ShowFinalScreen():
    global isRegisterButtonShows
    isRegisterButtonShows = False
    lblNextText.set("Next")
    
        
frameLabel = Frame(AimScaner, height=50)
frameLabel.pack()

frameInfo = Frame(AimScaner, pady=5)
frameInfo.pack()
lblInfoText.set("Register scanner 2nd + 1")
lblInfo = Label(frameInfo, textvariable=lblInfoText, font=(fontName, 18))
lblInfo.pack(side = LEFT)

### User Frame
frameUser = Frame(AimScaner, pady=10)
frameUser.pack()

lblUserText.set("Scanner Id:")
lblUser = Label(frameUser, textvariable =lblUserText, font=(fontName, fontSize))
#lblUser.pack(side = LEFT)

enScanId = Entry(frameUser, textvariable=enUserText, width=12, font=(fontName, fontSize))
#enScanId.pack(side = LEFT)
#enScanId.focus()

def btnNexts():
   if (isProcessing == False):
       AimScaner.destroy()
       os.system("python AIMLogin.py")

def btnCancel():
    if (isProcessing == False):
        if (isProcessDone):
            btnNexts()
        else:
            Show1stScreen()

def ProcessWork(types):
   if (isProcessing == False):
       if (enScanId.get().strip() !=''):
           print str(types)
           ShowProcessStatus()
           if (types==1):
              th1 = threading.Thread(target=submitLogin)
           th1.setDaemon(1)
           th1.start()
       else:
           ShowNotSuccessStatus()

frameButton = Frame(AimScaner, pady=10)
#frameButton.pack()

lblLoginText.set("Register")
btnLogin = Button(frameButton, textvariable =lblLoginText, width=12, font=(fontName, btnFontSize), command = lambda: ProcessWork(1)) 
btnLogin.bind("<Return>", lambda event:ProcessWork(1))
btnLogin.pack(side = LEFT)
btnLogin.configure(height=2)

lblNextText.set("Cancel")
btnNext = Button(frameButton, textvariable =lblNextText, font=(fontName, btnFontSize), width=12, command = btnCancel)
btnNext.bind("<Return>", lambda event:btnCancel())
btnNext.pack(side = RIGHT)
btnNext.configure(height=2)

frameButton1 = Frame(AimScaner, pady=2)
frameButton1.pack()
btnNext = Button(frameButton1, text ='Next', font=(fontName, btnFontSize), width=12, command = btnNexts)
btnNext.bind("<Return>", lambda event:btnNexts())
btnNext.pack(side = LEFT)
btnNext.configure(height=2)

## Status bar
frameStatus = Frame(AimScaner, bd=1, relief=SUNKEN, height=18)
frameStatus.pack(side=BOTTOM, fill='x')

lblStaWifiScaner = Label(frameStatus, textvariable=wifiScannerText, font=doubleStatusFontSize)
lblStaWifiScaner.pack(side=LEFT)

sep1 = Separator(frameStatus, orient=VERTICAL)
sep1.pack(side=LEFT, fill="y")

lblStaIpVer = Label(frameStatus, textvariable=ipVerText, font=doubleStatusFontSize)
lblStaIpVer.pack(side=LEFT)

sep2 = Separator(frameStatus, orient=VERTICAL)
sep2.pack(side=LEFT, fill="y")

lblStaDownId = Label(frameStatus, textvariable=downIdText, font=statusFontSize)
lblStaDownId.pack(side=LEFT)

sep3 = Separator(frameStatus, orient=VERTICAL)
sep3.pack(side=LEFT, fill="y")

lblStaTime = Label(frameStatus, textvariable=timeText, font=doubleStatusFontSize)
lblStaTime.pack(side=LEFT)

sep4 = Separator(frameStatus, orient=VERTICAL)
sep4.pack(side=LEFT, fill="y")

lblStaStore = Label(frameStatus, textvariable=stoNameText, font=statusFontSize)
lblStaStore.pack(side=LEFT)

lblStaWifi = Label(frameStatus, font=statusFontSize)
lblStaWifi.pack(side=RIGHT)
img1 = ImageTk.PhotoImage(Image.open(wgIcon))
lblStaWifi.configure(image=img1)

lblStaFTP = Label(frameStatus, font=statusFontSize)
lblStaFTP.pack(side=RIGHT)
img2 = ImageTk.PhotoImage(Image.open(fgIcon))
lblStaFTP.configure(image=img2)

lblStaBlue = Label(frameStatus, font=statusFontSize)
lblStaBlue.pack(side=RIGHT)

lblSta2nd = Label(frameStatus, font=statusFontSize)
lblSta2nd.pack(side=RIGHT)

def ShowDefaultStatus():
   lblSta2nd.configure(image='')
   lblSta2nd.image= ''

def ShowProcessStatus():
   img = ImageTk.PhotoImage(Image.open(byIcon))
   lblStaBlue.configure(image=img)
   lblStaBlue.image= img
   global isProcessing, isProcessDone
   isProcessDone = False
   isProcessing = True
   lblInfoText.set("Trying to Register...")
   
def ShowSuccessStatus():
   img = ImageTk.PhotoImage(Image.open(bgIcon))
   lblStaBlue.configure(image=img)
   lblStaBlue.image= img
   global isProcessing, isProcessDone
   isProcessing = False
   isProcessDone = True
   lblInfoText.set("Registration Done")

def ShowNotSuccessStatus():   
   img = ImageTk.PhotoImage(Image.open(brIcon))
   lblStaBlue.configure(image=img)
   lblStaBlue.image= img
   lblInfoText.set("Registration Failed!")
   global isProcessing, isProcessDone
   isProcessing = False
   isProcessDone = False

def Show2ndStatus():
   img = ImageTk.PhotoImage(Image.open(secondIcon))
   lblSta2nd.configure(image=img)
   lblSta2nd.image= img

def FillStatusInfo():  
    global ssid, ipaddress
    ssid = os.popen("iwconfig wlan0 \
                | grep 'ESSID' \
                | awk '{print $4}' \
                | awk -F\\\" '{print $2}'").read()    
    
    if (ssid.strip() !=""):
        if ("AIM" in ssid):
            ssid = ssid.replace("AIM", "").strip()
        if ("INV" in ssid):
            ssid = ssid.replace("INV", "").strip()
        print ssid
    if (len(ssid) == 1):
        ssid = "000" + ssid
    elif (len(ssid) == 2):
        ssid = "00" + ssid
    elif (len(ssid) == 3):
        ssid = "0" + ssid
    elif (len(ssid) > 4):
        ssid = ssid[:4]

    ipaddress = os.popen("ifconfig wlan0 \
                     | grep 'inet addr' \
                     | awk -F: '{print $2}' \
                     | awk '{print $1}'").read()
    
    if (ipaddress.strip() !=""):
        currIPAddress = ipaddress.split('.')
        if (len(currIPAddress) > 1):
            myIps = currIPAddress[2].strip()[-1:]
            ipaddress = myIps + "." + currIPAddress[3]
        print ipaddress

    scannerid = AIMDatabase.GetRegistrerScannerId()
    if (len(scannerid) == 1):
        scannerid = "000" + scannerid
    elif (len(scannerid) == 2):
        scannerid = "00" + scannerid
    elif (len(scannerid) == 3):
        scannerid = "0" + scannerid

    wifiScannerText.set(ssid + "\n" + scannerid)
    ipVerText.set(ipaddress.strip() + "\n" + __version__)
    UpdateStatusTime()

def UpdateStatusTime():
    now = datetime.datetime.now()
    myHour = str(now.hour)
    if (len(myHour) == 1):
        myHour = "0" + str(myHour)
    myMin = str(now.minute)
    if (len(myMin) == 1):
        myMin = "0" + str(myMin)
    myDay = str(now.day)
    if (len(myDay) == 1):
        myDay = "0" + str(myDay)
    myMonth = str(now.month)
    if (len(myMonth) == 1):
        myMonth = "0" + str(myMonth)
    timeText.set(myHour + myMin + "\n" + myDay + myMonth + str(now.year)[2:])


def UnRegisteredScannerById(macNo):
    #WriteToLog('UnRegisteredScannerById Functions Starts')
    isDeleted = False
    import bluetoothctl
    fnc = bluetoothctl.Bluetoothctl()
    try:
       print "Trying to Remove: " + macNo
       if (fnc.remove(macNo)):
           print "Scannner Deleted: " + macNo
           isDeleted = True
    except Exception as e:
       exc_type, exc_obj, exc_tb = sys.exc_info()
       logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    finally:
       AIMDatabase.Clear_DrScannerInfo()
       #WriteToLog('UnRegisteredScannerById Functions Ends')
       return isDeleted

#----- Check and Create sqlite3 aimdr.db -----------------------------------------------------------
AIMDatabase.CreateAllTable()


#----- Get Admin Configuration
GetMacConfigData()
GetConfigData()
FillStatusInfo()

#-----------------------------------------------------GPIO----------------------------------------------------------------------
enScanId.bind("<FocusIn>", lambda event:currentEntry(enScanId))

def ping():
    try:
        while 1:
            time.sleep(0.06)
            AimScaner.event_generate('<<Ping>>', when='tail')
    except:
        pass

def gotPing(event):
    gpiovalue = gpio.get_keypad_value()
    try:
        if (gpiovalue.strip() !=''):
            #WriteToLog("I2C key read Started for key " + gpiovalue.strip())
            select(gpiovalue)
            #WriteToLog("I2C key read Ended for key " + gpiovalue.strip())
    except:
        pass    

AimScaner.bind('<<Ping>>', gotPing)
th = threading.Thread(target=ping)
th.setDaemon(1)
th.start()
#---------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------Bottom Status-----------------------------------------------------------------------
def CheckWifiStatus():
    global img1, lblStaWifi
    print "Wifi Checking"
    status = False
    try:  
        img1 = ImageTk.PhotoImage(Image.open(wyIcon))
        lblStaWifi.configure(image=img1)
        status = True if os.system("ping -c 1 " + WifiIp) is 0 else False
    except:
        pass
    finally:
        if (status):
            img1 = ImageTk.PhotoImage(Image.open(wgIcon))
            lblStaWifi.configure(image=img1)
        else:
            img1 = ImageTk.PhotoImage(Image.open(wrIcon))
            lblStaWifi.configure(image=img1)
        threading.Timer(WifiCheckInterval, CheckWifiStatus).start()   

def CheckFTPStatus():
    global img2, lblStaFTP
    print "FTP Checking"
    status = False
    try:                 
        img2 = ImageTk.PhotoImage(Image.open(fyIcon))
        lblStaFTP.configure(image=img2)
        countFile = 0
        ftp = FTPSync.getFTPConnection(ftpHost, ftpUser, ftpPass, statusDirName)
        Ftpfiles = []
        Ftpfiles = FTPSync.getListofFile(ftp)
        for f in Ftpfiles:
            countFile= countFile + 1
            try:
                if os.path.isfile(statusDirName + f):
                    os.unlink(statusDirName + f)
                    FTPSync.downloadFile(f, statusDirName, ftp)
            except Exception as e:
                print(e)
        print "countFile=" + str(countFile)
        ftp.quit()
        if (countFile > 0):   
            status = True
        timeFileSource = statusDirName + drTimeConfigFileName
        if os.path.isfile(timeFileSource):
            try:
                file = open(timeFileSource, "r") 
                bsDate = file.read() 
                print "bsDate=" + bsDate
                if (bsDate.strip() !=''):
                    os.system("sudo date -s " + "\"" + bsDate + "\"")
                    UpdateStatusTime()
            except Exception as e:
                print(e)
    except Exception as e:
        print(e)
    finally:
        if (status):
            img2 = ImageTk.PhotoImage(Image.open(fgIcon))
            lblStaFTP.configure(image=img2)
        else:
            img2 = ImageTk.PhotoImage(Image.open(frIcon))
            lblStaFTP.configure(image=img2)
        threading.Timer(FtpCheckInterval, CheckFTPStatus).start()


threading.Timer(WifiCheckInterval, CheckWifiStatus).start()
threading.Timer(FtpCheckInterval, CheckFTPStatus).start()
#------------------------------------------------------Bottom Status---------------------------------------------------------------------

#WriteToLog('Ends The Program Line')
AimScaner.mainloop()
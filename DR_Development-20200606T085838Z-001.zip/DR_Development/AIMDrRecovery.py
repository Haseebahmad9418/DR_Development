#!/usr/bin/env python
# coding: utf-8
__version__ = "1.3"
__Date__ = "24APR2018"

from Tkinter import *   ## notice capitalized T in Tkinter
import Tkinter as tk
import ttk
import os
from ftplib import FTP
import wifi
import threading
from threading import Thread
import time
import sys
from PIL import ImageTk, Image
import filecmp
import shutil
import csv
import sqlite3
import zipfile
import RPi.GPIO as GPIO

AimRecovery = tk.Tk()
AimRecovery.title("AIM DR Recovery")
AimRecovery.resizable(0, 0)
w, h = 480, 320
AimRecovery.geometry("%dx%d+0+0" % (w, h))
#AimRecovery.wm_attributes('-fullscreen', 'true')

configDirName = "config/"
updateDirName = "update/"
updateDirFtpName = "UpdateDRFiles"

# Bootom Bar image file
wgIcon = "WG.png"
wrIcon = "WR.png"
wyIcon = "WY.png"
fgIcon = "FG.png"
frIcon = "FR.png"
fyIcon = "FY.png"
bgIcon = "BG.png"
brIcon = "BR.png"
byIcon = "BY.png"
secondIcon = "2B.png"

drConfigZipFileNameNew = "RangerConfig.zip"
drDbLookupFileName = "DbLookup.zip"

#All Real Config File Name
drConfigFileName = "DRConfig.xml"
drAdminConfigFileName = "AdminConfig.xml"
drMacConfigFileName = "MacConfig.xml"
drBarcodePrefixHeadConfigFileName = "BarcodePrefixHead.xml"
drBarcodePrefixDetailsConfigFileName = "BarcodePrefixDetail.xml"
drDbLookupConfigFileName = "DbLookup.csv"

updateFileNames = "configfile.py~AIMMain.py~AIMDr.py~AIMLogin.py~AIMWifi.py~AimFTP.py~AimScanner.py~AIMDatabase.py~FTPSync.py~ZipFunction.py~XMLReader.py~AIMSyncService.py~AIMSyncPopup.py~AIMManualSync.py~AIMReview.py~DR_Key.py~DR_Key_GPIO.py~AIMSound.py"

#-------- Global Variable Start Here
fontName = "Helvetica"
fontSize = 14
lblWifiHostText = StringVar()
lblHostText = StringVar()
lblPassText = StringVar()
lblPskText = StringVar()
lblPrefiText = StringVar()
lblPostfixText = StringVar()
lblConCheckText = StringVar()
lblOverrideText = StringVar()
lblNextText = StringVar()
lblStatus = StringVar()
downIdText = StringVar()
enHostText = StringVar(AimRecovery, value='0')
enPassText = StringVar(AimRecovery, value='aiminv2015')
#enHostText = StringVar(AimRecovery, value='microbytes')
#enPassText = StringVar(AimRecovery, value='mastermind359')

lblFtpHostText = StringVar()
lblFTPUserText = StringVar()
lblFTPPassText = StringVar()
lblDirText = StringVar()
lblFTPText = StringVar()
lblNextText = StringVar()
lblStatus = StringVar()
downIdText = StringVar()
lblInfoText = StringVar()
#enFtpHostText = StringVar(AimRecovery, value='192.168.0.100')
enFtpHostText = StringVar(AimRecovery, value='172.16.0.5')
enFtpUserText = StringVar(AimRecovery, value='Aiminventory')
enFtpPassText = StringVar(AimRecovery, value='aiminv')
enFtpDirText = StringVar(AimRecovery, value='DRConfig')

isPskShows = False
txtFontSize = 14
statusFontSize = 18
btnFontSize = 25
infoFontSize = 18
pady= 2
lblPrefiText.set("AIM")
lblPostfixText.set("INV")
#lblPrefiText.set("")
#lblPostfixText.set("")

isWifiConnected = False
isProcessing = False
IsWifi = 1
ErrorCount = 1

#---------------------------------------------- Set GPIO mode--------------------------------------------------------------------
# Set GPIO mode
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

MATRIX_FIRST = [['ESC', 'F2', 'F1'],
                [7, 8, 9],
                [4, 5, 6],
                [1, 2, 3],
                [0, '2nd', 'F3']]

# Set MATRIX for KeyPad: second key.
MATRIX_SECOND = [['CLO', '', ''],
                 ['ST', 'UP', 'GT'],
                 ['LEFT', 'TR', 'RIGHT'],
                 ['HID', 'DOWN', 'DEL'],
                 ['NEX', '2nd', '']]


ROW = [5,6,13,19,26]
COL = [16,20,21]

SECOND_KEY_VALUE = 0

for j in range(3):
    GPIO.setup(COL[j], GPIO.OUT)
    GPIO.output(COL[j], 1)

for i in range (5):
    GPIO.setup(ROW[i], GPIO.IN, pull_up_down = GPIO.PUD_UP)

# Get the value of keypad.
def get_first_keypad_value():
    global SECOND_KEY_VALUE
    firstVal = ''
    try:
       for j in range (3):
            GPIO.output(COL[j],0)
            for i in range(5):
                if GPIO.input (ROW[i]) == 0:
                   if MATRIX_FIRST[i][j] == '2nd':
                        SECOND_KEY_VALUE = 1
                        firstVal = '2nd1'
                        pass
                   else:
                        firstVal = str(MATRIX_FIRST[i][j])

                   while (GPIO.input(ROW[i]) == 0):
                        pass

            GPIO.output(COL[j],1)
    except Exception as e:
       print(e)
    finally:
        return firstVal



# Get the value of keypad about second key
def get_second_keypad_value():
    global SECOND_KEY_VALUE
    secondVal = ''
    try:
         for j in range (3):
            GPIO.output(COL[j],0)
            for i in range(5):
                if GPIO.input (ROW[i]) == 0:
                   if MATRIX_SECOND[i][j] == '2nd':
                        SECOND_KEY_VALUE = 0
                        secondVal = '2nd2'
                        pass
                   else:
                        secondVal = str(MATRIX_SECOND[i][j])
                   while (GPIO.input(ROW[i]) == 0):
                        pass
            GPIO.output(COL[j],1)
    except Exception as e:
       print(e)
    finally:
        return secondVal


# Get the value for Keypad.
def get_keypad_value():
    global SECOND_KEY_VALUE
    gpioval = ''
    try:
        if SECOND_KEY_VALUE == 1:
            gpioval = get_second_keypad_value()
            if (gpioval !=''):                
                return gpioval
        else:
            gpioval = get_first_keypad_value()
            if (gpioval !=''):
                return gpioval
        time.sleep(0.05)
    except KeyboardInterrupt:
        GPIO.cleanup()
#---------------------------------------------- Set GPIO mode--------------------------------------------------------------------

#-----Global function Ends Here
entry = None
def currentEntry(userEntry, flag):
    global entry, IsWifi
    entry = userEntry
    print entry._name
    IsWifi = flag

def select(value):
    global entry
    global isHideShows
    try:
        print value
        if value == "DEL":
           pos= entry.index(INSERT)
           entry.delete(pos-1, pos)
        elif value == "ESC":
           entry.delete(0, END)
        elif value == "LEFT":
           pos= entry.index(INSERT)
           entry.icursor(pos-1)
        elif value == "RIGHT":
           pos= entry.index(INSERT)
           entry.icursor(pos+1)
        elif value == "UP":
           entry.icursor(0)
        elif value == "DOWN":
           entry.icursor(len(entry.get()))
        elif value == "F2":
        
           if (isWifiConnected):
             ProcessFTPWork(1)
           else:
             ProcessWifiWork(1)
        elif value == "2nd1":
           Show2ndStatus()
        elif value == "2nd2":
           ShowDefaultStatus()
        #elif value == "CLO":
        #   os._exit(1)
        elif (value == "0" or value == "1" or value == "2" or value == "3"  or value == "4" or value == "5" or 
                value == "6" or value == "7" or value == "8" or value == "9"):
           pos= entry.index(INSERT)
           entry.insert(pos,value)
    except Exception as e:
        print(e)
####---------------------- GPIO Ends ----------------------------------------------------------------------------------------

###------------------------------------------------------ Wifi STARTS-----------------------------------------------------------------------------
frameHost = Frame(AimRecovery, pady=20)
frameHost.pack()

lblWifiHostText.set("Wifi Inforamtion")
lblHost = Label(frameHost, font=(fontName, txtFontSize), textvariable =lblWifiHostText)
lblHost.pack(side = LEFT)

frameSSID = Frame(AimRecovery, pady=pady)
frameSSID.pack()

lblPrefix = Label(frameSSID, font=(fontName, txtFontSize), textvariable =lblPrefiText)
lblPrefix.pack(side = LEFT)

enWifiHost = Entry(frameSSID, textvariable=enHostText, width=15, font=(fontName, fontSize))
enWifiHost.select_range(0, END)
enWifiHost.focus()
enWifiHost.pack(side = LEFT)

lblPostfix = Label(frameSSID, font=(fontName, txtFontSize), textvariable =lblPostfixText)
lblPostfix.pack(side = LEFT)

frameEnPass = Frame(AimRecovery, pady=pady)
frameEnPass.pack()

enWifiPass = Entry(frameEnPass, textvariable=enPassText, show="*", width=15, font=(fontName, fontSize))
enWifiPass.pack()

### Wifi Button Submit Frame Start
frameWifiButton = Frame(AimRecovery, pady=10)
frameWifiButton.pack()

lblConCheckText.set("Connect Wifi")
btnWifi = Button(frameWifiButton, textvariable =lblConCheckText, font=(fontName, btnFontSize), width=20, command = lambda: ProcessWifiWork(1))
btnWifi.bind("<Return>", lambda event:ProcessWifiWork(1))
btnWifi.configure()
btnWifi.pack(side = LEFT)
###------------------------------------------------------ Wifi ENDS-----------------------------------------------------------------------------


###------------------------------------------------------ FTP Start-----------------------------------------------------------------------------
### Information Frame
frameInfo = Frame(AimRecovery, pady=10)
frameInfo.pack()
lblInfoText.set("FTP Information")
lblInfo = Label(frameInfo, textvariable=lblInfoText, font=(fontName, infoFontSize))
lblInfo.pack(side = LEFT)
#frameInfo.pack_forget()

frameFTP = Frame(AimRecovery, pady=pady)
frameFTP.pack()

lblHostText.set("Host:")
lblHost = Label(frameFTP, textvariable =lblHostText, font=(fontName, fontSize))
lblHost.pack(side = LEFT)

enHost = Entry(frameFTP, textvariable=enFtpHostText, width=25, font=(fontName, fontSize))
enHost.pack(side = LEFT)


### User Frame
frameUser = Frame(AimRecovery, pady=pady)
frameUser.pack()

lblFTPUserText.set("User:")
lblUser = Label(frameUser, textvariable =lblFTPUserText, font=(fontName, fontSize))
lblUser.pack(side = LEFT)

enUser = Entry(frameUser, textvariable=enFtpUserText, width=25, font=(fontName, fontSize))
enUser.pack(side = LEFT)


### Password Frame
framePass = Frame(AimRecovery, pady=pady)
framePass.pack()

lblPassText.set("Pass:")
lblPass = Label(framePass, textvariable =lblPassText, font=(fontName, fontSize))
lblPass.pack(side = LEFT)

enPass = Entry(framePass, textvariable=enFtpPassText, show="*", width=25, font=(fontName, fontSize))
enPass.pack(side = LEFT)


### Remote Directory Frame
frameDir = Frame(AimRecovery, pady=pady)
frameDir.pack()

lblDirText.set("R.Dir:")
lblDir = Label(frameDir, textvariable =lblDirText, font=(fontName, fontSize))
lblDir.pack(side = LEFT)

enDir = Entry(frameDir, textvariable=enFtpDirText, width=25, font=(fontName, fontSize))
enDir.pack(side = LEFT)

### Button Connect Frame
frameButton = Frame(AimRecovery, pady=10)
frameButton.pack()

lblFTPText.set("Connect FTP")
btnFTP = Button(frameButton, textvariable =lblFTPText, font=(fontName, btnFontSize), width=20, command = lambda: ProcessFTPWork(1))
btnFTP.bind("<Return>", lambda event:ProcessFTPWork(1))
btnFTP.pack(side = LEFT)
btnFTP.configure()
###------------------------------------------------------ FTP ENDS-----------------------------------------------------------------------------

##------------------------------------------------------ Status bar Start-----------------------------------------------------------------------
frameStatus = Frame(AimRecovery, bd=1, relief=SUNKEN, height=18)
frameStatus.pack(side=BOTTOM, fill='x')

lblSta2nd = Label(frameStatus, font=(fontName, statusFontSize))
lblSta2nd.pack(side=LEFT)

lblStaWifi = Label(frameStatus, font=(fontName, statusFontSize))
lblStaWifi.pack(side=RIGHT)

lblStaFTP = Label(frameStatus, font=(fontName, statusFontSize))
lblStaFTP.pack(side=RIGHT)

lblStaVersion = Label(frameStatus, text=__version__, font=(fontName, statusFontSize))
lblStaVersion.pack(side=RIGHT)
##------------------------------------------------------ Status bar ends-----------------------------------------------------------------------

class CheckVersionNumber():
    @staticmethod
    def CheckVersion(updateDirName, updateScriptName, currentScriptName):
       ###---------Extract all zip files from local directory
       fileAPath = ""
       fileBPath = ""
       curFile = ""
       status = False
       isFound = False
       try:
           dFiles = os.listdir(updateDirName)
           for df in dFiles:
               updateFile_path = updateDirName + "/" + updateScriptName
               if os.path.exists(updateFile_path):
                fileAPath = updateFile_path
                break

           files = [f for f in os.listdir('.') if os.path.isfile(f)]
           for f in files:
            if (f == currentScriptName):
                fileBPath = currentScriptName
                isFound = True
                break
           if (isFound):
               if filecmp.cmp(fileAPath, fileBPath) == False:
                   status = True
           else:
                shutil.copy2(updateDirName+ '/' + currentScriptName, currentScriptName)
       except Exception as e:
            print(e)
       finally:
            return status

    @staticmethod
    def CheckUpdateVersionStatus():
        try:
            #Initialize Section
            arrProg = updateFileNames.split('~')
            if (len(arrProg) > 0):
                for m in range(len(arrProg)):
                    try:
                        status = False
                        status = CheckVersionNumber.CheckVersion(updateDirName, arrProg[m], arrProg[m])
                        print "status=" + str(status)
                        if (status):
                            os.unlink(arrProg[m])
                            shutil.copy2(updateDirName+ '/' + arrProg[m], arrProg[m])
                            print str(arrProg[m]) + " is Updated"
                    except Exception as e:
                        print(e)
        except Exception as e:
            print(e)

class FTPSync():
    @staticmethod
    def getFTPConnection(host, user, password, remoteDir):
        try:
            ftp = FTP(host)     # connect to host, default port
            ftp.login(user=user, passwd = password)
            ftp.cwd("/" + remoteDir + "/")
            return ftp
        except Exception as e:
            print(e)

    @staticmethod
    def downloadFile(remoteFileName, dstSave, ftp):
        isDownloaded = False
        try:
            filename = remoteFileName
            localfile = open(dstSave + filename, 'wb')
            ftp.retrbinary('RETR ' + filename, localfile.write, 1024)
            #ftp.quit()
            localfile.close()
            print "Download Done" + remoteFileName
            isDownloaded = True
        except Exception as e:
            print(e)
            isDownloaded = False
        finally:
            return isDownloaded

    @staticmethod
    def getListofFile(ftp):
        files = []
        try:
            files = ftp.nlst()
        except ftplib.error_perm, resp:
            if str(resp) == "550 No files found":
                print "No files in this directory"
            else:
                raise

        return files

def ShowHideFTPFrame(types):
    if (types == 1):
        frameHost.pack_forget()
        frameSSID.pack_forget()
        frameEnPass.pack_forget()
        frameWifiButton.pack_forget()
        frameInfo.pack()
        frameFTP.pack()
        frameUser.pack()
        framePass.pack()
        frameDir.pack()
        frameButton.pack()
    elif (types == 2):
        frameFTP.pack_forget()
        frameUser.pack_forget()
        framePass.pack_forget()
        frameDir.pack_forget()
        frameButton.pack_forget()
    else:
        frameInfo.pack_forget()
        frameFTP.pack_forget()
        frameUser.pack_forget()
        framePass.pack_forget()
        frameDir.pack_forget()
        frameButton.pack_forget()

def ShowWifiProcessStatus():
   img = ImageTk.PhotoImage(Image.open(wyIcon))
   lblStaWifi.configure(image=img)
   lblStaWifi.image= img
   print "Wifi Working"

def ShowWifiSuccessStatus():
   img = ImageTk.PhotoImage(Image.open(wgIcon))
   lblStaWifi.configure(image=img)
   lblStaWifi.image= img
   print "Wifi Success"

def ShowWifiNotSuccessStatus():   
   img = ImageTk.PhotoImage(Image.open(wrIcon))
   lblStaWifi.configure(image=img)
   lblStaWifi.image= img
   print "Wifi Not Success"

def ShowProcessStatus():
   img = ImageTk.PhotoImage(Image.open(fyIcon))
   lblStaFTP.configure(image=img)
   lblStaFTP.image= img
   print "FTP Working"

def ShowSuccessStatus():
   img = ImageTk.PhotoImage(Image.open(fgIcon))
   lblStaFTP.configure(image=img)
   lblStaFTP.image= img
   print "FTP Success"

def ShowNotSuccessStatus():   
   img = ImageTk.PhotoImage(Image.open(frIcon))
   lblStaFTP.configure(image=img)
   lblStaFTP.image= img
   print "FTP Not Success"

def ShowDefaultStatus():
   lblSta2nd.configure(image='')
   lblSta2nd.image= ''

def Show2ndStatus():
   img = ImageTk.PhotoImage(Image.open(secondIcon))
   lblSta2nd.configure(image=img)
   lblSta2nd.image= img

def ProcessWifiWork(types):
   global isProcessing
   if (isProcessing == False):
       isProcessing = True
       ShowWifiProcessStatus()
       th1 = threading.Thread(target=btnWifiCallBack)
       th1.setDaemon(1)
       th1.start()

def ProcessFTPWork(types):
   global isProcessing
   if ((isWifiConnected) and (isProcessing == False)):    
       isProcessing = True
       ShowProcessStatus()    
       th1 = threading.Thread(target=btnFTPCallBack)
       th1.setDaemon(1)
       th1.start()
   
def btnWifiCallBack():
   global isWifiConnected, isProcessing
   isWifiConnected = False
   try:
       #print "wifi checking"
       if (enHost.get().strip() !=''):
           ssid =  lblPrefiText.get().strip() + enWifiHost.get().strip() + lblPostfixText.get().strip()
           print "PSK=" + enPass.get().strip()
           data = {"ssid": ssid, "psk": enWifiPass.get().strip(), "force": True}
           net = wifi.NetconnectdClient()
           net._get_wifi_list()
           net.command('configure_wifi', data)
           content = net._get_status()
           #print content
           if (len(content) >0):
              if (content.get('wifi')['current_ssid'] == ssid):
                 isWifiConnected = True
   except Exception as e:
       print 'get key value Exception: {}'.format(e)
   finally:
       print "isWifiConnected=" + str(isWifiConnected)
       if (isWifiConnected):
          ShowHideFTPFrame(1)
          ShowWifiSuccessStatus()          
       else:
          ShowWifiNotSuccessStatus()
       isProcessing = False


def UpdateStatus(status):
    lblInfoText.set(status)


def btnFTPCallBack():
   ###---------Delete all files from local directory
   global ErrorCount, isProcessing
   ###---------Download all files from remote directory
   try:
       isErrorFound = False
       #Download Configruation Files
       if (ErrorCount > 1):
        lblInfoText.set("Connecting... " + str(ErrorCount))
       else:
        lblInfoText.set("Connecting...")

       ftp = FTPSync.getFTPConnection(enHost.get().strip(), enUser.get(), enPass.get(), enDir.get().strip())
       if (ftp !=None):
           threading.Timer(1, UpdateStatus('Connected')).start()
           files = []
           files = FTPSync.getListofFile(ftp)
           if (files.count > 0):
            threading.Timer(1, UpdateStatus('Downloading Config Files')).start()
            for f in files:
                try:
                    if os.path.isfile(configDirName + f):
                        os.unlink(configDirName + f)
                    FTPSync.downloadFile(f, configDirName, ftp)
                except Exception as e:
                    print(e)
                    isErrorFound = True
           ftp.quit()

           #Download Update DR Files
           ftp = FTPSync.getFTPConnection(enHost.get().strip(), enUser.get(), enPass.get(), updateDirFtpName)
           if (ftp !=None):
               files = []
               files = FTPSync.getListofFile(ftp)
               if (files.count > 0):
                 threading.Timer(1, UpdateStatus('Downloading Update Files')).start()
                 for f in files:
                    try:
                        if os.path.isfile(updateDirName + f):
                            os.unlink(updateDirName + f)
                        FTPSync.downloadFile(f, updateDirName, ftp)
                    except Exception as e:
                        print(e)
               ftp.quit()

           #Check DR Files if any update found
           threading.Timer(1, UpdateStatus('Verifying Update Files')).start()
           CheckVersionNumber.CheckUpdateVersionStatus()

           #Unzip Confiruation Files
           UnzipConfigFiles()
           ShowSuccessStatus()
           ErrorCount = 1
       else:
        ShowNotSuccessStatus()
        ErrorCount = ErrorCount + 1
        if (ErrorCount < 4):
            ProcessFTPWork(1)
        else:
            ErrorCount = 1
            lblInfoText.set("FTP not working")
            lblFTPText.set("Retry FTP")
   except Exception as e:
       exc_type, exc_obj, exc_tb = sys.exc_info()
       print(str(exc_tb.tb_lineno) + " " + e.message)
       isErrorFound = True
       ShowNotSuccessStatus()
       ErrorCount = ErrorCount + 1
       if (ErrorCount < 4):
            ProcessFTPWork(1)
       else:
            ErrorCount = 1
            lblInfoText.set("FTP not working")     
            lblFTPText.set("Retry FTP")
   finally:  
       isProcessing = False

def UnzipConfigFiles():
       ###---------Extract all zip files from local directory
       dFiles = []
       isDownloaded = False
       try:
           dFiles = os.listdir(configDirName)
           if os.path.isfile(configDirName + drConfigZipFileNameNew): 
              if os.path.isfile(configDirName + drConfigFileName):
                os.unlink(configDirName + drConfigFileName)
              
              if os.path.isfile(configDirName + drAdminConfigFileName):
                os.unlink(configDirName + drAdminConfigFileName)

              if os.path.isfile(configDirName + drMacConfigFileName):
                os.unlink(configDirName + drMacConfigFileName)

              if os.path.isfile(configDirName + drBarcodePrefixHeadConfigFileName):
                os.unlink(configDirName + drBarcodePrefixHeadConfigFileName)

              if os.path.isfile(configDirName + drBarcodePrefixDetailsConfigFileName):
                os.unlink(configDirName + drBarcodePrefixDetailsConfigFileName)
                             
              for df in dFiles:               
               zipConfigfile_path = configDirName + "/" + drConfigZipFileNameNew
               if os.path.isfile(zipConfigfile_path):
                   if (UnZipFile(zipConfigfile_path, configDirName)):
                     isDownloaded = True;

               dblookupConfigfile_path = configDirName + "/" + drDbLookupFileName
               if os.path.isfile(dblookupConfigfile_path):
                   if os.path.isfile(configDirName + drDbLookupConfigFileName): 
                       os.unlink(configDirName + drDbLookupConfigFileName)
                   if (UnZipFile(dblookupConfigfile_path, configDirName)):
                       isDownloaded = True;
       except Exception as e:
           print(e)
           ShowNotSuccessStatus()
       finally:
           if (isDownloaded):
              ReadAndSaveLookUpData()
              lblInfoText.set("Download Successfully")
              ShowHideFTPFrame(2)

def UnZipFile(path_to_zip_file, directory_to_extract_to):
    isZipped = False
    try:
        z = zipfile.ZipFile(path_to_zip_file, "r")
        z.extractall(directory_to_extract_to)
        z.close()
        isZipped = True
    except Exception as e:
       print(e)
    finally:
       return isZipped

              
def ReadAndSaveLookUpData():
    try:
        if os.path.isfile(configDirName + drDbLookupConfigFileName): 
            with open(configDirName + drDbLookupConfigFileName) as csvfile:
                spamreader = csv.reader(csvfile, delimiter=',')
                if (Reset_DrDbLookup()):
                    Insert_DrDbLookup(spamreader)
    except Exception as e:
           print(e)

def GetDbConnection():
    conn = sqlite3.connect('aimdr.db')
    return conn

def Reset_DrDbLookup():
    isDeleted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM DrDbLookup "
        cursor.execute(sql)
        conn.commit()
        isDeleted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isDeleted

def Insert_DrDbLookup(spamreader):
    isInserted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        firstline = True
        for row in spamreader:
            try:
                if firstline:
                    firstline = False
                else:
                    #count = count + 1
                    #print str(count) + ". " + row[0]
                    sql = "INSERT INTO DrDbLookup(FlagTypes, Barcode, Description) VALUES ('" + str(row[0]).strip() + "','" + str(row[1]).strip() + "','" + str(row[2]).replace("'","\"") + "')"
                    cursor.execute(sql)
            except Exception as e:
                print(e)
        isInserted = True
    except Exception as e:
        print(e)
    finally:
        conn.commit()
        conn.close()
        return isInserted

#-----------------------------------------------------GPIO----------------------------------------------------------------------
enWifiHost.bind("<FocusIn>", lambda event:currentEntry(enWifiHost, 1))
enWifiPass.bind("<FocusIn>", lambda event:currentEntry(enWifiPass, 1))
enHost.bind("<FocusIn>", lambda event:currentEntry(enHost, 0))
enUser.bind("<FocusIn>", lambda event:currentEntry(enUser, 0))
enPass.bind("<FocusIn>", lambda event:currentEntry(enPass, 0))
enDir.bind("<FocusIn>", lambda event:currentEntry(enDir, 0))

def ping():
    try:
        while 1:
            time.sleep(0.06)
            AimRecovery.event_generate('<<Ping>>', when='tail')
    except:
        pass

def gotPing(event):
    gpiovalue = get_keypad_value()
    try:
        if (gpiovalue.strip() !=''):
            select(gpiovalue)
    except:
        pass
        

AimRecovery.bind('<<Ping>>', gotPing)
th = threading.Thread(target=ping)
th.setDaemon(1)
th.start()
##---------------------------------------------------------------------------------------------------------------------------

ShowHideFTPFrame(3)
AimRecovery.mainloop()
#!/usr/bin/env python
# coding: utf-8
__version__ = "1.5"
__Date__ = "24APR2018"

from Tkinter import *   ## notice capitalized T in Tkinter
import Tkinter as tk
from PIL import ImageTk, Image
from ttk import Separator
import os
from configfile import *
import sys
import datetime
import AIMDatabase
import XMLReader
import threading
from threading import Thread
from bluetoothctl import *
import FTPSync

AimStatusBar = tk.Toplevel()

#-------- Global Variable Start Here
fontName = "Helvetica"
fontSize = 16
statusFontSize = 14
doubleStatusFontSize="10 bold"
doubleStatusFontSize = (fontName, 10, 'bold')

lblUserText = StringVar()
lblPassText = StringVar()
lblLoginText = StringVar()
lblStatus = StringVar()
downIdText = StringVar()
wifiScannerText = StringVar()
ipVerText = StringVar()
timeText = StringVar()
stoNameText = StringVar()

ssid = ''
ipaddress = ''

ftpHost = FtpIp
ftpUser = ''
ftpPass = ''
lblStaWifi = None
lblStaFTP = None
lblStaBlue = None
lblSta2nd = None

def GetConfigData():
   global ftpHost, ftpPass, ftpUser
   try:
      cData = XMLReader.ReadAdminConfigData()
      if (len(cData) > 0):
           ftpHost = cData.get('FTP_Host')
           ftpUser = cData.get('FTP_User')
           ftpPass = cData.get('FTP_Pass')
           print ftpHost 
           print ftpUser 
           print ftpPass 
      cData1 = XMLReader.ReadDRConfigData()
      if (len(cData1) > 0):
           downIdText.set(cData1.get('DownloadCode'))
           stoNameText.set(cData1.get('StoreName'))
   except Exception as e:
       print(e)

frameStatus = Frame(AimStatusBar, bd=1, relief=SUNKEN, height=18)
frameStatus.pack(side=BOTTOM, fill='x')

lblStaWifiScaner = Label(frameStatus, textvariable=wifiScannerText, font=doubleStatusFontSize)
lblStaWifiScaner.pack(side=LEFT)

sep1 = Separator(frameStatus, orient=VERTICAL)
sep1.pack(side=LEFT, fill="y")

lblStaIpVer = Label(frameStatus, textvariable=ipVerText, font=doubleStatusFontSize)
lblStaIpVer.pack(side=LEFT)

sep2 = Separator(frameStatus, orient=VERTICAL)
sep2.pack(side=LEFT, fill="y")

lblStaDownId = Label(frameStatus, textvariable=downIdText, font=(fontName, statusFontSize))
lblStaDownId.pack(side=LEFT)

sep3 = Separator(frameStatus, orient=VERTICAL)
sep3.pack(side=LEFT, fill="y")

lblStaTime = Label(frameStatus, textvariable=timeText, font=doubleStatusFontSize)
lblStaTime.pack(side=LEFT)

sep4 = Separator(frameStatus, orient=VERTICAL)
sep4.pack(side=LEFT, fill="y")

lblStaStore = Label(frameStatus, textvariable=stoNameText, font=(fontName, statusFontSize))
lblStaStore.pack(side=LEFT)

lblStaWifi = Label(frameStatus, font=(fontName, statusFontSize))
lblStaWifi.pack(side=RIGHT)
img1 = ImageTk.PhotoImage(Image.open(wgIcon))
lblStaWifi.configure(image=img1)

lblStaFTP = Label(frameStatus, font=(fontName, statusFontSize))
lblStaFTP.pack(side=RIGHT)
img2 = ImageTk.PhotoImage(Image.open(fgIcon))
lblStaFTP.configure(image=img2)

lblStaBlue = Label(frameStatus, font=(fontName, statusFontSize))
lblStaBlue.pack(side=RIGHT)
img3 = ImageTk.PhotoImage(Image.open(bgIcon))
lblStaBlue.configure(image=img3)

lblSta2nd = Label(frameStatus, font=(fontName, statusFontSize))
lblSta2nd.pack(side=RIGHT)


def ShowDefaultStatus():
   lblSta2nd.configure(image='')
   lblSta2nd.image= ''

def ShowProcessStatus():
   img = ImageTk.PhotoImage(Image.open(fyIcon))
   lblStaFTP.configure(image=img)
   lblStaFTP.image= img

def ShowSuccessStatus():
   img = ImageTk.PhotoImage(Image.open(fgIcon))
   lblStaFTP.configure(image=img)
   lblStaFTP.image= img

def ShowNotSuccessStatus():   
   img = ImageTk.PhotoImage(Image.open(frIcon))
   lblStaFTP.configure(image=img)
   lblStaFTP.image= img

def Show2ndStatus():
   img = ImageTk.PhotoImage(Image.open(secondIcon))
   lblSta2nd.configure(image=img)
   lblSta2nd.image= img

def FillStatusInfo():  
    global ssid, ipaddress
    ssid = os.popen("iwconfig wlan0 \
                | grep 'ESSID' \
                | awk '{print $4}' \
                | awk -F\\\" '{print $2}'").read()    
    
    if (ssid.strip() !=""):
        if ("AIM" in ssid and "INV" in ssid):
            ssid = ssid.strip()[3:]
            ssid = ssid.strip()[:2]
            print ssid
    ipaddress = os.popen("ifconfig wlan0 \
                     | grep 'inet addr' \
                     | awk -F: '{print $2}' \
                     | awk '{print $1}'").read()
    
    if (ipaddress.strip() !=""):
        currIPAddress = ipaddress.split('.')
        if (len(currIPAddress) == 4):
            ipaddress = currIPAddress[2] + "." + currIPAddress[3]
        print ipaddress

    wifiScannerText.set(ssid.strip() + "\n" + AIMDatabase.GetRegistrerScannerId())
    ipVerText.set(ipaddress.strip() + "\n" + __version__)
    now = datetime.datetime.now()
    timeText.set(str(now.hour) + ":" + str(now.minute) + "\n" + str(now.day) + "/" + str(now.month) + "/" + str(now.year))

#----------------------------------------------------Bottom Status-----------------------------------------------------------------------
def CheckWifiStatus():
    global img1, lblStaWifi
    print "Wifi Checking"
    status = False
    try:  
        img1 = ImageTk.PhotoImage(Image.open(wyIcon))
        lblStaWifi.configure(image=img1)
        status = True if os.system("ping -c 1 " + WifiIp) is 0 else False
    except:
        pass
    finally:
        if (status):
            img1 = ImageTk.PhotoImage(Image.open(wgIcon))
            lblStaWifi.configure(image=img1)
        else:
            img1 = ImageTk.PhotoImage(Image.open(wrIcon))
            lblStaWifi.configure(image=img1)
        threading.Timer(WifiCheckInterval, CheckWifiStatus).start()   

def CheckFTPStatus():
    global img2, lblStaFTP
    print "FTP Checking"
    status = False
    try:                 
        img2 = ImageTk.PhotoImage(Image.open(fyIcon))
        lblStaFTP.configure(image=img2)
        countFile = 0
        ftp = FTPSync.getFTPConnection(ftpHost, ftpUser, ftpPass, statusDirName)
        Ftpfiles = []
        Ftpfiles = FTPSync.getListofFile(ftp)
        for f in Ftpfiles:
            countFile= countFile + 1
            try:
                if os.path.isfile(statusDirName + f):
                    os.unlink(statusDirName + f)
                    FTPSync.downloadFile(f, statusDirName, ftp)
            except Exception as e:
                print(e)
        print "countFile=" + str(countFile)
        ftp.quit()
        if (countFile > 0):   
            status = True
        timeFileSource = statusDirName + drTimeConfigFileName
        if os.path.isfile(timeFileSource):
            try:
                file = open(timeFileSource, "r") 
                bsDate = file.read() 
                print "bsDate=" + bsDate
                if (bsDate.strip() !=''):
                    os.system("sudo date -s " + "\"" + bsDate + "\"")
            except Exception as e:
                print(e)
    except:
        pass
    finally:
        if (status):
            img2 = ImageTk.PhotoImage(Image.open(fgIcon))
            lblStaFTP.configure(image=img2)
        else:
            img2 = ImageTk.PhotoImage(Image.open(frIcon))
            lblStaFTP.configure(image=img2)
        threading.Timer(FtpCheckInterval, CheckFTPStatus).start()

def CheckBluetoothStatus():
    global img3, lblStaBlue 
    print "Bluetooth Checking"
    status = False
    try:
        img3 = ImageTk.PhotoImage(Image.open(byIcon))
        lblStaBlue.configure(image=img3)
        bl = Bluetoothctl()
        status =  bl.is_connected()
    except:
        pass
    finally:
        if (status):
            img3 = ImageTk.PhotoImage(Image.open(bgIcon))
            lblStaBlue.configure(image=img3)
        else:
            img3 = ImageTk.PhotoImage(Image.open(brIcon))
            lblStaBlue.configure(image=img3)
        threading.Timer(BluetoothCheckInterval, CheckBluetoothStatus).start()

threading.Timer(WifiCheckInterval, CheckWifiStatus).start()
threading.Timer(FtpCheckInterval, CheckFTPStatus).start()
threading.Timer(BluetoothCheckInterval, CheckBluetoothStatus).start()
#------------------------------------------------------Bottom Status---------------------------------------------------------------------


GetConfigData()
FillStatusInfo()
AimStatusBar.mainloop()
#!/usr/bin/env python
# coding: utf-8
__version__ = "2.0"
__Date__ = "02APR2019"

import logging
import socket
import time
from configfile import *

def WriteToLog(comments):
    if (IsLogging):
        try:
            logData = " " + socket.gethostname() + " : " + str(time.strftime("%d-%m-%Y %H:%M:%S")) + " :  " + __file__ + " :  " + comments
            logging.debug(logData)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

LOG_FILENAME = 'aimdr.log'
logging.basicConfig(filename=LOG_FILENAME,level=logging.DEBUG)
#WriteToLog('First Line Started')

try:
    from Tkinter import *   ## notice capitalized T in Tkinter
    import Tkinter as tk
    import os
    import threading
    from threading import Thread
    import time
    import tkMessageBox
    import sys
    import AIMDatabase    
    import DR_Key_GPIO as gpio
    from AIMSound import *
except Exception as e:
    exc_type, exc_obj, exc_tb = sys.exc_info()
    logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

AimInitialize = tk.Tk()
AimInitialize.title("AIM Initialize")
AimInitialize.resizable(0, 0)
w, h = 480, 320
AimInitialize.geometry("%dx%d+0+0" % (w, h))
#AimInitialize.iconbitmap(iconPath)
AimInitialize.wm_attributes('-fullscreen', 'true')

#-------- Global Variable Start Here
fontName = "Helvetica"
fontSize = 30
btnWidth = 15
btnFontSize = 18

lblTimerText = StringVar()
lblUserText = StringVar()
lblFTPText = StringVar()
lblNextText = StringVar()
lblResetText = StringVar()
sec = 1
keyString = ''
isMatch = False
isSoundPlay = False
buzzer = Buzzer()

####---------------------- GPIO Start ----------------------------------------------------------------------------------------
def select(value):
    try:
        global keyString, isMatch
        print value
        if value == "DEL":
           if (keyString.strip() !=''):
              keyString = keyString[:-1]
              lblUserText.set(keyString)
        elif value == "ESC":
           if (isMatch):
               NoWork()
           else:
               keyString = ''
               lblUserText.set(keyString)
        elif value == "LEFT":
           print value
        elif value == "RIGHT":
           print value
        elif value == "UP":
           print value
        elif value == "DOWN":
           print value
        elif value == "F2":
          if (isMatch):
              NoWork()
          else:
              if (keyString == initializeResetKey):
                   isMatch = True
                   #result = tkMessageBox.askquestion("Delete", " Are you sure you want to erase all data?", icon='warning')
                   #if result == 'yes':
                   #     print "DB Initialize DONE"
                   #     AIMDatabase.ResetDRTables()
                   #AimInitialize.destroy()
                   #os.system("python AIMWifi.py")
                   #frameButton.pack()
                   NoWork()
        elif value == "2nd1":
           print value
        elif value == "2nd2":
           print value
        elif value == "NEX":
           if (isMatch):
              YesWork()
        elif value == "HID":
           print value
        #elif value == "CLO":
        #   os._exit(1)
        elif (value == "0" or value == "1" or value == "2" or value == "3"  or value == "4" or value == "5" or 
                value == "6" or value == "7" or value == "8" or value == "9"):
            keyString = keyString + value
            lblUserText.set(keyString)            
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
####---------------------- GPIO Ends ----------------------------------------------------------------------------------------
frameLabel = Frame(AimInitialize, height=40)
frameLabel.pack()

frame1 = Frame(AimInitialize, pady=5)
frame1.pack()

lblTimerText.set(str(sec))
lblTimer = Label(frame1, textvariable =lblTimerText, font=(fontName, fontSize))
lblTimer.pack(side = LEFT)

frame2 = Frame(AimInitialize, pady=10)
frame2.pack()

lblUserText.set('')
lblUser = Label(frame2, textvariable =lblUserText, font=(fontName, fontSize))
lblUser.pack(side = LEFT)

def YesWork(): 
    print "Trying to erase"
    if (AIMDatabase.ResetDRTables()):
        print "Erase Done"
        NoWork()
    else:
        lblTimerText.set("Their is an error to reset database")

def NoWork():
    #AimInitialize.destroy()
    AimInitialize.after(1000, lambda: AimInitialize.destroy())
    os.system("python AIMWifi.py")

### Button Connect Frame
frameButton = Frame(AimInitialize, pady=2)
frameButton.pack()

lblResetText.set("Are you sure you want to erase all data?")
lblReset = Label(frameButton, textvariable =lblResetText, font=(fontName, 14))
lblReset.pack()

lblFTPText.set("Yes")
btnFTP = Button(frameButton, textvariable =lblFTPText, font=(fontName, btnFontSize), width=btnWidth, command = YesWork)
btnFTP.bind("<Return>", lambda event:YesWork())
btnFTP.pack(side = LEFT)
btnFTP.configure(height=2)

lblNextText.set("No")
btnNext = Button(frameButton, textvariable =lblNextText, font=(fontName, btnFontSize), width=btnWidth, command = NoWork)
btnNext.bind("<Return>", lambda event:NoWork())
btnNext.pack(side = RIGHT)
btnNext.configure(height=2)

frameButton.pack_forget()

#----------------------------------------------------GPIO-----------------------------------------------------------------------
def ping():
    try:
        while 1:
            time.sleep(0.06)
            AimInitialize.event_generate('<<Ping>>', when='tail')
    except:
        pass

def gotPing(event):
    gpiovalue = gpio.get_keypad_value()
    try:
        if (gpiovalue.strip() !=''):
            select(gpiovalue)
    except:
        pass

AimInitialize.bind('<<Ping>>', gotPing)
th = threading.Thread(target=ping)
th.setDaemon(1)
th.start()

#def checkKey():
#    try:
#        while 1:
#            time.sleep(1)
#            AimInitialize.event_generate('<<INIT>>', when='tail')
#    except:
#        pass

def finalKey():
    global sec, isSoundPlay
    try:
        if (keyString !=""):
            #print keyString
            #lblUserText.set(keyString)
            pass
        else:        
            #WriteToLog('Counting')
            if (sec == 1 or sec == 3 or sec == 5 or sec == 7 or sec == 9):
                isSoundPlay = False
                PlaySounds()
            sec = sec + 1            
            lblTimerText.set(str(sec))
            if (sec == initializeMaxTime):
                #AimInitialize.destroy()
                AimInitialize.after(1000, lambda: AimInitialize.destroy())
                os.system("python AimScanner.py")
    except:
        pass
    finally:
        threading.Timer(1, finalKey).start()

#AimInitialize.bind('<<INIT>>', finalKey)
#th = threading.Thread(target=checkKey)
#th.setDaemon(1)
#th.start()

threading.Timer(1, finalKey).start()
#------------------------------------------------------GPIO---------------------------------------------------------------------

#-----------------------------------------------------SOUND----------------------------------------------------------------------
def PlaySounds():
    global isSoundPlay
    try:   
        if (isSoundPlay == False):
            isSoundPlay = True
            thread = Thread(target =  buzzer.play, args=(5, ))
            thread.start()
    except Exception as e:
       exc_type, exc_obj, exc_tb = sys.exc_info()
       logging.debug(str(exc_tb.tb_lineno) + " " + e.message) 
#---------------------------------------------------------------------------------------------------------------------------

#WriteToLog('Ends The Program Line')
AimInitialize.mainloop()

### Install netconnectd
### Copy netconnectd to path /home/pi. after then, run this terminal command on terminal.

    cd netconnectd
    sudo python setup.py install
    sudo python setup.py install_extras

    sudo service netconnectd start
    sudo update-rc.d netconnectd defaults 98


#!/usr/bin/env python
# coding: utf-8
__version__ = "2.1"
__Date__ = "27MAR2019"

import logging
import socket
import time
from configfile import *

def WriteToLog(comments):
    if (IsLogging):
        try:
            logData = " " + socket.gethostname() + " : " + str(time.strftime("%d-%m-%Y %H:%M:%S")) + " :  " + __file__ + " :  " + comments
            logging.debug(logData)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

LOG_FILENAME = 'aimdr.log'
logging.basicConfig(filename=LOG_FILENAME,level=logging.DEBUG)
#WriteToLog('First Line Started')

try:
    from Tkinter import *   ## notice capitalized T in Tkinter
    import Tkinter as tk
    import ttk
    import os
    from ftplib import FTP
    import FTPSync
    import ZipFunction
    import XMLReader
    import pickle
    import wifi
    import threading
    from threading import Thread
    import time
    from PIL import ImageTk, Image
    import sys
    import AIMDatabase    
    import DR_Key_GPIO as gpio 
    import datetime
    from ttk import Separator   
except Exception as e:
    exc_type, exc_obj, exc_tb = sys.exc_info()
    logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

AimWifi = tk.Tk()
AimWifi.title("AIM CU Wifi Settings")
AimWifi.resizable(0, 0)
w, h = 480, 320
AimWifi.geometry("%dx%d+0+0" % (w, h))
#AimWifi.iconbitmap(iconPath)
#AimWifi.wm_attributes('-type', 'splash')
AimWifi.wm_attributes('-fullscreen', 'true')

#-------- Global Variable Start Here
fontName = "Helvetica"
fontSize = 19
lblHostText = StringVar()
lblPassText = StringVar()
lblPskText = StringVar()
lblPrefiText = StringVar()
lblPostfixText = StringVar()
lblConCheckText = StringVar()
lblOverrideText = StringVar()
lblNextText = StringVar()
lblStatus = StringVar()
enHostText = StringVar(AimWifi, value='')
enPassText = StringVar(AimWifi, value='')
lblInfoText = StringVar()
isPskShows = False
isOverrideShows = False
statusFontSize = (fontName, 12, 'bold')
doubleStatusFontSize = (fontName, 10, 'bold')
btnFontSize = 18
infoFontSize = 18
isConnected = False
isProcessing = False

downIdText = StringVar()
wifiScannerText = StringVar()
ipVerText = StringVar()
timeText = StringVar()
stoNameText = StringVar()

ssid = ''
ipaddress = ''

####------------- Wifi Information-----------------------------------------------------------------------------------
wifiSSID = ''
wifiPSK = ''
wifiPrefix =''
wifiPostfix =''

wifiSSID1 = ''
wifiPSK1 = ''
wifiPrefix1 =''
wifiPostfix1 =''
####-----------------------------------------------------------------------------------------------------------------

#-------- Global Variable Ends Here
def GetConfigData():
   #WriteToLog('GetConfigData Functions Starts')
   ###---------Extract all zip files from local directory
   global wifiSSID
   global wifiPSK
   global wifiPrefix
   global wifiPostfix
   global wifiSSID1
   global wifiPSK1
   global wifiPrefix1
   global wifiPostfix1
   dFiles = []
   try:
       cData = XMLReader.ReadAdminConfigData()
       if (len(cData) > 0):
           wifiSSID = cData.get('Wifi_SSID')
           wifiPSK = cData.get('Wifi_PSK')
           wifiPrefix = cData.get('Wifi_Prefix')
           wifiPostfix = cData.get('Wifi_Postfix')
           wifiSSID1 = cData.get('Wifi1_SSID')
           wifiPSK1 = cData.get('Wifi1_PSK')
           wifiPrefix1 = cData.get('Wifi1_Prefix')
           wifiPostfix1 = cData.get('Wifi1_Postfix')
           
           print wifiSSID
           print wifiPSK
           print wifiPrefix
           print wifiPostfix
           print wifiSSID1
           print wifiPSK1
           print wifiPrefix1
           print wifiPostfix1

           #enHostText.set(wifiSSID)
           enPassText.set(wifiPSK)
           lblPrefiText.set(wifiPrefix)
           lblPostfixText.set(wifiPostfix)
       cData1 = XMLReader.ReadDRConfigData()
       if (len(cData1) > 0):
           print cData1.get('StoreName')
           print cData1.get('DownloadCode')
           downIdText.set(cData1.get('DownloadCode'))
           stoNameText.set(cData1.get('StoreName'))           
   except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
   #finally:
        #WriteToLog('GetConfigData Functions Ends')


####---------------------- GPIO Start ----------------------------------------------------------------------------------------
entry = None

def currentEntry(userEntry):
    global entry
    entry = userEntry
    print entry

def select(value):
    global entry
    global isPskShows
    global isOverrideShows
    try:
        if value == "DEL":
           pos= entry.index(INSERT)
           entry.delete(pos-1, pos)
        elif value == "ESC":
           entry.delete(0, END)
           #os._exit(1)
        elif value == "LEFT":
           pos= entry.index(INSERT)
           entry.icursor(pos-1)
        elif value == "RIGHT":
           pos= entry.index(INSERT)
           entry.icursor(pos+1)
        elif value == "UP":
           entry.icursor(0)
        elif value == "DOWN":
           if (isProcessing == False):
               #entry.icursor(len(entry.get()))
               if (isOverrideShows):
                  isOverrideShows =  False
                  btnOverride.pack_forget() 
               else:
                  isOverrideShows =  True
                  btnOverride.pack(side = LEFT)
               ProcessWork(2)
        elif value == "F2":
           if (isProcessing == False):
               if (isConnected):
                  btnNexts()
               else:
                  ProcessWork(1)
        elif value == "2nd1":
           Show2ndStatus()
        elif value == "2nd2":
           ShowDefaultStatus()
        elif value == "HID":
           if (isProcessing == False):
               if (isPskShows):
                  isPskShows = False
                  lblPass.pack_forget()
                  enPass.pack_forget()
                  #btnPSK.pack_forget()
                  enHost.focus()
               else:
                  isPskShows = True
                  lblPass.pack(side = LEFT)
                  enPass.pack(side = LEFT)
                  #btnPSK.pack(side = LEFT)
                  enPass.focus()
        elif value == "NEX":
           if (isProcessing == False):
              btnNexts()
        #elif value == "CLO":
        #   os._exit(1)
        elif (value == "0" or value == "1" or value == "2" or value == "3"  or value == "4" or value == "5" or 
                value == "6" or value == "7" or value == "8" or value == "9"):
           pos= entry.index(INSERT)
           entry.insert(pos,value)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
####---------------------- GPIO Ends ----------------------------------------------------------------------------------------
### Information Frame
frameInfo = Frame(AimWifi, height=50, pady=10)
frameInfo.pack()
lblInfo = Label(frameInfo, textvariable=lblInfoText, font=(fontName, infoFontSize))
lblInfo.pack(side = LEFT)

frameLabel = Frame(AimWifi, pady=5)
frameLabel.pack()

### Host Frame
frameHost = Frame(AimWifi, pady=5)
frameHost.pack()

lblHostText.set("SSID:")
lblHost = Label(frameHost, font=(fontName, fontSize), textvariable =lblHostText)
lblHost.pack(side=LEFT)

frameSSID = Frame(AimWifi, pady=5)
frameSSID.pack()

lblPrefix = Label(frameSSID, font=(fontName, fontSize), textvariable =lblPrefiText)
lblPrefix.pack(side=LEFT)

enHost = Entry(frameSSID, textvariable=enHostText, width=15, font=(fontName, fontSize))
enHost.select_range(0, END)
enHost.focus()
enHost.pack(side=LEFT)

lblPostfix = Label(frameSSID, font=(fontName, fontSize), textvariable =lblPostfixText)
lblPostfix.pack(side=LEFT)

### User Frame
framePass = Frame(AimWifi, pady=5)
framePass.pack()

lblPassText.set("PSK:")
lblPass = Label(framePass, font=(fontName, fontSize), textvariable =lblPassText)
lblPass.pack(side=LEFT)

enPass = Entry(framePass, textvariable=enPassText, show="*", width=15, font=(fontName, fontSize))
#enPass.configure(state='disabled')
enPass.pack(side=LEFT)

#def btnPSKCallBack():
#    enPass.configure(state='normal')
#    enPass.select_range(0, END)
#    enPass.focus()

#lblPskText.set("PSK")
#btnPSK = Button(framePass, textvariable =lblPskText, font=(fontName, 10), width= 10, height= 1, command= btnPSKCallBack)
#btnPSK.bind("<Return>", lambda event:btnPSKCallBack())
#btnPSK.pack(side = LEFT)

lblPass.pack_forget()
enPass.pack_forget()
#btnPSK.pack_forget()

def btnNexts():
   AimWifi.destroy()
   os.system("python AimFTP.py")

def ProcessWork(types):
   global isProcessing
   isProcessing = True
   ShowProcessStatus()
   if (types==1):
      th1 = threading.Thread(target=btnWifiCallBack)
   elif (types==2):
      th1 = threading.Thread(target=btnOverrideCallBack)
   th1.setDaemon(1)
   th1.start()
   
   
def btnWifiCallBack():
   #WriteToLog('btnWifiCallBack Functions Starts')
   global isConnected, isProcessing
   isConnected = False
   try:
       global wifiPrefix
       global wifiPostfix
       #print "wifi checking"
       if (enHost.get().strip() !=''):
           ssid =  wifiPrefix.strip() + enHost.get().strip() + wifiPostfix.strip()
           print "PSK=" + enPass.get().strip()
           data = {"ssid": ssid, "psk": enPass.get().strip(), "force": True}
           net = wifi.NetconnectdClient()
           net._get_wifi_list()
           net.command('configure_wifi', data)
           content = net._get_status()
           #print content
           if (len(content) >0):
              if (content.get('wifi')['current_ssid'] == ssid):
                 isConnected = True
   except Exception as e:
       exc_type, exc_obj, exc_tb = sys.exc_info()
       logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
   finally:
       print "isConnected=" + str(isConnected)
       if (isConnected):
          ShowSuccessStatus()
          btnNext.pack(side = RIGHT)
       else:
          ShowNotSuccessStatus()
       isProcessing = False
       #WriteToLog('btnWifiCallBack Functions Ends')
          
   
def btnOverrideCallBack():
   #WriteToLog('btnOverrideCallBack Functions Starts')
   global isConnected, isProcessing
   isConnected = False
   try:
       #print "wifi checking"
       if (enHost.get().strip() !=''):
           data = {"ssid": enHost.get().strip(), "psk": enPass.get().strip(), "force": True}
           print "PSK=" + enPass.get().strip()
           net = wifi.NetconnectdClient()
           net._get_wifi_list()
           net.command('configure_wifi', data)
           content = net._get_status()
           #print content
           if (len(content) >0):
              if (content.get('wifi')['current_ssid'] == enHost.get().strip()):
                 isConnected = True
   except Exception as e:
       exc_type, exc_obj, exc_tb = sys.exc_info()
       logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
   finally:
       if (isConnected):
          ShowSuccessStatus()
          btnNext.pack(side = RIGHT)
       else:
          ShowNotSuccessStatus()
       isProcessing = False
       #WriteToLog('btnOverrideCallBack Functions Ends')


### Button Submit Frame
frameButton = Frame(AimWifi, pady=3)
frameButton.pack()

lblConCheckText.set("Connect")
btnFTP = Button(frameButton, textvariable =lblConCheckText, font=(fontName, fontSize), width=12, command = lambda: ProcessWork(1))
btnFTP.bind("<Return>", lambda event:ProcessWork(1))
btnFTP.configure(height=2)
btnFTP.pack(side = LEFT)

lblOverrideText.set("Override")
btnOverride = Button(frameButton, textvariable =lblOverrideText, font=(fontName, fontSize), width=12, command = lambda: ProcessWork(2), padx=2)
btnOverride.bind("<Return>", lambda event:ProcessWork(2))
btnOverride.pack(side = LEFT)
btnOverride.configure(height=2)
btnOverride.pack_forget()

lblNextText.set("Next")
btnNext = Button(frameButton, textvariable =lblNextText, font=(fontName, fontSize), width=12, command = btnNexts, padx=2)
btnNext.bind("<Return>", lambda event:btnNexts())
btnNext.pack(side = RIGHT)
btnNext.configure(height=2)
btnNext.pack_forget()

## Status bar
frameStatus = Frame(AimWifi, bd=1, relief=SUNKEN, height=18)
frameStatus.pack(side=BOTTOM, fill='x')

lblStaWifiScaner = Label(frameStatus, textvariable=wifiScannerText, font=doubleStatusFontSize)
lblStaWifiScaner.pack(side=LEFT)

sep1 = Separator(frameStatus, orient=VERTICAL)
sep1.pack(side=LEFT, fill="y")

lblStaIpVer = Label(frameStatus, textvariable=ipVerText, font=doubleStatusFontSize)
lblStaIpVer.pack(side=LEFT)

sep2 = Separator(frameStatus, orient=VERTICAL)
sep2.pack(side=LEFT, fill="y")

lblStaDownId = Label(frameStatus, textvariable=downIdText, font=statusFontSize)
lblStaDownId.pack(side=LEFT)

sep3 = Separator(frameStatus, orient=VERTICAL)
sep3.pack(side=LEFT, fill="y")

lblStaTime = Label(frameStatus, textvariable=timeText, font=doubleStatusFontSize)
lblStaTime.pack(side=LEFT)

sep4 = Separator(frameStatus, orient=VERTICAL)
sep4.pack(side=LEFT, fill="y")

lblStaStore = Label(frameStatus, textvariable=stoNameText, font=statusFontSize)
lblStaStore.pack(side=LEFT)

lblStaWifi = Label(frameStatus, font=statusFontSize)
lblStaWifi.pack(side=RIGHT)

lblStaFTP = Label(frameStatus, font=statusFontSize)
lblStaFTP.pack(side=RIGHT)

lblStaBlue = Label(frameStatus, font=statusFontSize)
lblStaBlue.pack(side=RIGHT)

lblSta2nd = Label(frameStatus, font=statusFontSize)
lblSta2nd.pack(side=RIGHT)

def ShowDefaultStatus():
   lblSta2nd.configure(image='')
   lblSta2nd.image= ''

def ShowProcessStatus():
   img = ImageTk.PhotoImage(Image.open(wyIcon))
   lblStaFTP.configure(image=img)
   lblStaFTP.image= img
   lblInfoText.set("Connecting...")

def ShowSuccessStatus():
   img = ImageTk.PhotoImage(Image.open(wgIcon))
   lblStaFTP.configure(image=img)
   lblStaFTP.image= img
   lblInfoText.set("Connected")

def ShowNotSuccessStatus():   
   img = ImageTk.PhotoImage(Image.open(wrIcon))
   lblStaFTP.configure(image=img)
   lblStaFTP.image= img
   lblInfoText.set("Failed to Connect!")

def Show2ndStatus():
   img = ImageTk.PhotoImage(Image.open(secondIcon))
   lblSta2nd.configure(image=img)
   lblSta2nd.image= img

def FillStatusInfo():  
    global ssid, ipaddress
    ssid = os.popen("iwconfig wlan0 \
                | grep 'ESSID' \
                | awk '{print $4}' \
                | awk -F\\\" '{print $2}'").read()    
    
    if (ssid.strip() !=""):
        if ("AIM" in ssid):
            ssid = ssid.replace("AIM", "").strip()
        if ("INV" in ssid):
            ssid = ssid.replace("INV", "").strip()
        print ssid
    if (len(ssid) == 1):
        ssid = "000" + ssid
    elif (len(ssid) == 2):
        ssid = "00" + ssid
    elif (len(ssid) == 3):
        ssid = "0" + ssid
    elif (len(ssid) > 4):
        ssid = ssid[:4]

    ipaddress = os.popen("ifconfig wlan0 \
                     | grep 'inet addr' \
                     | awk -F: '{print $2}' \
                     | awk '{print $1}'").read()
    
    if (ipaddress.strip() !=""):
        currIPAddress = ipaddress.split('.')
        if (len(currIPAddress) > 1):
            myIps = currIPAddress[2].strip()[-1:]
            ipaddress = myIps + "." + currIPAddress[3]
        print ipaddress

    scannerid = AIMDatabase.GetRegistrerScannerId()
    if (len(scannerid) == 1):
        scannerid = "000" + scannerid
    elif (len(scannerid) == 2):
        scannerid = "00" + scannerid
    elif (len(scannerid) == 3):
        scannerid = "0" + scannerid

    wifiScannerText.set(ssid + "\n" + scannerid)
    ipVerText.set(ipaddress.strip() + "\n" + __version__)
    UpdateStatusTime()

def UpdateStatusTime():
    now = datetime.datetime.now()
    myHour = str(now.hour)
    if (len(myHour) == 1):
        myHour = "0" + str(myHour)
    myMin = str(now.minute)
    if (len(myMin) == 1):
        myMin = "0" + str(myMin)
    myDay = str(now.day)
    if (len(myDay) == 1):
        myDay = "0" + str(myDay)
    myMonth = str(now.month)
    if (len(myMonth) == 1):
        myMonth = "0" + str(myMonth)
    timeText.set(myHour + myMin + "\n" + myDay + myMonth + str(now.year)[2:])

#----- Get Admin Configuration
GetConfigData()
FillStatusInfo()

#Check defautl directory and create if not exists
if not os.path.exists("config"):
    os.makedirs("config")
if not os.path.exists("update"):
    os.makedirs("update")
if not os.path.exists("status"):
    os.makedirs("status")
if not os.path.exists("drdata"):
    os.makedirs("drdata")

#-----------------------------------------------------GPIO----------------------------------------------------------------------
enHost.bind("<FocusIn>", lambda event:currentEntry(enHost))
enPass.bind("<FocusIn>", lambda event:currentEntry(enPass))

def ping():
    try:
        while 1:
            time.sleep(0.06)
            AimWifi.event_generate('<<Ping>>', when='tail')
    except:
        pass

def gotPing(event):
    gpiovalue = gpio.get_keypad_value()
    try:
        if (gpiovalue.strip() !=''):
            select(gpiovalue)
    except:
        pass


AimWifi.bind('<<Ping>>', gotPing)
th = threading.Thread(target=ping)
th.setDaemon(1)
th.start()
#---------------------------------------------------------------------------------------------------------------------------
#WriteToLog('Ends The Program Line')
AimWifi.mainloop()
#!/usr/bin/env python
import smbus
import sys
import time
__version__ = "1.7"

KeyPadTable= [['ESC','F2','9'], ['7','8','6'], ['4','5','3'], ['1', '2','0','2nd']]
Key2ndTable= [['CLO','','GT'], ['ST','UP','RIGHT'],['LEFT','TR','DEL'], ['HID','DOWN','NEX','2nd']]
RowID=[0,0,0,0 ,0,0,0,4 ,0,0,0,3 ,0,2,1,0]

Press2ndKey = False
CurrentKey=None
I2CBus=1
I2CAddress=0x27  
I2CAddress = I2CAddress
I2CBus = I2CBus

#open smbus pcf8574
bus = smbus.SMBus(I2CBus)

#set pcf to input
bus.write_byte(I2CAddress,0xff)
  
def get_keymatrix_value():
  keyVal = None
  try:
    #set P4 Low First
    OutPin= 0x10
    for Column in range(4):
      #scan first row to see if we have something
      bus.write_byte(I2CAddress,~OutPin)
      #read the key now 
      key = RowID[bus.read_byte(I2CAddress) & 0x0f]
      if key >0 :
          if (Press2ndKey):
            keyVal= Key2ndTable[key-1][Column]
          else:  
            keyVal= KeyPadTable[key-1][Column]
      OutPin = OutPin * 2
  except Exception as e:
    print(e)
  finally:
    return keyVal

#ReadKey return current key once and debounce it
def ReadKey():
 global CurrentKey
 LastKey= CurrentKey
 try:
   while True:    
    NewKey= get_keymatrix_value()

    if NewKey != LastKey:
      time.sleep(0.02)
      LastKey= NewKey
    else:
      break

   #if LastValue is the same than CurrentValue
   #just return None
   if LastKey==CurrentKey:
     return None
   
   #ok put Lastvalue to be CurrentValue
   CurrentKey=LastKey
   return CurrentKey 
 except Exception as e:
   print(e)

# Get the value for Keypad.
def get_keypad_value():
  global Press2ndKey
  try:
      V = ReadKey()
      if V != None:
        if (V=="2nd"):
          if (Press2ndKey):
            Press2ndKey = False
            return "2nd2"
          else:
            Press2ndKey = True
            return "2nd1"
        else:
          return V
  except Exception as e:
    print(e)
    pass
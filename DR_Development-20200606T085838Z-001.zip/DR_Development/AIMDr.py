#!/usr/bin/env python
# -*- coding: utf-8 -*-
__version__ = "7.8"
__Date__ = "27MAR2019"

import logging
import socket
import time
from configfile import *

def WriteToLog(comments):
    if (IsLogging):
        try:
            now = time.time()
            struct_now = time.localtime(now)
            mlsec = repr(now).split('.')[1][:3]
            logData = " " + socket.gethostname() + " : " + str(time.strftime("%d-%m-%Y %H:%M:%S.{} %Z".format(mlsec), struct_now)) + " :  " + __file__ + " :  " + comments
            logging.debug(logData)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

LOG_FILENAME = 'aimdr.log'
logging.basicConfig(filename=LOG_FILENAME,level=logging.DEBUG)
#WriteToLog('First Line Started')

try:
    from Tkinter import *  ## notice capitalized T in Tkinter
    import Tkinter as tk
    import ttk
    import tkFont as font
    import tkFont as fontLab
    import threading
    from threading import Thread
    import random
    import os    
    import datetime
    from array import *
    import csv
    from uuid import getnode as get_mac
    import sys
    import subprocess
    import time
    import math
    from stdnum.exceptions import *
    from stdnum.util import clean
    from PIL import ImageTk, Image
    from bluetoothctl import *    
    import DR_Key_GPIO as gpio
    import RPi.GPIO as GPIOSound
    import AIMDatabase
    import ZipFunction
    import FTPSync
    import XMLReader   
    import AIMVersionCheck
    from AIMSound import *
    from AIMManualSync import *
    import tkMessageBox
    from ttk import Separator
except Exception as e:
    exc_type, exc_obj, exc_tb = sys.exc_info()
    logging.debug(str(exc_tb.tb_lineno) + " " + e.message)


#Main Form
Keyboard_App = tk.Tk()
Keyboard_App.title("AIM DR")
Keyboard_App.resizable(0, 0)
w, h = 480, 320
Keyboard_App.geometry("%dx%d+0+0" % (w, h))
Keyboard_App.wm_attributes('-fullscreen', 'true')

# standard named font (everything that uses it will change)
font.nametofont('TkDefaultFont').configure(size=12)  # tiny

#-------- Global Variable Start Here
MyFont = font.Font(weight='normal')
entryDefWidth = 19 
entryDefFontSize = 34
entryMAXInputSize = 52
counter = 1
fontName = "Helvetica"
bottomTextSize = 18
statusFontSize = (fontName, 12, 'bold')
doubleStatusFontSize = (fontName, 10, 'bold')
reportFontSize = 16
deleteFontSize = 16
reportFontSize = 20

isExactFieldLength = False
isFieldLength = False
isDoubleKey = False
isDoubleKeyValid = True
isForcedKey = False
srcInput = False
srcBluetooth = False
isAutoQtyFound = False
isAutoPriceFound = False
isScheduleStarted = False
isProcessing = False
isFtpWorking = False
####----------------------------- This is for hold loop and data start here ----------------------------
cData = {}
downloadCode = ''
totDataCount = 0
totLoopCount = 3
currLoopPosition = 0
decimalPosition = 2

aimLocation = '0'
aimPrice = '0'
aimQty = '0'
totAimQty = 0
totAimQtyDesc = ''
runningAimQtyDesc= ''
aimDataValue = []
data1 = ''
data2 = ''
data3 = ''
data4 = ''
data5 = ''
data6 = ''
data7 = ''
data8 = ''
data9 = ''
data10 = ''
lDbLookup = ''
pDbLookup = ''
qDbLookup = ''
dDbLookup = ['','','','','','','','','','']
aimConcatDataValue = ''
aimFinalValue =''
aimCSVHeader = ''
aimCSVValue = ''
DROutUnique_Id = 1
ScheduleCode = ''
UserId = ''
DRId = ''
startLocation = 0
endLocation = 0
csvFileName = ''
zipFileName = ''
fileName = ''
maxId = 0
currentId = 0
currentPointer = 0
totRecord = 0
EscKeyCount = 0
DoubleEnterCount = 1
isJumpKeyFound = False
maxJumpKey = 1
isLocationChangeKeyFound = False
isRunningTotFound = False
isDataValidate = True
isRunnningDataValidate = True
currStatus = 0
prevLength = 0
currLength = 0
loopBackNo = 0    
isDataLoopBak = False
isReportFormShow = False
isDeleteFormShow = False
isTransferFormShow = False
isRevFormShow = False
is2ndKeyShows = False
lblStatus = StringVar()
downIdText = StringVar()
wifiScannerText = StringVar()
ipVerText = StringVar()
timeText = StringVar()
stoNameText = StringVar()
ssid = ''
ipaddress = ''

lblCountText = StringVar()
lblHeadText = StringVar()
lblValueText = StringVar()

####------------- FTP Information------------------------------------------------------------------------------------
ftpHost = ''
ftpUser = ''
ftpPass = ''
ftpHost1 = ''
ftpUser1 = ''
ftpPass1 = ''
ftpRemoteDir = ''
ReviewName = ''
CurrentHeadDescription = ''
autoSync = True
autoLocationNumSync = 0
####-----------------------------------------------------------------------------------------------------------------

locationPosition = 0
pricePosition = 0
qtyPosition = 0

AllowedBarcodePrefix = ''
AllowedBarcodePrefixType = ''
finalAllowedBarcodePrefix = ''
frmReport = None
listbox = None
frmDeletePopup = None
frmSyncPopup = None
lblSta2ndStatus = None
ScannerId = '0'
ReportKey = 'ST'
isDoubleKeyFound = False
isDoubleKeyFailed = False
isReviewing = False
PrevDoubleVal =''
PrevCloseValue = ''
PrevEscValue = ''
CurrPrefix = ''
prefixData = ''

#------- Key Stroke Counter -----------------
totalStrokeCount = 0
totalPieceCount = 0
strokeEndTime = 0
isCounterEnable = True
Kph = 0
Pph = 0
listItemCount = 0
currentIndex = 0

###--Show the VK 
IsVKShow = False
isLowerVKShow = False
vkButtonFontSize = 12

buzzer = Buzzer()

#-------------Show the report start here---------------------------------------------------------------------------------------------------------------------------------------------
class frmReports:
    def __init__(self, master):
        #WriteToLog('Reports Form Loading Starts')
        global lblSta2ndStatus, Kph, Pph, listItemCount, currentIndex, listbox
        listItemCount = 0
        currentIndex = 0
        headlblText = StringVar()
        self.master = master
        self.frame = Frame(self.master)
        self.frame.pack()

        ##------------------------- Status bar start ---------------------------------------------------------
        self.frameStatus = Frame(self.frame, bd=1, relief=SUNKEN, height=18)
        self.frameStatus.pack(side=BOTTOM, fill='x')

        lblSta2ndStatus = Label(self.frameStatus, font=(fontName, statusFontSize))
        lblSta2ndStatus.pack(side=LEFT)
        img = ImageTk.PhotoImage(Image.open(secondIcon))
        lblSta2ndStatus.configure(image=img)
        lblSta2ndStatus.image= img

        self.lblStaDownId = Label(self.frameStatus, textvariable=downIdText, font=(fontName, statusFontSize))
        self.lblStaDownId.pack(side=LEFT)

        self.lblStaWifi = Label(self.frameStatus, font=(fontName, statusFontSize))
        self.lblStaWifi.pack(side=RIGHT)
        self.img1 = ImageTk.PhotoImage(Image.open(wgIcon))
        self.lblStaWifi.configure(image=img1)

        self.lblStaFTP = Label(self.frameStatus, font=(fontName, statusFontSize))
        self.lblStaFTP.pack(side=RIGHT)
        self.img2 = ImageTk.PhotoImage(Image.open(fgIcon))
        self.lblStaFTP.configure(image=img2)

        self.lblStaBlue = Label(self.frameStatus, font=(fontName, statusFontSize))
        self.lblStaBlue.pack(side=RIGHT)
        self.img3 = ImageTk.PhotoImage(Image.open(bgIcon))
        self.lblStaBlue.configure(image=img3)

        self.lblStaVersion = Label(self.frameStatus, text=__version__, font=(fontName, statusFontSize))
        self.lblStaVersion.pack(side=RIGHT)

        ##------------------------- Status bar ends ---------------------------------------------------------


        self.lblHeader = Label(self.frame, textvariable=headlblText, font=(fontName, reportFontSize))
        self.lblHeader.pack()

        self.scrollbar = Scrollbar(self.frame)
        self.scrollbar.pack(side=RIGHT, fill=Y)

        listbox = Listbox(self.frame, width=480, height=320, font=(fontName, reportFontSize))        
        listbox.bind('<<ListboxSelect>>', self.SelectList)
        listbox.pack(side="left", fill=BOTH, expand=True)

        # attach listbox to scrollbar
        listbox.config(yscrollcommand=self.scrollbar.set)
        self.scrollbar.config(command=listbox.yview)
        

        priceHide = False
        qtyHide = False
        data1Hide = False
        data2Hide = False
        data3Hide = False
        if (str(cData.get('P_ShowsInReport')).lower() == 'false'):
            priceHide =True
        if (str(cData.get('Q_ShowsInReport')).lower() == 'false'):
            qtyHide = True
        if (totDataCount > 0):
            if (str(cData.get('I0_ShowsInReport')).lower() == 'false'):
                data1Hide = True
        if (totDataCount > 1):
            if (str(cData.get('I1_ShowsInReport')).lower() == 'false'):
                data2Hide = True
        if (totDataCount > 2):
            if (str(cData.get('I2_ShowsInReport')).lower() == 'false'):
                data3Hide = True
        qtySpace = "   "
        d1Space = "     "
        d2Space = "      "
        d3Space = "       "
        lForlocation ="L: "
        pForPrice =" P: "
        qForQty =" Q: "
        d1ForData1 ="D1: "
        d2ForData2 ="D2: "
        d3ForData3 ="D3: "

        if (ReportKey == "GT"):
            headlblText.set("Grand Total")
            try:
                if (priceHide == False or qtyHide == False):
                    cursorGt = AIMDatabase.GetGTReportTotal(ScheduleCode)
                    for rowHead in cursorGt:
                        if (priceHide == False):
                            listbox.insert(END, cData.get('P_Description') + " = " + str(rowHead[0]))
                        if (qtyHide == False):
                            listbox.insert(END, cData.get('Q_Description') + " = " + str(rowHead[1]))

                cursor = AIMDatabase.GetGTReportData(ScheduleCode, 'Location, GroupId, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Location, GroupId', "ScheduleCode='" + ScheduleCode + "' AND Active=1")
                for row in cursor:
                    if (qtyHide and priceHide):
                        listbox.insert(END, lForlocation + row[0])
                    elif (qtyHide !=True and priceHide !=True):
                        listbox.insert(END, lForlocation + row[0] + pForPrice + str(row[2]) +  qForQty + str(row[3]))
                    else :
                       if (qtyHide):
                        listbox.insert(END, lForlocation + row[0] + pForPrice + str(row[2]))
                       elif (priceHide):
                        listbox.insert(END, lForlocation + row[0] + qForQty + str(row[3]))
                        

                    if (totDataCount > 0):
                        cursor1 = AIMDatabase.GetGTReportData(ScheduleCode, 'Data1, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Data1', "ScheduleCode='" + ScheduleCode +  "'  AND Active=1 AND GroupId=" + str(row[1]) + " AND Location=" + row[0])
                        for row1 in cursor1:
                            if (data1Hide == False):
                                if (qtyHide and priceHide):
                                    listbox.insert(END, d1Space + d1ForData1 + row1[0])
                                elif (qtyHide !=True and priceHide !=True):
                                    listbox.insert(END, d1Space + d1ForData1 + row1[0] + pForPrice + str(row1[1]) + qForQty + str(row1[2]))
                                else:
                                    if (qtyHide):
                                        listbox.insert(END, d1Space + d1ForData1 + row1[0] + pForPrice + str(row1[1]))
                                    elif (priceHide):
                                        listbox.insert(END, d1Space + d1ForData1 + row1[0] + qForQty + str(row1[2]))

                            if (totDataCount > 1): 
                                cursor2 = AIMDatabase.GetGTReportData(ScheduleCode, 'Data2, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Data2', "ScheduleCode='" + ScheduleCode + "' AND Active=1 AND GroupId=" + str(row[1]) + " AND Location=" + row[0] + " AND Data1=" + row1[0])
                                for row2 in cursor2:
                                    if (data2Hide == False):
                                        if (qtyHide and priceHide):
                                            listbox.insert(END, d2Space + d2ForData2 + row2[0])
                                        elif (qtyHide !=True and priceHide !=True):
                                            listbox.insert(END, d2Space + d2ForData2 + row2[0] +pForPrice + str(row2[1]) + qtySpace + str(row2[2]))
                                        else:
                                            if (qtyHide):
                                                listbox.insert(END, d2Space + d2ForData2 + row2[0] +pForPrice + str(row2[1]))
                                            elif (priceHide):
                                                listbox.insert(END, d2Space + d2ForData2 + row2[0] +qtySpace + str(row2[2]))

                                if (totDataCount > 2): 
                                    cursor3 = AIMDatabase.GetGTReportData(ScheduleCode, 'Data3, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Data3', "ScheduleCode='" + ScheduleCode + "' AND Active=1 AND GroupId=" + str(row[1]) +  " AND Location=" + row[0] + " AND Data1=" + row1[0] + " AND Data2=" + row2[0])
                                    for row3 in cursor3:
                                        if (data3Hide == False):
                                            if (qtyHide and priceHide):
                                                listbox.insert(END, d3Space + d3ForData3 + row3[0])
                                            elif (qtyHide !=True and priceHide !=True):
                                                listbox.insert(END, d3Space + d3ForData3 + row3[0] +pForPrice + str(row3[1]) + qForQty+ str(row3[2]))
                                            else:
                                                if (qtyHide):
                                                    listbox.insert(END, d3Space + d3ForData3 + row3[0] +pForPrice + str(row3[1]))
                                                elif (priceHide):
                                                    listbox.insert(END, d3Space + d3ForData3 + row3[0] +qtySpace + str(row3[2]))
                                                
            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        else:
            headlblText.set("Sub Total")
            try:
                currDataLoc = 0
                if (currStatus == locationPosition):
                    cursor = AIMDatabase.GetReportData(str(DROutUnique_Id), ScheduleCode, 'Location, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Location', "ScheduleCode='" + ScheduleCode + "' AND Active=1")
                    for row in cursor:
                        if (qtyHide and priceHide):
                            listbox.insert(END, lForlocation + row[0])
                        elif (qtyHide !=True and priceHide !=True):
                            listbox.insert(END, lForlocation + row[0] +pForPrice + str(row[1]) + qForQty + str(row[2]))
                        else:
                            if (qtyHide):
                                listbox.insert(END, lForlocation + row[0] +pForPrice + str(row[1]))
                            elif (priceHide):
                                listbox.insert(END, lForlocation + row[0] + qForQty + str(row[2]))
                
                elif (currStatus == pricePosition) or (currStatus == qtyPosition):
                    cursor = AIMDatabase.GetReportData(str(DROutUnique_Id), ScheduleCode, 'Location, GroupId, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Location', "ScheduleCode='" + ScheduleCode + "' AND Active=1")
                    for row in cursor:
                        if (qtyHide and priceHide):
                            listbox.insert(END, lForlocation + row[0])
                        elif (qtyHide !=True and priceHide !=True):
                            listbox.insert(END, lForlocation + row[0] +pForPrice + str(row[2]) + qForQty + str(row[3]))
                        else:
                            if (qtyHide):
                                listbox.insert(END, lForlocation + row[0] +pForPrice + str(row[2]))
                            elif (priceHide):
                                listbox.insert(END, lForlocation + row[0] +qForQty + str(row[3]))
                            

                        if (totDataCount > 0):
                            cursor1 = AIMDatabase.GetReportData(str(DROutUnique_Id), ScheduleCode, 'Data1, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Data1', "ScheduleCode='" + ScheduleCode + "' AND Active=1 AND Location=" + row[0])
                            for row1 in cursor1:
                                if (data1Hide == False):
                                    if (qtyHide and priceHide):
                                        listbox.insert(END, d1Space + d1ForData1 + row1[0])
                                    elif (qtyHide !=True and priceHide !=True):
                                        listbox.insert(END, d1Space + d1ForData1 + row1[0] +pForPrice + str(row1[1]) + qForQty + str(row1[2]))
                                    else:
                                        if (qtyHide):
                                            listbox.insert(END, d1Space + d1ForData1 + row1[0] + pForPrice + str(row1[1]))
                                        elif (priceHide):
                                            listbox.insert(END, d1Space + d1ForData1 + row1[0] + qForQty + str(row1[2]))                                        

                                if (totDataCount > 1):
                                    cursor2 = AIMDatabase.GetReportData(str(DROutUnique_Id), ScheduleCode, 'Data2, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Data2', "ScheduleCode='" + ScheduleCode + "' AND Active=1 AND Location=" + row[0] + " AND Data1=" + row1[0])
                                    for row2 in cursor2:
                                        if (data2Hide == False):
                                            if (qtyHide and priceHide):
                                                listbox.insert(END, d2Space + d2ForData2 + row2[0])
                                            elif (qtyHide !=True and priceHide !=True):
                                                listbox.insert(END, d2Space + d2ForData2 + row2[0] +pForPrice + str(row2[1]) + qtySpace + str(row2[2]))
                                            else:
                                                if (qtyHide):
                                                    listbox.insert(END, d2Space + d2ForData2 + row2[0] +pForPrice + str(row2[1]))
                                                elif (priceHide):
                                                    listbox.insert(END, d2Space + d2ForData2 + row2[0] +":  " + str(row2[2]))

                                        if (totDataCount > 2):
                                            cursor3 = AIMDatabase.GetReportData(str(DROutUnique_Id), ScheduleCode, 'Data3, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Data3', "ScheduleCode='" + ScheduleCode + "' AND Active=1 AND Location=" + row[0] + " AND Data1=" + row1[0] + " AND Data2=" + row2[0])
                                            for row3 in cursor3:
                                                if (data3Hide == False):
                                                    if (qtyHide and priceHide):
                                                        listbox.insert(END, d3Space + d3ForData3 + row3[0])
                                                    elif (qtyHide !=True and priceHide !=True):
                                                        listbox.insert(END, d3Space + d3ForData3 + row3[0] +pForPrice + str(row3[1]) + qForQty + str(row3[2]))
                                                    else:
                                                        if (qtyHide):
                                                            listbox.insert(END, d3Space + d3ForData3 + row3[0] +pForPrice + str(row3[1]))
                                                        elif (priceHide):
                                                            listbox.insert(END, d3Space + d3ForData3 + row3[0] +qForQty + str(row3[2]))                                                        
                                                        

                else:
                    for x in range(totDataCount):
                        if ((x+1) == currLoopPosition):
                            currDataLoc = currDataLoc+1    
                            break

                    if (currDataLoc==1):
                        cursor = AIMDatabase.GetReportData(str(DROutUnique_Id), ScheduleCode, 'Location, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Location', "ScheduleCode='" + ScheduleCode + "' AND Active=1")
                        for row in cursor:
                            if (qtyHide and priceHide):
                                listbox.insert(END, lForlocation + row[0])
                            elif (qtyHide !=True and priceHide !=True):
                                listbox.insert(END, lForlocation + row[0] +pForPrice + str(row[1]) + qForQty + str(row[2]))
                            else:
                                if (qtyHide):
                                    listbox.insert(END, lForlocation + row[0] +pForPrice + str(row[1]))
                                elif (priceHide):
                                    listbox.insert(END, lForlocation + row[0] +qForQty+ str(row[2]))                                
                                

                            cursor1 = AIMDatabase.GetReportData(str(DROutUnique_Id), ScheduleCode, 'Data1, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Data1', "ScheduleCode='" + ScheduleCode + "' AND Active=1 AND Location=" + row[0])
                            for row1 in cursor1:
                                if (data1Hide == False):
                                    if (qtyHide and priceHide):
                                        listbox.insert(END, d1Space + d1ForData1 + row1[0])
                                    elif (qtyHide !=True and priceHide !=True):
                                        listbox.insert(END, d1Space + d1ForData1 + row1[0] +pForPrice + str(row1[1]) + qForQty + str(row1[2]))
                                    else:
                                        if (qtyHide):
                                            listbox.insert(END, d1Space + d1ForData1 + row1[0] +pForPrice + str(row1[1]))
                                        elif (priceHide):
                                            listbox.insert(END, d1Space + d1ForData1 + row1[0] +qtySpace + str(row1[2]))
            
                    if (currDataLoc==2):
                        cursor = AIMDatabase.GetReportData(str(DROutUnique_Id), ScheduleCode, 'Location, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Location', "ScheduleCode='" + ScheduleCode + "' AND Active=1")
                        for row in cursor:
                            if (qtyHide and priceHide):
                                listbox.insert(END, lForlocation + row[0])
                            elif (qtyHide !=True and priceHide !=True):
                                listbox.insert(END, lForlocation + row[0] +pForPrice + str(row[1]) + qForQty + str(row[2]))    
                            else:
                                if (qtyHide):
                                    listbox.insert(END, lForlocation + row[0] +pForPrice + str(row[1]))
                                elif (priceHide):
                                    listbox.insert(END, lForlocation + row[0] +qtySpace + str(row[2]))                                
                    
                            cursor1 = AIMDatabase.GetReportData(str(DROutUnique_Id), ScheduleCode, 'Data1, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Data1', "ScheduleCode='" + ScheduleCode + "' AND Active=1 AND Location=" + row[0])
                            for row1 in cursor1:
                                if (data1Hide == False):
                                    if (qtyHide and priceHide):
                                        listbox.insert(END, d1Space + d1ForData1 + row1[0])
                                    elif (qtyHide !=True and priceHide !=True):
                                        listbox.insert(END, d1Space + d1ForData1 + row1[0] +pForPrice + str(row1[1]) + qForQty + str(row1[2]))
                                    else:
                                        if (qtyHide):
                                            listbox.insert(END, d1Space + d1ForData1 + row1[0] +pForPrice + str(row1[1]))
                                        elif (priceHide):
                                            listbox.insert(END, d1Space + d1ForData1 + row1[0] +qtySpace + str(row1[2]))
                                            
                        
                                cursor2 = AIMDatabase.GetReportData(str(DROutUnique_Id), ScheduleCode, 'Data2, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Data2', "ScheduleCode='" + ScheduleCode + "' AND Active=1 AND Location=" + row[0] + " AND Data1=" + row1[0])
                                for row2 in cursor2:
                                    if (data2Hide == False):        
                                        if (qtyHide and priceHide):
                                            listbox.insert(END, d2Space + d2ForData2 + row2[0])
                                        elif (qtyHide !=True and priceHide !=True):
                                            listbox.insert(END, d2Space + d2ForData2 + row2[0] +pForPrice + str(row2[1]) + qForQty + str(row2[2]))
                                        else:
                                            if (qtyHide):
                                                listbox.insert(END, d2Space + d2ForData2 + row2[0] +pForPrice + str(row2[1]))
                                            elif (priceHide):
                                                listbox.insert(END, d2Space + d2ForData2 + row2[0] +qtySpace + str(row2[2]))
                                            
                            
                    if (currDataLoc==3):
                        cursor = AIMDatabase.GetReportData(str(DROutUnique_Id), ScheduleCode, 'Location, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Location', "ScheduleCode='" + ScheduleCode + "' AND Active=1")
                        for row in cursor:
                            if (qtyHide and priceHide):
                                listbox.insert(END, lForlocation + row[0])
                            elif (qtyHide !=True and priceHide !=True):
                                listbox.insert(END, lForlocation + row[0] +pForPrice + str(row[1]) + qForQty + str(row[2]))
                            else:
                                if (qtyHide):
                                    listbox.insert(END, lForlocation + row[0] +pForPrice + str(row[1]))
                                elif (priceHide):
                                    listbox.insert(END, lForlocation + row[0] +qtySpace + str(row[2]))                                
                    
                            if (totDataCount > 0):
                                cursor1 = AIMDatabase.GetReportData(str(DROutUnique_Id), ScheduleCode, 'Data1, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Data1', "ScheduleCode='" + ScheduleCode + "' AND Active=1 AND Location=" + row[0])
                                for row1 in cursor1:
                                    if (data1Hide == False):
                                        if (qtyHide and priceHide):
                                            listbox.insert(END, d1Space + d1ForData1 + row1[0])
                                        elif (qtyHide !=True and priceHide !=True):
                                            listbox.insert(END, d1Space + d1ForData1 + row1[0] +pForPrice + str(row1[1]) + qForQty + str(row1[2]))
                                        else:
                                            if (qtyHide):
                                                listbox.insert(END, d1Space + d1ForData1 + row1[0] +pForPrice + str(row1[1]))
                                            elif (priceHide):
                                                listbox.insert(END, d1Space + d1ForData1 + row1[0] +qtySpace + str(row1[2]))
                                            

                                    if (totDataCount > 1):
                                        cursor2 = AIMDatabase.GetReportData(str(DROutUnique_Id), ScheduleCode, 'Data2, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Data2', "ScheduleCode='" + ScheduleCode + "' AND Active=1 AND Location=" + row[0] + " AND Data1=" + row1[0])
                                        for row2 in cursor2:
                                            if (data2Hide == False):
                                                if (qtyHide and priceHide):
                                                    listbox.insert(END, d2Space + d2ForData2 + row2[0])
                                                elif (qtyHide !=True and priceHide !=True):
                                                    listbox.insert(END, d2Space + d2ForData2 + row2[0] +pForPrice + str(row2[1]) + qForQty + str(row2[2]))
                                                else:
                                                    if (qtyHide):
                                                        listbox.insert(END, d2Space + d2ForData2 + row2[0] +pForPrice + str(row2[1]))
                                                    elif (priceHide):
                                                        listbox.insert(END, d2Space + d2ForData2 + row2[0] +qtySpace + str(row2[2]))
                                                    

                                        if (totDataCount > 2):
                                            cursor3 = AIMDatabase.GetReportData(str(DROutUnique_Id), ScheduleCode, 'Data3, Sum(Price) as TotalPrice, Sum(Qty) as TotalQty', 'Data3', "ScheduleCode='" + ScheduleCode + "' AND Active=1 AND Location=" + row[0] + " AND Data1=" + row1[0] + " AND Data2=" + row2[0])
                                            for row3 in cursor3:
                                                if (data3Hide == False):
                                                    if (qtyHide and priceHide):
                                                        listbox.insert(END, d3Space + d3ForData3 + row3[0])
                                                    elif (qtyHide !=True and priceHide !=True):
                                                        listbox.insert(END, d3Space + d3ForData3 + row3[0] +pForPrice + str(row3[1]) + qForQty + str(row3[2]))    
                                                    else:
                                                        if (qtyHide):
                                                            listbox.insert(END, d3Space + d3ForData3 + row3[0] +pForPrice + str(row3[1]))
                                                        elif (priceHide):
                                                            listbox.insert(END, d3Space + d3ForData3 + row3[0] +qtySpace + str(row3[2]))
                                                        
                
                #print("totalStrokeCount=" + str(totalStrokeCount))
                #print("totalPieceCount=" + str(totalPieceCount))
                #print("strokeEndTime=" + str(strokeEndTime))
                performance = ""                
                if (cData.get('KPh') == "1"):
                    Kph = math.ceil((float(totalStrokeCount)/strokeEndTime) * 60 * 60)
                    #print("KPh=" + str(math.ceil(Kph)))
                    performance = "KPh:" + str(Kph)

                if (cData.get('PPh') == "1"):
                    Pph = math.ceil((float(totalPieceCount)/strokeEndTime) * 60 * 60)                
                    #print("PPh=" + str(math.ceil(Pph)))                
                    performance = performance + " PPh:" + str(Pph)                    

                if (performance.strip() !=""):
                    listbox.insert(END, "")
                    listbox.insert(END, performance)

            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

        if (listbox.size() > 0):
            listItemCount = listbox.size()
            listbox.selection_set(currentIndex)
            listbox.event_generate("<<ListboxSelect>>")
        #WriteToLog('Reports Form Loading Ends')

    def SelectList(self, evt):
        # Note here that Tkinter passes an event object to onselect()
        w = evt.widget
        indexs = int(w.curselection()[0])
        value = w.get(indexs)
        w.see(indexs)
        print 'You selected item %d: "%s"' % (indexs, value)        
       
    @staticmethod
    def ShowDefaultStatus():
        global lblSta2ndStatus
        lblSta2ndStatus.configure(image='')
        lblSta2ndStatus.image= ''
        #print "Default Status"

    @staticmethod
    def Show2ndStatus():
        global lblSta2ndStatus
        img = ImageTk.PhotoImage(Image.open(secondIcon))
        lblSta2ndStatus.configure(image=img)
        lblSta2ndStatus.image= img
        #print "2nd Status"

    @staticmethod
    def ChangeUpKey():
        global currentIndex, listbox
        if (currentIndex > 0):
            currentIndex = currentIndex - 1
            listbox.selection_clear(0, END)
            listbox.selection_set(currentIndex)
            listbox.event_generate("<<ListboxSelect>>")

    @staticmethod
    def ChangeDownKey():
        global currentIndex, listbox
        if (currentIndex < listItemCount-1):
            currentIndex = currentIndex + 1
            listbox.selection_clear(0, END)
            listbox.selection_set(currentIndex)
            listbox.event_generate("<<ListboxSelect>>")
        
def ShowReportForm():
    #WriteToLog("ShowReportForm Function started")
    try:
        global isReportFormShow, frmReport
        isReportFormShow = True
        #Report Form
        frmReport = tk.Toplevel()
        frmReport.title("AIM Report")
        frmReport.resizable(0, 0)
        w, h = 480, 320
        frmReport.geometry("%dx%d+0+0" % (w, h))
        frmReport.wm_attributes('-fullscreen', 'true')
        app = frmReports(frmReport)
        frmReport.mainloop()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog("ShowReportForm Function Ends")
#-------------Show the report ends here---------------------------------------------------------------------------------------------------------------------------------------------

#-------------------------Show delete popup screen ---------------------------------------------------------------------------------------------------------------------------------
class frmDeletePopups:
    @staticmethod
    def submitOK():       
        try:
            global currentId, currentPointer
            if (currentId > 0):
                AIMDatabase.Update_DRDataDeleteStatus(str(currentId), '0', str(time.strftime("%d-%m-%Y %H:%M:%S")))
                currentId = AIMDatabase.GetPreviousMaxId(str(currentId), str(DROutUnique_Id), aimLocation)
                currentPointer = AIMDatabase.GetMaxCountId(str(currentId), str(DROutUnique_Id), aimLocation)
                ShowBottomInfo()
                frmDeletePopups.submitCancel()
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

    @staticmethod
    def submitCancel():
        global isDeleteFormShow
        isDeleteFormShow = False
        frmDeletePopup.destroy()

    def __init__(self, master):
        self.master = master
        self.frame = Frame(self.master)
        self.frame.pack()

        self.frameSync = Frame(self.frame, pady=5)
        self.frameSync.pack()

        self.frame1 = Frame(self.frame, pady=5)
        self.frame1.pack()

        self.lblReady = Label(self.frame1, text ="Delete?", font=(fontName, deleteFontSize))
        self.lblReady.pack()

        self.frameButton = Frame(self.frame, pady=5)
        self.frameButton.pack()

        self.btnCancel = Button(self.frameButton, text ="Cancel", width=12, font=(fontName, deleteFontSize), command = frmDeletePopups.submitCancel) 
        self.btnCancel.bind("<Return>", lambda event:frmDeletePopups.submitCancel())
        self.btnCancel.pack(side = LEFT)

        self.btnOK = Button(self.frameButton, text ="Confirm", width=12, font=(fontName, deleteFontSize), command = frmDeletePopups.submitOK) 
        self.btnOK.bind("<Return>", lambda event:frmDeletePopups.submitOK())
        self.btnOK.pack(side = RIGHT)

def center(toplevel):
    toplevel.update_idletasks()
    w = toplevel.winfo_screenwidth()
    h = toplevel.winfo_screenheight()
    size = tuple(int(_) for _ in toplevel.geometry().split('+')[0].split('x'))
    x = w/2 - size[0]/2
    y = h/2 - size[1]/2
    toplevel.geometry("%dx%d+%d+%d" % (size + (x, y)))

def ShowDeletePopupForm():
    #WriteToLog("ShowDeletePopupForm Function started")
    try:
        global isDeleteFormShow, frmDeletePopup
        isDeleteFormShow = True
        gpio.SECOND_KEY_VALUE = 0
        ShowDefaultStatus()
        #Delete Form
        frmDeletePopup = tk.Toplevel()
        frmDeletePopup.title("Delete Confirmation")
        frmDeletePopup.resizable(0, 0)
        w, h = 400, 150
        frmDeletePopup.geometry("%dx%d+0+0" % (w, h))
        center(frmDeletePopup)
        app = frmDeletePopups(frmDeletePopup)
        frmDeletePopup.mainloop()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog("ShowReportForm Function Ends")
#-------------------------Show delete popup screen ---------------------------------------------------------------------------------------------------------------------------------

#-------------------------Show delete popup screen ---------------------------------------------------------------------------------------------------------------------------------
class frmAIMSyncPopups:
    @staticmethod
    def submitOK():       
        global isProcessing, DROutUnique_Id
        if (isProcessing == False):
            isProcessing = True
            try:
                CheckScheduleStarted()
                if (isFtpWorking):
                    if (isScheduleStarted):
                        print "Test by Hasnat"
                        #AIMDatabase.CloseOpenLocation()
                        CloseOpenLocation()
                        if (AIMDatabase.GetTotalLocationReadyForTransfer() > 0):
                            isDone = SyncService.SyncData()
                            if (isDone == "DONE" or isDone == ""):
                                DROutUnique_Id = AIMDatabase.GetScheduleGroupId(ScheduleCode) + 1
                                isProcessing = False
                                frmAIMSyncPopups.submitCancel()
                            else:
                                tkMessageBox.showinfo("Sync Error", isDone)
                        else:
                            tkMessageBox.showinfo("Sync Error", "Their is no location for data trasnsfer")
                    else:
                        tkMessageBox.showinfo("Sync Error", "Please start your schedule from base station")
                else:
                    tkMessageBox.showinfo("Sync Error", "FTP not working properly, please contact administrator")
            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
            finally:
                isProcessing = False

    @staticmethod
    def submitCancel():
        global isTransferFormShow
        if (isProcessing == False):
            isTransferFormShow = False
            frmSyncPopup.destroy()

    def __init__(self, master):
        self.master = master
        self.frame = Frame(self.master)
        self.frame.pack()

        self.frameSync = Frame(self.frame, pady=5)
        self.frameSync.pack()

        self.frame1 = Frame(self.frame, pady=5)
        self.frame1.pack()

        self.lblReady = Label(self.frame1, text ="Transmit?", font=(fontName, deleteFontSize))
        self.lblReady.pack()

        self.frameButton = Frame(self.frame, pady=5)
        self.frameButton.pack()

        self.btnCancel = Button(self.frameButton, text ="Cancel", width=12, font=(fontName, deleteFontSize), command = frmAIMSyncPopups.submitCancel) 
        self.btnCancel.bind("<Return>", lambda event:frmAIMSyncPopups.submitCancel())
        self.btnCancel.pack(side = LEFT)

        self.btnOK = Button(self.frameButton, text ="Confirm", width=12, font=(fontName, deleteFontSize), command = frmAIMSyncPopups.submitOK) 
        self.btnOK.bind("<Return>", lambda event:frmAIMSyncPopups.submitOK())
        self.btnOK.pack(side = RIGHT)

def CloseOpenLocation():
    try:
        cursorHead = AIMDatabase.GetOpenedLocation()
        for drDataHead in cursorHead:
            if (drDataHead[3].strip() !=''):
                dateTimes = str(time.strftime("%d-%m-%Y %H:%M:%S"))
                AIMDatabase.Insert_DrScheduleTrack(str(DROutUnique_Id), aimLocation, ScheduleCode)
                AIMDatabase.Insert_DrMainHead(str(DROutUnique_Id), aimLocation, ScheduleCode, str(DRId), UserId, '0', dateTimes)
                AIMDatabase.Insert_DrColumnHead(str(DROutUnique_Id), aimLocation, ScheduleCode, aimCSVHeader, str(totDataCount), '0', dateTimes)
                AIMDatabase.Update_DRDataLocationClosed(str(DROutUnique_Id), aimLocation, ScheduleCode)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
            
def CheckScheduleStarted():
    print "FTP Checking"
    global isScheduleStarted, isFtpWorking
    isScheduleStarted = False
    isFtpWorking = False
    try:                 
        countFile = 0
        ftp = FTPSync.getFTPConnection(ftpHost, ftpUser, ftpPass, statusDirName)
        if (ftp !=None):
            isFtpWorking = True
            Ftpfiles = []
            Ftpfiles = FTPSync.getListofFile(ftp)
            for f in Ftpfiles:
                countFile= countFile + 1
                try:
                    if os.path.isfile(statusDirName + f):
                        os.unlink(statusDirName + f)
                    FTPSync.downloadFile(f, statusDirName, ftp)
                except Exception as e:
                    print(e)
            print "countFile=" + str(countFile)
            ftp.quit()
        
            timeFileSource = statusDirName + drStatusConfigFileName
            if os.path.isfile(timeFileSource):
                try:
                    file = open(timeFileSource, "r") 
                    bsDate = file.read() 
                    if (bsDate.strip() !=''):
                        if (bsDate.strip() == downloadCode.strip()):
                            isScheduleStarted = True
                            print "isScheduleStarted=" + str(isScheduleStarted)
                except Exception as e:
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

def ShowTransferPopupForm():
    #WriteToLog("ShowDeletePopupForm Function started")
    try:
        global isTransferFormShow, frmSyncPopup
        isTransferFormShow = True
        gpio.SECOND_KEY_VALUE = 0
        ShowDefaultStatus()
        #Transfer Form
        frmSyncPopup = tk.Toplevel()
        frmSyncPopup.title("Syncing Confirmation")
        frmSyncPopup.resizable(0, 0)
        w, h = 400, 150
        frmSyncPopup.geometry("%dx%d+0+0" % (w, h))
        center(frmSyncPopup)
        app = frmAIMSyncPopups(frmSyncPopup)
        frmSyncPopup.mainloop()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog("ShowReportForm Function Ends")

# This is for textbox and virtual keyboard button
# --------------------------Start Here -------------------------------
class validation():
    @staticmethod
    def ExactFieldLength(fldSize, data):
        #WriteToLog('ExactFieldLength Validation Started')
        global isExactFieldLength
        isExactFieldLength = False
        try:
            if (len(data) == int(fldSize)):
                isExactFieldLength = True
            else:
                isExactFieldLength = False
            #print "isExactFieldLength = " + str(isExactFieldLength)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        #finally:
        #    WriteToLog('ExactFieldLength Validation Ended')

    @staticmethod
    def FieldLengthCheck(fldSize, data):
        #WriteToLog('FieldLengthCheck Validation Started')
        global isFieldLength
        isFieldLength = False
        try:
            print "fldSize=" + fldSize
            print "data=" + data
            if (len(data) <= int(fldSize)):
                isFieldLength = True
            else:
                isFieldLength = False
            #print "isFieldLength = " + str(isFieldLength)
        except Exception as e:
           exc_type, exc_obj, exc_tb = sys.exc_info()
           logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        #finally:
        #    WriteToLog('FieldLengthCheck Validation Ended')

    @staticmethod
    def IsNumeric(data1):
        #WriteToLog('IsNumeric Function Started')
        isValid = False
        try:
            if (float(data1)):
                isValid = True
            else:
                isValid = False
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        finally:
            #WriteToLog('IsNumeric Function Ends')
            return isValid

    @staticmethod
    def IsPositiveNumber(data1):
        #WriteToLog('IsPositiveNumber Function Started')
        isValid = False
        try:
            if (float(data1) > 0):
                isValid = True
            else:
                isValid = False
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        finally:
            #print "IsPositiveNumber = " + str(isValid)
            #WriteToLog('IsPositiveNumber Function Ends')
            return isValid

    @staticmethod
    def CheckBarcode(data):
        #WriteToLog('CheckBarcode Function Started')
        try:
            #if (len(data) == EAN13Length):
            #    isValid = validation.EAN(data)
            #elif (len(data) == UPCALength):
            #    isValid = validation.UPCA(data)
            
            if (validation.EAN(data)):
               return True
            elif (validation.UPCA(data)):
               return True
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

    @staticmethod
    def GetFinalAllowedBarcodePrefix(AllowedBarcodeType):
        #WriteToLog('GetFinalAllowedBarcodePrefix Function Starts')
        global finalAllowedBarcodePrefix
        try:
            finalAllowedBarcodePrefix = ''
            CurrAllowedBarcodeType = AllowedBarcodeType.split(',')
            prefArray = AllowedBarcodePrefix.split('~')
            typeArray = AllowedBarcodePrefixType.split('~')
            for x in range(len(CurrAllowedBarcodeType)):
                for y in range(len(typeArray)):
                    if (CurrAllowedBarcodeType[x] == typeArray[y]):
                        finalAllowedBarcodePrefix = finalAllowedBarcodePrefix + prefArray[y] + " "

            print "finalAllowedBarcodePrefix = " + finalAllowedBarcodePrefix
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        #finally:
        #    WriteToLog('GetFinalAllowedBarcodePrefix Function Starts')
            
    @staticmethod
    def BarcodePrefixValidation():
        #WriteToLog('BarcodePrefixValidation Function Starts')
        isValid = False
        try:
            if (CurrPrefix in finalAllowedBarcodePrefix):
                isValid = True
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        finally:
            #print "BarcodePrefixValidation = " + str(isValid)
            #WriteToLog('BarcodePrefixValidation Function Ends')
            return isValid

    ##UPCA validation
    @staticmethod
    def UPCA(upc_str):
        #WriteToLog('UPCA Function Starts')
        isValid = False
        try:
            if len(upc_str) != 12:
                isValid = False
                return isValid

            upc_str = str(upc_str)
            upcChecksum = upc_str.strip()[-1]
            upcMainString = upc_str.strip()[:-1]

            odd_sum = 0
            even_sum = 0
            for i, char in enumerate(upcMainString):
                j = i+1
                if (j % 2 == 0):
                    even_sum += int(char)
                else:
                    odd_sum += int(char)

            total_sum = (odd_sum * 3) + even_sum
            mod = total_sum % 10
            check_digit = 10 - mod
            if check_digit == 10:
                check_digit = 0
            
            if (str(check_digit) == upcChecksum):
                isValid = True
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        finally:
            #print "IsPositiveNumber = " + str(isValid)
            #WriteToLog('UPCA Function Ends')
            return isValid

    ##EAN 13 Validation
    @staticmethod
    def compact(number):
        """Convert the EAN to the minimal representation. This strips the number
        of any valid separators and removes surrounding whitespace."""
        print "X"
        return clean(number, ' -').strip()

    @staticmethod
    def calc_check_digit(number):
        """Calculate the EAN check digit for 13-digit numbers. The number passed
        should not have the check bit included."""
        print "Y"
        return str((10 - sum((3, 1)[i % 2] * int(n)
                                for i, n in enumerate(reversed(number)))) % 10)

    @staticmethod
    def validate(number):
        """Checks to see if the number provided is a valid EAN-13. This checks
        the length and the check bit but does not check whether a known GS1
        Prefix and company identifier are referenced."""
        number = validation.compact(number)
        if not number.isdigit():
            raise InvalidFormat()
        if len(number) not in (13, 12, 8):
            raise InvalidLength()
        if validation.calc_check_digit(number[:-1]) != number[-1]:
            raise InvalidChecksum()
        return number

    @staticmethod
    def EAN(number):
        #WriteToLog('EAN Validation Starts')
        """Checks to see if the number provided is a valid EAN-13. This checks
        the length and the check bit but does not check whether a known GS1
        Prefix and company identifier are referenced."""
        try:
            return bool(validation.validate(number))
        except ValidationError:
            return False
        #finally:
        #    WriteToLog('EAN Validation Ends')

    @staticmethod
    def ValidateDbLookup(data, flgTypes):
        #WriteToLog('ValidateDbLookup Function Starts')
        isValid = False
        global lDbLookup, pDbLookup, qDbLookup, dDbLookup
        lDbLookup = ''
        pDbLookup = ''
        qDbLookup = ''
        dDbLookup = ['','','','','','','','','','']
        try:
            if (AIMDatabase.CheckDbLookUp(data, flgTypes) > 0):
                isValid = True
            print flgTypes
            if (flgTypes == 'L'):
                lDbLookup = AIMDatabase.GetDbLookUpDescription(data, flgTypes)
                print "lDbLookup=" + lDbLookup
            elif (flgTypes == 'P'):
                print "data =" + data + " " + flgTypes
                pDbLookup = AIMDatabase.GetDbLookUpDescription(data, flgTypes)
                print "pDbLookup=" + pDbLookup
            elif (flgTypes == 'Q'):
                qDbLookup = AIMDatabase.GetDbLookUpDescription(data, flgTypes)
                print "qDbLookup=" + qDbLookup
            else:
                dataNum = flgTypes[1:]
                dDbLookup[int(dataNum)-1] = AIMDatabase.GetDbLookUpDescription(data, flgTypes)
                print " dDbLookup" + str(dataNum) + "=" + dDbLookup[int(dataNum)-1]
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        finally:
            #WriteToLog('ValidateDbLookup Function Ends')
            return isValid

    @staticmethod
    def ValidateDoubleKey(data, head):
        global PrevDoubleVal, isDoubleKeyFound, isDoubleKeyFailed
        #WriteToLog('ValidateDoubleKey Function Starts')
        isValid = False
        try:
            if (PrevDoubleVal.strip() == ''):
                PrevDoubleVal = data;
                entry.delete('1.0', END)
                lblDescText.set(head + " " + RepeatText)
            else:
                if (data.strip() == PrevDoubleVal): 
                    isValid = True
                    isDoubleKeyFound = False
                    isDoubleKeyFailed = False
                    PrevDoubleVal = ''
                else:
                    isDoubleKeyFailed = True
            
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        finally:
            #WriteToLog('ValidateDoubleKey Function Ends')
            return isValid

def RunningValidation(entryText):
    #WriteToLog('RunningValidation Function Starts')
    global isRunnningDataValidate, isDataValidate
    isRunnningDataValidate = True
    fldLength = '0'
    fldData =''
    isExactValidationFound = False
    try:
        if (len(entryText) > 0):
            fldData = entryText
            print("Running Validation currStatus=" + str(currStatus))
            if (currStatus == locationPosition):
                fldLength = cData.get('L_Fieldlength')
                if (str(cData.get('L_ExactFieldLength')).lower() == 'true'):
                    isExactValidationFound = True
            elif (currStatus == pricePosition):
                fldLength = cData.get('P_Fieldlength')
                if (str(cData.get('P_ExactFieldLength')).lower() == 'true'):
                    isExactValidationFound = True
            elif (currStatus == qtyPosition):
                GetCurrentQty(entryText)
                fldData = aimQty
                fldLength = cData.get('Q_Fieldlength')
                if (str(cData.get('Q_ExactFieldLength')).lower() == 'true'):
                    isExactValidationFound = True
            else:
                try:
                    x = len(aimDataValue)
                    print("Index=" + str(x))
                    fldLength = cData.get('I' + str(x) + '_Fieldlength')
                    print("fldLength=" + str(fldLength))
                    if (str(cData.get('I' + str(x) + '_ExactFieldLength')).lower() == 'true'):
                        isExactValidationFound = True
                    #if (cData.get('I' + str(x) + '_Fieldlength') != '0'):
                    #    isLengthValidationFound = True
                except Exception as e:
                    isExactValidationFound = False
                    #isLengthValidationFound = False
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    logging.debug(str(exc_tb.tb_lineno) + " " + e.message)                    
             
            try:          
                if (isExactValidationFound):
                    validation.ExactFieldLength(fldLength, fldData)
                    if (isExactFieldLength == False):
                        isRunnningDataValidate = False
                        return
            except Exception as e:
                    isRunnningDataValidate = False
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        #else:
        #    isRunnningDataValidate = False
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    finally:
        print "RunningValidation- isRunnningDataValidate=" + str(isRunnningDataValidate)
        isDataValidate = isRunnningDataValidate
        #WriteToLog('RunningValidation Function Ends')

def RunningLengthValidation(entryText):
    #WriteToLog('RunningLengthValidation Function Starts')
    global isRunnningDataValidate, isDataValidate
    isRunnningDataValidate = True
    fldLength = '0'
    fldData =''
    isLengthValidationFound = False
    try:
        if (len(entryText) > 0):
            fldData = entryText
            print("Running Validation currStatus=" + str(currStatus))
            if (currStatus == locationPosition):
                fldLength = cData.get('L_Fieldlength')
                if (cData.get('L_Fieldlength') != '0'):
                    isLengthValidationFound = True
            elif (currStatus == pricePosition):
                fldLength = cData.get('P_Fieldlength')
                if (cData.get('P_Fieldlength') != '0'):
                    isLengthValidationFound = True
            elif (currStatus == qtyPosition):
                GetCurrentQty(entryText)
                fldData = aimQty
                print("aimQty=" + str(aimQty))
                fldLength = cData.get('Q_Fieldlength')
                print("fldLength=" + str(fldLength))
                if (cData.get('Q_Fieldlength') != '0'):
                    isLengthValidationFound = True
            else:
                try:
                    x = len(aimDataValue)
                    #print("Index=" + str(x))
                    fldLength = cData.get('I' + str(x) + '_Fieldlength')
                    #print("fldLength=" + str(fldLength))
                    if (cData.get('I' + str(x) + '_Fieldlength') != '0'):
                        isLengthValidationFound = True
                except Exception as e:
                    isLengthValidationFound = False
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

            try:
                if (isLengthValidationFound):
                    validation.FieldLengthCheck(fldLength, fldData)
                    if (isFieldLength == False):
                        isRunnningDataValidate = False
                        return 
            except Exception as e:
                    isRunnningDataValidate = False
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        #else:
        #    isRunnningDataValidate = False
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    finally:
        print "RunningLengthValidation- isRunnningDataValidate=" + str(isRunnningDataValidate)
        isDataValidate = isRunnningDataValidate
        #WriteToLog('RunningValidation Function Ends')

def DataValidation(entryText):
    #WriteToLog('DataValidation Function Starts')
    global isDoubleKeyFound
    global isDataValidate
    isDoubleKeyFound =  False
    isDataValidate = True
    try:        
        if (len(entryText) > 0):
            print("Validation currStatus=" + str(currStatus))
            if (currStatus == locationPosition):                
                if 'L_BarCode' in cData:
                    if (cData.get('L_BarCode') != 'None'):
                        if (srcBluetooth == False):                            
                            if (validation.CheckBarcode(entryText) == False):
                                isDataValidate = False
                                AIMDatabase.Insert_DrLog("L." + entryText)
                                return

                if (str(cData.get('L_DoubleKey')).lower() == 'true'):
                    isDoubleKeyFound = True
                    if (validation.ValidateDoubleKey(entryText,  cData.get('L_Description')) == False):
                        isDataValidate = False
                        return

                if (str(cData.get('L_DbLookup')).lower() == 'true'):
                    if (validation.ValidateDbLookup(entryText, 'L') == False):
                        isDataValidate = False
                        return

                print "Location Validation"
            elif (currStatus == pricePosition):
                if 'P_BarCode' in cData:
                    if (cData.get('P_BarCode') != 'None'):
                        if (srcBluetooth == False):                            
                            if (validation.CheckBarcode(entryText) == False):
                                isDataValidate = False
                                AIMDatabase.Insert_DrLog("P." + entryText)
                                return

                if (str(cData.get('P_DoubleKey')).lower() == 'true'):
                    isDoubleKeyFound = True
                    if (validation.ValidateDoubleKey(entryText,  cData.get('P_Description')) == False):
                        isDataValidate = False
                        return

                if (str(cData.get('P_DbLookup')).lower() == 'true'):
                    if (validation.ValidateDbLookup(entryText, 'P') == False):
                        isDataValidate = False
                        return

                print "Price Validation"
            elif (currStatus == qtyPosition):
                GetCurrentQty(entryText)            
                if 'Q_BarCode' in cData:
                    if (cData.get('Q_BarCode') != 'None'):
                        if (srcBluetooth == False):                            
                            if (validation.CheckBarcode(aimQty) == False):
                                isDataValidate = False
                                AIMDatabase.Insert_DrLog("Q." + entryText)
                                return

                if (str(cData.get('Q_DbLookup')).lower() == 'true'):
                    if (validation.ValidateDbLookup(aimQty, 'Q') == False):
                        isDataValidate = False
                        return

                print "Qty Validation"
            else:
                x = len(aimDataValue)               
                if ('I' + str(x) + '_BarCode') in cData:
                    if (('I' + str(x) + '_BarCode') != 'None'):
                        if (srcBluetooth == False):                            
                            if (validation.CheckBarcode(entryText) == False):
                                isDataValidate = False
                                AIMDatabase.Insert_DrLog("D." + entryText)
                                return

                if (str(cData.get('I' + str(x) + '_DoubleKey')).lower() == 'true'):
                    isDoubleKeyFound = True
                    if (validation.ValidateDoubleKey(entryText, cData.get('I' + str(x) + '_Description')) == False):
                        isDataValidate = False
                        return

                if (str(cData.get('I' + str(x) + '_DbLookup')).lower() == 'true'):
                    if (validation.ValidateDbLookup(entryText, 'D'+str(x+1)) == False):
                        isDataValidate = False
                        return
               
                print "Data Validation"
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog('DataValidation Function Starts')

class ReadXMLData():
    @staticmethod
    def ReadAdminConfigData():
        #WriteToLog('ReadAdminConfigData Function Starts')
        global ftpHost, ftpHost1, ftpPass, ftpPass1, ftpUser, ftpUser1, ftpRemoteDir, autoSync, autoLocationNumSync, ReviewName
       
        try:
            cData = XMLReader.ReadAdminConfigData()
            if (len(cData) > 0):
                ftpHost = cData.get('FTP_Host')
                ftpHost1 = cData.get('FTP1_Host')

                ftpUser = cData.get('FTP_User')
                ftpUser1 = cData.get('FTP1_User')

                ftpPass = cData.get('FTP_Pass')
                ftpPass1 = cData.get('FTP1_Pass')

                ftpRemoteDir = cData.get('FTP_DrData')

                
                if (cData.get('ManualSync') == "1"):
                    autoSync = True
                else:
                    autoSync = False
                autoLocationNumSync = int(cData.get('XNumSync'))

                ReviewName = cData.get('ReviewName')
                if (ReviewName == ''):
                    ReviewName = "Reviewing";
                #print "ftpHost=" + ftpHost
                #print "ftpHost1=" + ftpHost1
                #print "ftpUser=" + ftpUser
                #print "ftpUser1=" + ftpUser1
                #print "ftpPass=" + ftpPass
                #print "ftpPass1=" + ftpPass1
                #print "ftpRemoteDir=" + ftpRemoteDir
                #print "autoSync=" + str(autoSync)
                #print "autoLocationNumSync=" + str(autoLocationNumSync)
                print "ReviewName=" + ReviewName
        except Exception as e:
           exc_type, exc_obj, exc_tb = sys.exc_info()
           logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        #finally:
        #    WriteToLog('ReadAdminConfigData Function Ends')

    @staticmethod
    def ReadConfigData():
        #WriteToLog('ReadConfigData Function Starts')
        dFiles = []
        global cData, totDataCount, totLoopCount, aimCSVHeader, pricePosition, qtyPosition, startLocation, endLocation, isAutoPriceFound, downloadCode
        try:
            cData = XMLReader.ReadDRConfigData()
            if (len(cData) > 0):
                totDataCount = int(cData.get('I_RowCount')) 
                pricePosition = totDataCount + 1
                qtyPosition = totDataCount + 2
                totLoopCount = totDataCount + 3
                
                #print "totDataCount=" + str(totDataCount)
                #print "totLoopCount=" + str(totLoopCount)
                aimTmpCSVHeader = ''
                if (totDataCount > 0):
                    for x in range(totDataCount):
                        aimTmpCSVHeader = aimTmpCSVHeader + 'Data' + str(x+1) + ","
                    aimCSVHeader = "Location" + "," +  aimTmpCSVHeader + "Price" + "," + "Qty"
                else:
                    aimCSVHeader = Location + "," + "Price" + "," + "Qty"

                GetLoopBackFieldNo(cData.get('LoopBack'))

                print cData.get('StoreName')
                print cData.get('DownloadCode')
                downloadCode = cData.get('DownloadCode')

                downIdText.set(downloadCode)
                stoNameText.set(cData.get('StoreName'))

                if (cData.get('P_DefaultPrice') == "0" or cData.get('P_DefaultPrice') == "0.00"):
                    isAutoPriceFound = True
                print "isAutoPriceFound=" + str(isAutoPriceFound)
                try:
                    startLocation = float(cData.get('Q_StartLocation'))
                    endLocation = float(cData.get('Q_EndLocation'))                    
                except Exception as e:
                   exc_type, exc_obj, exc_tb = sys.exc_info()
                   logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        #finally:
        #    WriteToLog('ReadConfigData Function Ends')

def GetLoopBackFieldNo(looPBackText):
    #WriteToLog('GetLoopBackFieldNo Function Starts')
    global loopBackNo, isDataLoopBak
    loopBackNo = totDataCount + 1
    try:
        if (looPBackText.strip() != ''):
            loopArray = []
            loopArray = looPBackText.split('_')
            if (len(loopArray) > 0):
                if (loopArray[0] == "Location"):
                    loopBackNo = 0
                elif (loopArray[0] == "Qty"):
                    loopBackNo = totDataCount + 2
                elif (loopArray[0] == "Data"):
                    for x in range(totDataCount):
                        if (loopArray[1] == cData.get('I' + str(x) + '_Description')):
                            loopBackNo = x + 1
                            isDataLoopBak = True
                            break;
    except Exception as e:
       exc_type, exc_obj, exc_tb = sys.exc_info()
       logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    finally:
        print "loopBackNo=" + str(loopBackNo)
        #WriteToLog('GetLoopBackFieldNo Function Ends')
        
def AddHeaderToDB():
    #WriteToLog('AddHeaderToDB Function Starts')
    try:
        global aimCSVHeader, aimCSVValue, DROutUnique_Id, ScheduleCode, DRId, UserId, fileName, totDataCount, aimConcatDataValue, aimLocation, aimFinalValue
        aimCSVValue = ''

        if (aimCSVHeader.strip() != ''): 
            dateTimes = str(time.strftime("%d-%m-%Y %H:%M:%S"))
            AIMDatabase.Insert_DrScheduleTrack(str(DROutUnique_Id), aimLocation, ScheduleCode)
            AIMDatabase.Insert_DrMainHead(str(DROutUnique_Id), aimLocation, ScheduleCode, str(DRId), UserId, '0', dateTimes) 
            AIMDatabase.Insert_DrColumnHead(str(DROutUnique_Id), aimLocation, ScheduleCode, aimCSVHeader, str(totDataCount), '0', dateTimes)
            AIMDatabase.Update_DRDataLocationClosed(str(DROutUnique_Id), aimLocation, ScheduleCode)
        
            if (autoSync):
                totLocationReadyForSync = AIMDatabase.GetTotalLocationReadyForSync()
                print("totLocationReadyForSync" + str(totLocationReadyForSync))
                if (autoLocationNumSync <= totLocationReadyForSync):
                    #os.system("python AIMSyncPopup.py")
                    ShowTransferPopupForm()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog('AddHeaderToDB Function Ends')

def StartOverDoubleKey():
    #WriteToLog('StartOverDoubleKey Function Starts')
    print "StartOverDoubleKey"
    try:     
        global PrevDoubleVal, isDoubleKeyFailed, CurrentHeadDescription
        entry.config(state='normal')
        entry.delete('1.0', END)
        pos = entry.index(INSERT)
        currDesc = lblDescText.get()
        if (currDesc.find(RepeatText) > 0):
            CurrentHeadDescription = currDesc[:-len(RepeatText)].strip()
            lblDescText.set(CurrentHeadDescription)
        else:
            CurrentHeadDescription = currDesc
            lblDescText.set(CurrentHeadDescription)
        PrevDoubleVal = ''
        isDoubleKeyFailed = False
        SetEntryColor(2)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog('StartOverDoubleKey Function Ends')

def SetEntryColor(types):
    if (types == 1):
        if (isDoubleKeyFound and isDoubleKeyFailed == False and isRunnningDataValidate):
            entry.config(state='normal')
            entry.config(background='yellow')
            entry.config(foreground='black')
        else:
            entry.config(state='disabled')
            entry.config(background='red')
            entry.config(foreground='white')
    else:
        entry.config(state='normal')
        entry.config(background='white')
        entry.config(foreground='black')
        
def PlaySounds(types):
    #WriteToLog("PlaySounds Function started")
    try:
        if (types==1):
            SetEntryColor(1)
            if (isPlaySound):
                if (isDoubleKeyFound and isDoubleKeyFailed == False and isRunnningDataValidate):
                    print "Failed"
                else:
                    #subprocess.Popen(["aplay", badSoundFile])
                    #thread = Thread(target = gpioBeefSound, args=(types, ))
                    #thread.start()
                    #buzzer = Buzzer()
                    thread = Thread(target=buzzer.play, args=(4, ))
                    thread.start()
        else:
            SetEntryColor(2)
            if (isPlaySound):
                entry.config(state='normal')
                #subprocess.Popen(["aplay", goodSoundFile])
                #thread = Thread(target = gpioBeefSound, args=(types, ))
                #thread.start()
                #buzzer = Buzzer()
                thread = Thread(target =  buzzer.play, args=(5, ))
                thread.start()
    except Exception as e:
       exc_type, exc_obj, exc_tb = sys.exc_info()
       logging.debug(str(exc_tb.tb_lineno) + " " + e.message) 
    #finally:
    #    WriteToLog("PlaySounds Function Ends")

def GetCurrentQty(entryText):
    try:
        #WriteToLog("GetCurrentQty Function started")
        global aimQty    
        aimQtyArray = []
        aimQtyArray1 = []
        aimQtyArray1 = entryText.split(' = ')
        if (len(aimQtyArray1) > 1):
            aimQtyArray = aimQtyArray1[1].split(' + ')           
            aimQty = aimQtyArray[0]
        else:
            aimQty = entryText

        aimQty = aimQty.replace('+', '').strip()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog("GetCurrentQty Function Ends")

def CheckingEscCombination(value):
    global EscKeyCount, PrevEscValue
    try:
        clKey = "ESC"
        if value == clKey and PrevEscValue == clKey:
            EscKeyCount = 2
        else:
            EscKeyCount = 0
            PrevEscValue = value
        print str(EscKeyCount)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

def ShowReviewHeader():
    if (isReviewing):
        entry.config(state='disabled')
        lblDesc.configure(bg='green')
        lblDesc.configure(foreground='white')
        lblDescText.set(ReviewName)
    else:
        entry.config(state='normal')
        lblDesc.configure(bg='#F0F0F0')
        lblDesc.configure(foreground='black')
        lblDescText.set(CurrentHeadDescription)
    
def select(value):
    try:
        print value
        global srcInput, srcBluetooth, DoubleEnterCount, isRunningTotFound, isLocationChangeKeyFound, totAimQtyDesc, isJumpKeyFound, currLoopPosition, isRevFormShow
        global totAimQty, runningAimQtyDesc, currentId, currentPointer, totRecord, isRunnningDataValidate, isReportFormShow, ReportKey, isDataValidate, isReviewing
        global IsVKShow, isLowerVKShow, isCounterEnable, currentIndex

        CheckingEscCombination(value)
        if (EscKeyCount == 2):
            print "Esc key Found"
        lengthText = len(entry.get("1.0", "end-1c").strip())
        if (srcBluetooth == False):
            srcInput = True

        #print("srcInput=" + str(srcInput))
        #print("srcBluetooth=" + str(srcBluetooth))

        if value == "DEL":
            if (isDataValidate):
                #if (currentId > 0):
                #    AIMDatabase.Update_DRDataDeleteStatus(str(currentId), '0', str(time.strftime("%d-%m-%Y %H:%M:%S")))
                #    currentId = AIMDatabase.GetPreviousMaxId(str(currentId), str(DROutUnique_Id), aimLocation)
                #    currentPointer = AIMDatabase.GetMaxCountId(str(currentId), str(DROutUnique_Id), aimLocation)
                #    ShowBottomInfo()
                ShowDeletePopupForm()
        elif (value == "ESC") :
            if (isReportFormShow):
                isReportFormShow = False
                isCounterEnable = True
                frmReport.destroy()                
            elif (isDeleteFormShow):
                frmDeletePopups.submitCancel()
            elif (isTransferFormShow):
                frmAIMSyncPopups.submitCancel()
            else:
                entry.config(state='normal')
                isDataValidate = True
                isRunnningDataValidate = True
                if (isReviewing):
                    isReviewing = False
                    ShowReviewHeader()
                    currentId = AIMDatabase.GetDrDataMaxId(str(DROutUnique_Id), aimLocation)
                    currentPointer = AIMDatabase.GetMaxCountId(str(currentId), str(DROutUnique_Id), aimLocation)                    
                    ShowBottomInfo()
                    gpio.SECOND_KEY_VALUE = 0
                    ShowDefaultStatus()
                elif (isJumpKeyFound):
                    currLoopPosition = currLoopPosition - 1
                    LoopLogic()
                    isJumpKeyFound = False
                    lblDesc.configure(bg='#F0F0F0')
                    totAimQty = 0
                    totAimQtyDesc = ''
                    runningAimQtyDesc = ''
                elif(isDoubleKeyFound):                   
                    StartOverDoubleKey()
                else:
                    if (currStatus == qtyPosition) and (EscKeyCount == 0):
                        entry.delete('1.0', END)
                        pos = entry.index(INSERT)
                        entry.insert(pos, str(totAimQtyDesc))
                        SetQtyPosition()
                    else:
                        entry.delete('1.0', END)
                        totAimQty = 0
                        totAimQtyDesc = ''
                        runningAimQtyDesc = ''

                    if (isRunnningDataValidate):                       
                        EscKey()

                        if (isLocationChangeKeyFound):
                            LocationKeyConfirmResult(value)

                #PlaySounds(2)
                SetEntryColor(2)                
                #entry.config(state='normal')
                DynamicResizeFontSize()
                srcBluetooth = False
                srcInput = False
            gpio.SECOND_KEY_VALUE = 0
            ShowDefaultStatus()
        elif (value == "<-" or value == "LEFT"):
            if (isDataValidate):
                if (currentPointer > 0):
                    isReviewing = True;
                    ShowReviewHeader()
                    currentId = AIMDatabase.GetPreviousMaxId(str(currentId), str(DROutUnique_Id), aimLocation)
                    currentPointer = AIMDatabase.GetMaxCountId(str(currentId), str(DROutUnique_Id), aimLocation)
                    ShowBottomInfo()
        elif (value == "->" or value == "RIGHT"):
            if (isDataValidate):
                if (currentPointer < totRecord):
                    isReviewing = True;
                    ShowReviewHeader()
                    currentId = AIMDatabase.GetNextMaxId(str(currentId), str(DROutUnique_Id), aimLocation)
                    currentPointer = AIMDatabase.GetMaxCountId(str(currentId), str(DROutUnique_Id), aimLocation)
                    ShowBottomInfo()
        elif (value == "|<-" or value == "UP"):
            if (isReportFormShow) :
               frmReports.ChangeUpKey()
            elif (IsVKShow == False):
                IsVKShow = True
                frameBottom.pack_forget()
                frameLowerButton.pack_forget()
                frameButton.pack()
                gpio.SECOND_KEY_VALUE = 0
                ShowDefaultStatus()
        elif (value == "->|" or value == "DOWN" or value == "HIDE"):
            if (isReportFormShow) :
               frmReports.ChangeDownKey() 
            elif (IsVKShow):
                IsVKShow = False
                frameButton.pack_forget()
                frameLowerButton.pack_forget()
                frameBottom.pack(fill='x')
                gpio.SECOND_KEY_VALUE = 0
                ShowDefaultStatus()
        elif (value == "CAP"):
            if (IsVKShow):
                if (isLowerVKShow):
                    isLowerVKShow = False
                    frameLowerButton.pack_forget()
                    frameBottom.pack_forget()
                    frameButton.pack()
                else:
                    isLowerVKShow = True
                    frameButton.pack_forget()
                    frameBottom.pack_forget()
                    frameLowerButton.pack()
        elif (value == "NEX" or value == "F1" or value == "F3"):
            print value
        elif (value == "ST"):
            if (isDataValidate):
                if (isReportFormShow == False):
                    ReportKey = value
                    isCounterEnable = False
                    ShowReportForm()
        elif (value == "GT"):
            if (isDataValidate):
                if (isReportFormShow == False):
                    ReportKey = value
                    ShowReportForm()
        elif (value == "TR"):
            if (isDataValidate):
                #os.system("python AIMSyncPopup.py")
                ShowTransferPopupForm()
        elif value == "2nd1":
            if (isReportFormShow):
                frmReports.Show2ndStatus()
            else:
                Show2ndStatus()
        elif value == "2nd2":
            if (isReportFormShow):
                frmReports.ShowDefaultStatus()
            else:
                ShowDefaultStatus()
        elif (value == "HID" or value == "REV"):
            if (isDataValidate):
                if (isRevFormShow == False):
                    gpio.SECOND_KEY_VALUE = 0
                    ShowDefaultStatus()
                    os.system("python AIMReview.py")
        elif value == "CLO":
            if (isDataValidate):
                if (isReportFormShow):
                    isReportFormShow = False
                    isCounterEnable = True
                    frmReport.destroy()                    
                elif (isReviewing):
                    isReviewing = False
                    ShowReviewHeader()
                    currentId = AIMDatabase.GetDrDataMaxId(str(DROutUnique_Id), aimLocation)
                    currentPointer = AIMDatabase.GetMaxCountId(str(currentId), str(DROutUnique_Id), aimLocation)
                    ShowBottomInfo()
                gpio.SECOND_KEY_VALUE = 0
                ShowDefaultStatus()
                #if (IsDeveloperMode):
                #    os._exit(1)
        elif value == "ENTER" or value == "F2":
            if (isDeleteFormShow):
                frmDeletePopups.submitOK()
            elif (isTransferFormShow):
                frmAIMSyncPopups.submitOK()
            elif (isDataValidate):
                if (srcInput):
                    confirm()
        elif value == "SPACE":
            pos = entry.index(INSERT)
            entry.insert(pos, " ")
        else:
            if (srcInput):
                if ((currStatus == qtyPosition) & (DoubleEnterCount > 0)):
                    DoubleEnterCount = DoubleEnterCount - 1
                    print "DoubleEnterCount1=" + str(DoubleEnterCount)
                if (isRunningTotFound):
                    isRunningTotFound = False
                
                pos = entry.index(INSERT)
                entry.insert(pos, value)

                RunningLengthValidation(entry.get("1.0", "end-1c").strip())

                if (isLocationChangeKeyFound):
                    if (value == "1"):
                        LocationKeyConfirmResult(value)
                    else:
                        entry.delete('1.0', END)

                if (isJumpKeyFound):
                    newVal = int(value)
                    if (newVal > 0 and newVal <= maxJumpKey):
                        EscKeyResult(value)
                    else:
                        entry.delete('1.0', END)
                        
                DynamicResizeFontSize()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

def DynamicResizeFontSize():
    try:
        lengthText = len(entry.get("1.0", "end-1c").strip())
        #print("lengthText=" + str(lengthText))

        if (lengthText > 17 and lengthText <= 24):
            entry.config(font=((fontName, 25)))
            entry.config(height=1)
        elif (lengthText > 24):
            entry.config(font=((fontName, 25)))
            entry.config(height=2)
        else:
            entry.config(font=((fontName, entryDefFontSize)))
            entry.config(height=1)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    
def onKeyPress(event=None):
    #print 'You press %s\n' % (event.char, )
    global srcInput, srcBluetooth
    if (srcInput ==False):
        srcBluetooth = True
    else:
        return 'break'
    DynamicResizeFontSize()

def EscKey():
    #WriteToLog("EscKey Function started")
    try:
        global isJumpKeyFound, maxJumpKey, EscKeyCount, CurrentHeadDescription
        if (EscKeyCount == 2):
            jumpString = "1=" + cData.get('L_Description')
            endString = ",ESC=Cancel"
            dataString = ""   
            if (totDataCount > 0):
                for x in range(totDataCount):
                    dataString = dataString + ","+ str(x+2) + "=" + cData.get('I' + str(x) + '_Description')

            if (currStatus > locationPosition):
                isJumpKeyFound = True
                lblDesc.configure(bg='yellow')
                if (currStatus == pricePosition):
                    CurrentHeadDescription = jumpString + dataString + endString
                    lblDescText.set(CurrentHeadDescription)
                    maxJumpKey = pricePosition
                elif (currStatus == qtyPosition):  
                    if (isAutoPriceFound == False):
                        CurrentHeadDescription = jumpString + dataString + "," + str(qtyPosition) + "=" + cData.get('P_Description')  + endString
                        lblDescText.set(CurrentHeadDescription)
                    else:
                        CurrentHeadDescription = jumpString + dataString + endString
                        lblDescText.set(CurrentHeadDescription)
                    maxJumpKey = qtyPosition
                else:
                    dataString = ""
                    for x in range(totDataCount):
                        if (x == currLoopPosition-1):
                            break
                        else:
                            dataString = dataString + ","+ str(x+2) + "=" + cData.get('I' + str(x) + '_Description')
                            maxJumpKey = x+2
                    CurrentHeadDescription = jumpString + dataString + endString
                    lblDescText.set(CurrentHeadDescription)
            ShowBottomInfo()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog("EscKey Function Ends")
                
def EscKeyResult(keyVal):
    #WriteToLog("EscKeyResult Function started")
    global srcInput, srcBluetooth
    try:
        global EscKeyCount, currLoopPosition, isJumpKeyFound, aimDataValue, DROutUnique_Id, totAimQtyDesc, runningAimQtyDesc, isLocationChangeKeyFound, totAimQty, CurrentHeadDescription        
        #print("EscKeyResult Called")
        #---- Choice key for jump in any position
        if (keyVal == str(locationPosition+1)):
            isLocationChangeKeyFound = True
            isJumpKeyFound = False
            CurrentHeadDescription = "1= Yes, ESC= No"
            lblDescText.set(CurrentHeadDescription)
            entry.delete('1.0', END)
        elif (keyVal == str(pricePosition+1)):
            currLoopPosition = pricePosition-1
            lblDesc.configure(bg='#F0F0F0')
            entry.delete('1.0', END)
            EscKeyCount = 0
            totAimQty = 0
            totAimQtyDesc = ''
            runningAimQtyDesc = ''
            LoopLogic()
            isJumpKeyFound = False            
        elif (keyVal == str(qtyPosition+1)):
            currLoopPosition = qtyPosition-1
            lblDesc.configure(bg='#F0F0F0')
            entry.delete('1.0', END)
            EscKeyCount = 0
            totAimQty = 0
            totAimQtyDesc = ''
            runningAimQtyDesc = ''
            LoopLogic()
            isJumpKeyFound = False            
        else:
            for x in range(totDataCount):
                if (keyVal == str(x+2)):
                    currLoopPosition = x
                    break;

            if (currLoopPosition == locationPosition):
                aimDataValue = []
            else:
                for i in range(currLoopPosition, len(aimDataValue)):
                    try:
                        del aimDataValue[currLoopPosition]
                    except Exception as e:
                        exc_type, exc_obj, exc_tb = sys.exc_info()
                        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
                
        
            lblDesc.configure(bg='#F0F0F0')
            entry.delete('1.0', END)
            EscKeyCount = 0
            totAimQty = 0
            totAimQtyDesc = ''
            runningAimQtyDesc = ''
            LoopLogic()
            isJumpKeyFound = False
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    finally:
        #WriteToLog("EscKeyResult Function Ends")
        srcInput = False
        srcBluetooth = False
        ShowBottomInfo()        
    
def LocationKeyConfirmResult(keyVal):
    #WriteToLog("LocationKeyConfirmResult Function started")
    try:
        global EscKeyCount, currLoopPosition, isJumpKeyFound, isLocationChangeKeyFound, aimDataValue, DROutUnique_Id, totAimQtyDesc, runningAimQtyDesc, srcBluetooth, srcInput, aimLocation, currentPointer, aimPrice, aimQty

        if (keyVal == "1"):
            #Location is closed
            AddHeaderToDB()
            currentPointer = 0
            aimLocation = '0'
            aimQty = '0'
            aimPrice = '0'
            CheckAndSetGroupId()
            totAimQty = 0
            totAimQtyDesc = ''
            runningAimQtyDesc = ''
            currLoopPosition = -1
            EscKeyCount = 0
            aimDataValue = []
            LoopLogic()
            isLocationChangeKeyFound = False
            lblDesc.configure(bg='#F0F0F0')
            entry.delete('1.0', END)            
            lblCountText.set("")
            lblHeadText.set("")
            lblValueText.set("")
            ShowBottomInfo()
            srcBluetooth = False
            srcInput = False
        elif (keyVal == "ESC"):
            #Back to state where it was
            currLoopPosition = currLoopPosition -1
            LoopLogic()
            isJumpKeyFound = False
            isLocationChangeKeyFound = False
            EscKeyCount = 0
            lblDesc.configure(bg='#F0F0F0')
            entry.delete('1.0', END)
            if (currStatus == qtyPosition):
                pos = entry.index(INSERT)
                entry.insert(pos, str(totAimQtyDesc))

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog('LocationKeyConfirmResult Function Ends')
 
def confirm(event=None):
    #WriteToLog("confirm Function started")
    try:
        global counter, srcInput, srcBluetooth, DoubleEnterCount
        if (entry.get("1.0", "end-1c").strip() !=""):
            RunningValidation(entry.get("1.0", "end-1c").strip())
            if (isRunnningDataValidate):
                if ((currStatus == qtyPosition) & (DoubleEnterCount < 2)):
                    DoubleEnterCount= DoubleEnterCount + 1
                    print "DoubleEnterCount2=" + str(DoubleEnterCount)
                SaveData()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog('confirm Function Ends')

def RemoveAlphaText(entryText):
    #WriteToLog("RemoveAlphaText Function started")
    global CurrPrefix
    try:
        if (entryText[:1].isalpha()):
            CurrPrefix = entryText[:1]
            entry.delete('1.0', END)
            pos = entry.index(INSERT)
            entry.insert(pos, str(entryText[1:]))
            DynamicResizeFontSize()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog('RemoveAlphaText Function Ends')

def CheckPrefixAllowed(entryText):
     isPrefixAllowed = True
     try:   
         if (currStatus == locationPosition):   
            validation.GetFinalAllowedBarcodePrefix(cData.get('L_BarCode'))
            if (validation.BarcodePrefixValidation()== False):
                isPrefixAllowed = False
                AIMDatabase.Insert_DrLog("L." + entryText)
         elif (currStatus == pricePosition):
            validation.GetFinalAllowedBarcodePrefix(cData.get('P_BarCode'))
            if (validation.BarcodePrefixValidation()== False):
                isPrefixAllowed = False
                AIMDatabase.Insert_DrLog("P." + entryText)
         elif (currStatus == qtyPosition):
            validation.GetFinalAllowedBarcodePrefix(cData.get('Q_BarCode'))
            if (validation.BarcodePrefixValidation()== False):
                isPrefixAllowed = False
                AIMDatabase.Insert_DrLog("Q." + entryText)
         else:
            x = len(aimDataValue)
            validation.GetFinalAllowedBarcodePrefix(cData.get('I' + str(x) + '_BarCode'))
            if (validation.BarcodePrefixValidation()== False):
                isPrefixAllowed = False
                AIMDatabase.Insert_DrLog("D." + entryText)
     except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
     finally:
        return isPrefixAllowed

def CheckScannerAllowed():
    #WriteToLog('CheckScannerAllowed Function Starts')
    isScannerAllowed = False
    try:
        if (currStatus == locationPosition):
            if 'L_BarCode' in cData:
                if (cData.get('L_BarCode') != 'None'):
                    isScannerAllowed = True
        elif (currStatus == pricePosition):
             if 'P_BarCode' in cData:
                if (cData.get('P_BarCode') != 'None'):
                    isScannerAllowed = True
        elif (currStatus == qtyPosition):
            if 'Q_BarCode' in cData:
                if (cData.get('Q_BarCode') != 'None'):
                    isScannerAllowed = True
        else:
            try:
                k = len(aimDataValue)
                if ('I' + str(k) + '_BarCode') in cData:
                    if (('I' + str(k) + '_BarCode') != 'None'):
                        isScannerAllowed = True
            except:
                pass
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    finally:
        #WriteToLog('CheckScannerAllowed Function Ends')
        return isScannerAllowed

def scannerConfirm(event=None):
    #WriteToLog("scannerConfirm Function started")
    try:
        global counter, srcInput, srcBluetooth, DoubleEnterCount, isDataValidate, EscKeyCount, PrevEscValue
        EscKeyCount = 0
        PrevEscValue = ''
        if (CheckScannerAllowed()):
            entryText = entry.get("1.0", "end-1c").strip()
            RemoveAlphaText(entryText)
            if (srcBluetooth == True):
                entryText = entry.get("1.0", "end-1c").strip()
                if (CheckPrefixAllowed(entryText)):
                    #RunningValidation(entryText)
                    #if (isRunnningDataValidate):
                    #    SaveData()
                    #else:
                    #    PlaySounds(1)
                    #    return 'break'
                    SaveData()
                else:
                    #print "1"
                    #PlaySounds(1)
                    isDataValidate = False
                    return 'break'
            else:
                if ((currStatus == qtyPosition) & (DoubleEnterCount < 2)):
                    entryText = entry.get("1.0", "end-1c").strip()
                    if (len(entryText) > 0):
                        DoubleEnterCount = DoubleEnterCount + 1
                        print "DoubleEnterCount3=" + str(DoubleEnterCount)

                if (DoubleEnterCount == 2):
                    SaveData()
                else:
                    return 'break'
        else:
           entry.delete('1.0', END) 
           pos = entry.index(INSERT)
           entry.insert(pos, "Scanner Not Allowed")
           DynamicResizeFontSize()
           #print "2"
           #PlaySounds(1)
           isDataValidate = False
           return 'break'

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog('scannerConfirm Function Ends')

def ShowBottomInfo():
    #WriteToLog("ShowBottomInfo Function started")
    try:
        global totRecord
        lblColHeadText = ''
        lblColValueText = ''
        lrDbLookup = ''
        prDbLookup = ''
        qrDbLookup = ''
        drDbLookup = ''
        totRecord = AIMDatabase.GetTotalRecord(str(DROutUnique_Id), aimLocation)
        if (totRecord > 0):
            print "Hasnat1"
            cursor = AIMDatabase.Select_DRDataById(str(DROutUnique_Id), aimLocation, str(currentId))
            for row in cursor:
                lblCountText.set(str(currentPointer) + " of " + str(totRecord))
                #lblColHeadText = cData.get('L_Description') + ":\n"
                lblColHeadText = "L" + ":\n"
                lblColValueText = row[0] + "\n"
                lrDbLookup = AIMDatabase.GetDbLookUpDescription(row[0], "L")
                if (lrDbLookup.strip() !=""):
                    lblColHeadText = lblColHeadText + "\n"
                    lblColValueText = lblColValueText + lrDbLookup + "\n"

                for x in range(totDataCount):            
                    if (row[x+1].strip() !=''):
                        #lblColHeadText = lblColHeadText + cData.get('I' + str(x) + '_Description')  + ":\n"
                        lblColHeadText = lblColHeadText + "D" + str(x+1) + ":\n"
                        lblColValueText = lblColValueText + row[x+1] + "\n"
                        drDbLookup = AIMDatabase.GetDbLookUpDescription(row[x+1], "D" + str(x+1))
                        if (drDbLookup.strip() !=""):
                            lblColHeadText = lblColHeadText + "\n"
                            lblColValueText = lblColValueText + drDbLookup + "\n"
        
                if (isAutoPriceFound == False):
                    #lblColHeadText = lblColHeadText + cData.get('P_Description') + ":\n"
                    lblColHeadText = lblColHeadText + "P" + ":\n"
                    lblColValueText = lblColValueText + row[11] + "\n"
                    print "Price=" + str(str(row[11]).partition('.')[0])
                    prDbLookup = AIMDatabase.GetDbLookUpDescription(str(str(row[11]).partition('.')[0]), "P")
                    if (prDbLookup.strip() !=""):
                        lblColHeadText = lblColHeadText + "\n"
                        lblColValueText = lblColValueText + prDbLookup + "\n"

                if (isAutoQtyFound == False):
                    #lblColHeadText = lblColHeadText + cData.get('Q_Description') + ":\n"
                    lblColHeadText = lblColHeadText + "Q" + ":\n"
                    lblColValueText = lblColValueText + row[12] + "\n"
                    qrDbLookup = AIMDatabase.GetDbLookUpDescription(row[12], "Q")
                    if (qrDbLookup.strip() !=""):
                        lblColHeadText = lblColHeadText + "\n"
                        lblColValueText = lblColValueText + qrDbLookup + "\n"

                lblHeadText.set(lblColHeadText)
                lblValueText.set(lblColValueText)
        else:            
            lblCountText.set("")
            if (aimLocation.strip() !="0"):
                print "Hasnat3"
                lblColHeadText = "L" + ":\n"
                lblColValueText = aimLocation + "\n"
                lrDbLookup = AIMDatabase.GetDbLookUpDescription(aimLocation, "L")
                if (lrDbLookup.strip() !=""):
                    lblColHeadText = lblColHeadText + "\n"
                    lblColValueText = lblColValueText + lrDbLookup + "\n"
                
                if (totDataCount > 0):
                    if (len(aimDataValue) > 0):
                        for x in range(totDataCount):            
                            if (aimDataValue[x].strip() !=''):                        
                                lblColHeadText = lblColHeadText + "D" + str(x+1) + ":\n"
                                lblColValueText = lblColValueText + aimDataValue[x] + "\n"
                                drDbLookup = AIMDatabase.GetDbLookUpDescription(aimDataValue[x], "D" + str(x+1))
                                if (drDbLookup.strip() !=""):
                                    lblColHeadText = lblColHeadText + "\n"
                                    lblColValueText = lblColValueText + drDbLookup + "\n"
        
                if (isAutoPriceFound == False and aimPrice.strip() !="0"):
                    lblColHeadText = lblColHeadText + "P" + ":\n"
                    lblColValueText = lblColValueText + aimPrice.strip() + "\n"
                    prDbLookup = AIMDatabase.GetDbLookUpDescription(aimPrice.strip().partition('.'), "P")
                    if (prDbLookup.strip() !=""):
                        lblColHeadText = lblColHeadText + "\n"
                        lblColValueText = lblColValueText + prDbLookup + "\n"
                
                if (isAutoQtyFound == False and str(totAimQty).strip() !="0"):
                    lblColHeadText = lblColHeadText + "Q" + ":\n"
                    lblColValueText = lblColValueText + str(totAimQty).strip() + "\n"
                    qrDbLookup = AIMDatabase.GetDbLookUpDescription(str(totAimQty).strip(), "Q")
                    if (qrDbLookup.strip() !=""):
                        lblColHeadText = lblColHeadText + "\n"
                        lblColValueText = lblColValueText + qrDbLookup + "\n"
            
            lblHeadText.set(lblColHeadText)
            lblValueText.set(lblColValueText)
    except Exception as e:
       exc_type, exc_obj, exc_tb = sys.exc_info()
       logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog('ShowBottomInfo Function Ends')

def ShowRunningBottomInfo():
    #WriteToLog("ShowRunningBottomInfo Function started")
    global totRecord
    try:
        print "Hasnat2"
        lblCountText.set("")            
        if (aimLocation.strip() !="0"):
            lblColHeadText = "L" + ":\n"
            lblColValueText = aimLocation + "\n"
            if (lDbLookup.strip() !=""):
                lblColHeadText = lblColHeadText + "\n"
                lblColValueText = lblColValueText + lDbLookup + "\n"

            if (totDataCount > 0):
                if (len(aimDataValue) > 0):
                    for x in range(totDataCount):            
                        if (aimDataValue[x].strip() !=''):                        
                            lblColHeadText = lblColHeadText + "D" + str(x+1) + ":\n"
                            lblColValueText = lblColValueText + aimDataValue[x] + "\n"
                        if (dDbLookup[x].strip() !=""):
                            lblColHeadText = lblColHeadText + "\n"
                            lblColValueText = lblColValueText + dDbLookup[x] + "\n"
        
            if (isAutoPriceFound == False and aimPrice.strip() !="0"):
                lblColHeadText = lblColHeadText + "P" + ":\n"
                lblColValueText = lblColValueText + aimPrice.strip() + "\n"
                if (pDbLookup.strip() !=""):
                    lblColHeadText = lblColHeadText + "\n"
                    lblColValueText = lblColValueText + pDbLookup + "\n"
                
            if (isAutoQtyFound == False and str(totAimQty).strip() !="0"):
                lblColHeadText = lblColHeadText + "Q" + ":\n"
                lblColValueText = lblColValueText +str(totAimQty).strip() + "\n"
                if (qDbLookup.strip() !=""):
                    lblColHeadText = lblColHeadText + "\n"
                    lblColValueText = lblColValueText + qDbLookup + "\n"
            
            lblHeadText.set(lblColHeadText)
            lblValueText.set(lblColValueText)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog('ShowRunningBottomInfo Function Ends')

def ResetDataArray():
    #WriteToLog("ResetDataArray Function started")
    try:
        for i in range(currLoopPosition, len(aimDataValue)):
            try:
                del aimDataValue[currLoopPosition]
            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog('ResetDataArray Function Ends')

def StrokeCounterCheck():
    if (totalStrokeCount < 1):
        print "StrokeCount Called"
        if (cData.get('KPh') == "1") or (cData.get('PPh') == "1"):
            StrokeCount()

def SaveData():
    #WriteToLog("SaveData Function started")
    try:
        global srcInput, srcBluetooth, isJumpKeyFound, EscKeyCount, currLoopPosition, aimFinalValue, aimLocation, aimDataValue, aimPrice, aimQty, aimConcatDataValue, decimalPosition
        global DoubleEnterCount, totAimQty, prevLength, currLength, isRunningTotFound, aimCSVValue, totAimQtyDesc, runningAimQtyDesc, maxId, isAutoQtyFound
        global data1, data2, data3, data4, data5, data6, data7, data8, data9, data10, currentId, currentPointer, isAutoQtyFoundCurrPrefix, CurrPrefix, prefixData
        global totalStrokeCount, totalPieceCount

        aimConcatDataValue = ''    
        entryText = entry.get("1.0", "end-1c").strip()

        if (len(entryText) > 0):
            if (DoubleEnterCount == 2):
                data1 = ''
                data2 = ''
                data3 = ''
                data4 = ''
                data5 = ''
                data6 = ''
                data7 = ''
                data8 = ''
                data9 = ''
                data10 = ''

                for m in range(totDataCount):
                    aimConcatDataValue = aimConcatDataValue + aimDataValue[m] + ","
                    if (m==0):
                        data1 = aimDataValue[m]
                    elif (m==1):
                        data2 = aimDataValue[m]
                    elif (m==2):
                        data3 = aimDataValue[m]
                    elif (m==3):
                        data4 = aimDataValue[m]
                    elif (m==4):
                        data5 = aimDataValue[m]
                    elif (m==5):
                        data6 = aimDataValue[m]
                    elif (m==6):
                        data7 = aimDataValue[m]
                    elif (m==7):
                        data8 = aimDataValue[m]
                    elif (m==8):
                        data9 = aimDataValue[m]
                    elif (m==9):
                        data10 = aimDataValue[m]

                finalTotQty = str(totAimQty)

                #print aimConcatDataValue
                aimFinalValue = aimLocation + "," + aimConcatDataValue +  aimPrice + "," + finalTotQty + '\n'
                #print(aimFinalValue)

                aimCSVValue = aimCSVValue + aimFinalValue

                #### DR Data added to the database
                #maxId = AIMDatabase.GetMaxDataId()
                maxId = AIMDatabase.GetMaxDataIdByLocation(str(DROutUnique_Id), aimLocation)
                maxId = maxId+1
            
                if AIMDatabase.Insert_DRData(str(maxId), str(DROutUnique_Id), aimLocation, ScheduleCode, data1, data2, data3, data4, data5, data6, data7, data8, data9, data10, aimPrice, finalTotQty, "0", str(time.strftime("%d-%m-%Y %H:%M:%S")), prefixData):
                    currentId = AIMDatabase.GetDrDataMaxId(str(DROutUnique_Id), aimLocation)
                    currentPointer = AIMDatabase.GetMaxCountId(str(currentId), str(DROutUnique_Id), aimLocation)
                    ShowBottomInfo()
                    currLoopPosition = loopBackNo-1;
                    if (isDataLoopBak):
                        ResetDataArray()
                    LoopLogic()
                    totAimQty = 0
                    aimPrice ='0'
                    totAimQtyDesc = ''
                    runningAimQtyDesc =''
                    prefixData = ''
                    CurrPrefix = ''
                    DoubleEnterCount = 1
                    entry.delete('1.0', END)
                    DynamicResizeFontSize()
                    srcBluetooth = False
                    srcInput = False                    
                    totalPieceCount = totalPieceCount + 1
            else:
                DataValidation(entryText)
                if (isDataValidate):
                    if (currStatus == locationPosition):
                        aimLocation = entryText
                        entry.delete('1.0', END)
                        currLocation = float(aimLocation)
                        if (currLocation >= startLocation and currLocation <= endLocation):
                            isAutoQtyFound = True
                        else:
                            isAutoQtyFound = False
                        print("isAutoQtyFound=" + str(isAutoQtyFound))
                        if (CurrPrefix.strip() !=''):
                            prefixData = "L_" + CurrPrefix + aimLocation + ","
                        if (str(cData.get('L_PlaySoundAccept')).lower() == 'true'):
                            PlaySounds(2)
                            print "Sound Plays Location"
                        StrokeCounterCheck()
                        totalStrokeCount = totalStrokeCount + len(aimLocation)
                    elif (currStatus == pricePosition):
                        if (decimalPosition > 0):
                            if (len(entryText) > decimalPosition):
                                withDecText = entryText[-decimalPosition:]
                                withoutDecText = entryText[:-decimalPosition]
                                aimPrice = withoutDecText + "." + withDecText
                                StrokeCounterCheck()
                                totalStrokeCount = totalStrokeCount + len(str(withoutDecText))
                            else:
                                aimPrice = entryText + ".00"
                                StrokeCounterCheck()
                                totalStrokeCount = totalStrokeCount + len(str(entryText))
                        else:
                            aimPrice = entryText
                            StrokeCounterCheck()
                            totalStrokeCount = totalStrokeCount + len(str(entryText))

                        entry.delete('1.0', END)
                        if (CurrPrefix.strip() !=''):
                            prefixData = prefixData + "P_" + CurrPrefix + aimPrice + ","
                        if (str(cData.get('P_PlaySoundAccept')).lower() == 'true'):
                            PlaySounds(2)
                            print "Sound Plays Price"
                    elif (currStatus == qtyPosition):
                        print "qty position"
                        print str(cData.get('Q_PlaySoundAccept'))                        
                        GetCurrentQty(entryText)
                        totAimQty = totAimQty + int(aimQty)
                        runningAimQtyDesc = " + " + str(aimQty) + runningAimQtyDesc
                        totAimQtyDesc =  str(totAimQty) + " = " + runningAimQtyDesc
                        entry.delete('1.0', END)
                        pos = entry.index(INSERT)
                        entry.insert(pos, str(totAimQtyDesc))
                        SetQtyPosition()
                        isRunningTotFound =  True
                        if (CurrPrefix.strip() !=''):
                            prefixData = prefixData + "Q_" + CurrPrefix + str(aimQty) + ","
                        if (str(cData.get('Q_PlaySoundAccept')).lower() == 'true'):
                            print "Sound Plays Qty"
                            PlaySounds(2)
                        StrokeCounterCheck()
                        totalStrokeCount = totalStrokeCount + len(str(aimQty))                        
                    else:
                        aimDataValue.append(entryText)
                        StrokeCounterCheck()
                        totalStrokeCount = totalStrokeCount + len(str(entryText))                        
                        entry.delete('1.0', END)
                        if (CurrPrefix.strip() !=''):
                            prefixData = prefixData + "D_" + CurrPrefix + str(entryText) + ","
                        for x in range(totDataCount):
                            #print "x=" + str(x)
                            if ((x+1) == currLoopPosition):
                                if (str(cData.get('I'+ str(x) + '_PlaySoundAccept')).lower() == 'true'):
                                    #print "Sound Plays Data"
                                    PlaySounds(2)
                                break

                    CurrPrefix = ''
                    ShowRunningBottomInfo()
                    LoopLogic()            
                    DynamicResizeFontSize()            
                #else:
                #    print "3"
                #    PlaySounds(1)                    

                srcBluetooth = False
                srcInput = False    
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog('SaveData Function Ends') 

def SetQtyPosition():
    try:
        currQPos = len(str(totAimQty)) + 3
        entry.mark_set(INSERT, str("1."+ str(currQPos)))
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        
def LoopLogic():
    #WriteToLog("SaveData Function started")
    try:
        global currLoopPosition, currStatus, DoubleEnterCount, totAimQty, aimPrice, CurrentHeadDescription

        currLoopPosition = currLoopPosition + 1
        #print "currLoopPosition=" + str(currLoopPosition)

        #if Auto Price Found Skip the Price Section, When Default Price =0
        if (isAutoPriceFound):
            print "Price1"
            if (currLoopPosition == pricePosition):
                currLoopPosition = qtyPosition
                currStatus = qtyPosition
                aimPrice = "0"
                print "Price2"

        #if Auto Qty Found Skip the Qty Section, Set defautl price =1, When localtion between start location and end location
        if (isAutoQtyFound):
            print "Qty1"
            if (currLoopPosition == qtyPosition):
                totAimQty = 1
                #currLoopPosition = loopBackNo
                DoubleEnterCount = DoubleEnterCount + 1
                print "DoubleEnterCount4=" + str(DoubleEnterCount)
                #currStatus = loopBackNo
                pos = entry.index(INSERT)
                entry.insert(pos, "1")
                SaveData()
                print "Qty2"
    
        #Normal Looping Process
        if (currLoopPosition == locationPosition):
            CurrentHeadDescription = cData.get('L_Description')
            lblDescText.set(CurrentHeadDescription)
            currStatus = locationPosition
        elif (currLoopPosition == pricePosition):
            CurrentHeadDescription = cData.get('P_Description')
            lblDescText.set(CurrentHeadDescription)
            currStatus = pricePosition
        elif (currLoopPosition == qtyPosition):
            CurrentHeadDescription = cData.get('Q_Description')
            lblDescText.set(CurrentHeadDescription)
            currLoopPosition = currLoopPosition -1
            currStatus = qtyPosition
        else:
            for x in range(totDataCount):
                if ((x+1) == currLoopPosition):
                    CurrentHeadDescription = cData.get('I' + str(x) + '_Description')
                    lblDescText.set(CurrentHeadDescription)
                    currStatus = x+1
                    break
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog('SaveData Function Ends')
        

frameLabel = Frame(Keyboard_App)
frameLabel.pack(fill='x')

lblDescText = StringVar()
CurrentHeadDescription = "Location:"
lblDescText.set(CurrentHeadDescription)
lblDesc = Label(frameLabel, textvariable =lblDescText, font=(fontName, 11))
lblDesc.pack(fill='x')

frameEntry = Frame(Keyboard_App)
frameEntry.pack(fill='x')

entry = Text(frameEntry, font=(fontName, entryDefFontSize), fg="red", bd=4, height=1)
entry.bind('<KeyPress>', onKeyPress)
#entry.bind('<Key>', onKeyPressed)
entry.bind('<Return>', scannerConfirm)
entry.focus()
entry.pack(fill='x')


#-----------------------------------------------------VK Start----------------------------------------------------------------------------------
buttons = [
    'A','B','C','D','E','F','G','+','-', 
    'H','I','J','K','L','M','N','*','/',
    'O','P','Q','R','S','T','U','$','%',
    'V','W','X','Y','Z','CAP','.','SPACE']

buttonsLow = [
    'a','b','c','d','e','f','g','+','-', 
    'h','i','j','k','l','m','n','*','/',
    'o','p','q','r','s','t','u','$','%',
    'v','w','x','y','z','CAP','.','SPACE']

columnSpan = 9
frameButton = Frame(Keyboard_App)

varRow = 2
varColumn = 0
for button in buttons:
    command = lambda x=button: select(x)
    if (button == "SPACE"):
        Button(frameButton, text=button, font=(fontName, vkButtonFontSize), width=8, bg="#000000", fg="#ffffff",
                activebackground="#ffffff", activeforeground="#000000", relief='raised', padx=5,
                pady=6, bd=4, command=command).grid(row=varRow, column=varColumn, columnspan=2)
    else:
        Button(frameButton, text=button, font=(fontName, vkButtonFontSize), width=3, bg="#000000", fg="#ffffff",
            activebackground="#ffffff", activeforeground="#000000", relief='raised', padx=5,
            pady=6, bd=4, command=command).grid(row=varRow, column=varColumn)

    varColumn += 1
    if varColumn > columnSpan - 1 and varRow > 1:
        varColumn = 0
        varRow += 1

frameLowerButton = Frame(Keyboard_App)

varRow = 2
varColumn = 0
for button in buttonsLow:
    command = lambda x=button: select(x)
    if (button == "SPACE"):
        Button(frameLowerButton, text=button, font=(fontName, vkButtonFontSize), width=8, bg="#000000", fg="#ffffff",
                activebackground="#ffffff", activeforeground="#000000", relief='raised', padx=5,
                pady=6, bd=4, command=command).grid(row=varRow, column=varColumn, columnspan=2)
    else:
        Button(frameLowerButton, text=button, font=(fontName, vkButtonFontSize), width=3, bg="#000000", fg="#ffffff",
            activebackground="#ffffff", activeforeground="#000000", relief='raised', padx=5,
            pady=6, bd=4, command=command).grid(row=varRow, column=varColumn)

    varColumn += 1
    if varColumn > columnSpan - 1 and varRow > 1:
        varColumn = 0
        varRow += 1

#-----------------------------------------------------VK ENDS----------------------------------------------------------------------------------



##------------------------ Bottom Panel ---------------------------------------------------
frameBottom = Frame(Keyboard_App)
frameBottom.pack(fill='x')

#lblCountText.set("1 of 27")
lblCount = Label(frameBottom, textvariable =lblCountText, font=(fontName, bottomTextSize))
lblCount.pack(side=RIGHT, anchor=NW)

#lblHeadText.set("Area Number:\nPrice:\nQtyanity:")
lblHead = Label(frameBottom, textvariable =lblHeadText, font=(fontName, bottomTextSize), anchor=W, justify=LEFT, padx=10)
lblHead.pack(side=LEFT)

#lblValueText.set("765\n134.23\n45")
lblValue = Label(frameBottom, textvariable =lblValueText, wraplength=280, font=(fontName, bottomTextSize), anchor=W, justify=LEFT, padx=2)
lblValue.pack(side=TOP, anchor=W)

##------------------------ Bottom Panel --------------------------------------------------------

##------------------------- Status bar ---------------------------------------------------------
frameStatus = Frame(Keyboard_App, bd=1, relief=SUNKEN, height=18)
frameStatus.pack(side=BOTTOM, fill='x')

lblStaWifiScaner = Label(frameStatus, textvariable=wifiScannerText, font=doubleStatusFontSize)
lblStaWifiScaner.pack(side=LEFT)

sep1 = Separator(frameStatus, orient=VERTICAL)
sep1.pack(side=LEFT, fill="y")

lblStaIpVer = Label(frameStatus, textvariable=ipVerText, font=doubleStatusFontSize)
lblStaIpVer.pack(side=LEFT)

sep2 = Separator(frameStatus, orient=VERTICAL)
sep2.pack(side=LEFT, fill="y")

lblStaDownId = Label(frameStatus, textvariable=downIdText, font=statusFontSize)
lblStaDownId.pack(side=LEFT)

sep3 = Separator(frameStatus, orient=VERTICAL)
sep3.pack(side=LEFT, fill="y")

lblStaTime = Label(frameStatus, textvariable=timeText, font=doubleStatusFontSize)
lblStaTime.pack(side=LEFT)

sep4 = Separator(frameStatus, orient=VERTICAL)
sep4.pack(side=LEFT, fill="y")

lblStaStore = Label(frameStatus, textvariable=stoNameText, font=statusFontSize)
lblStaStore.pack(side=LEFT)

lblStaWifi = Label(frameStatus, font=statusFontSize)
lblStaWifi.pack(side=RIGHT)
img1 = ImageTk.PhotoImage(Image.open(wgIcon))
lblStaWifi.configure(image=img1)

lblStaFTP = Label(frameStatus, font=statusFontSize)
lblStaFTP.pack(side=RIGHT)
img2 = ImageTk.PhotoImage(Image.open(fgIcon))
lblStaFTP.configure(image=img2)

lblStaBlue = Label(frameStatus, font=statusFontSize)
lblStaBlue.pack(side=RIGHT)
img3 = ImageTk.PhotoImage(Image.open(bgIcon))
lblStaBlue.configure(image=img3)

lblSta2nd = Label(frameStatus, font=statusFontSize)
lblSta2nd.pack(side=RIGHT)

def ShowDefaultStatus():
    global is2ndKeyShows
    is2ndKeyShows = False
    lblSta2nd.configure(image='')
    lblSta2nd.image= ''

def ShowProcessStatus():
    img = ImageTk.PhotoImage(Image.open(fyIcon))
    lblStaFTP.configure(image=img)
    lblStaFTP.image= img

def ShowSuccessStatus():
    img = ImageTk.PhotoImage(Image.open(fgIcon))
    lblStaFTP.configure(image=img)
    lblStaFTP.image= img

def ShowNotSuccessStatus():   
    img = ImageTk.PhotoImage(Image.open(frIcon))
    lblStaFTP.configure(image=img)
    lblStaFTP.image= img

def Show2ndStatus():
    global is2ndKeyShows
    is2ndKeyShows = True
    img = ImageTk.PhotoImage(Image.open(secondIcon))
    lblSta2nd.configure(image=img)
    lblSta2nd.image= img

def FillStatusInfo():  
    global ssid, ipaddress
    ssid = os.popen("iwconfig wlan0 \
                | grep 'ESSID' \
                | awk '{print $4}' \
                | awk -F\\\" '{print $2}'").read()    
    
    if (ssid.strip() !=""):
        if ("AIM" in ssid):
            ssid = ssid.replace("AIM", "").strip()
        if ("INV" in ssid):
            ssid = ssid.replace("INV", "").strip()
        print ssid
    if (len(ssid) == 1):
        ssid = "000" + ssid
    elif (len(ssid) == 2):
        ssid = "00" + ssid
    elif (len(ssid) == 3):
        ssid = "0" + ssid
    elif (len(ssid) > 4):
        ssid = ssid[:4]

    ipaddress = os.popen("ifconfig wlan0 \
                     | grep 'inet addr' \
                     | awk -F: '{print $2}' \
                     | awk '{print $1}'").read()
    
    if (ipaddress.strip() !=""):
        currIPAddress = ipaddress.split('.')
        if (len(currIPAddress) > 1):
            myIps = currIPAddress[2].strip()[-1:]
            ipaddress = myIps + "." + currIPAddress[3]
        print ipaddress

    scannerid = AIMDatabase.GetRegistrerScannerId()
    if (len(scannerid) == 1):
        scannerid = "000" + scannerid
    elif (len(scannerid) == 2):
        scannerid = "00" + scannerid
    elif (len(scannerid) == 3):
        scannerid = "0" + scannerid

    wifiScannerText.set(ssid + "\n" + scannerid)
    ipVerText.set(ipaddress.strip() + "\n" + __version__)
    UpdateStatusTime()

def UpdateStatusTime():
    now = datetime.datetime.now()
    myHour = str(now.hour)
    if (len(myHour) == 1):
        myHour = "0" + str(myHour)
    myMin = str(now.minute)
    if (len(myMin) == 1):
        myMin = "0" + str(myMin)
    myDay = str(now.day)
    if (len(myDay) == 1):
        myDay = "0" + str(myDay)
    myMonth = str(now.month)
    if (len(myMonth) == 1):
        myMonth = "0" + str(myMonth)
    timeText.set(myHour + myMin + "\n" + myDay + myMonth + str(now.year)[2:])

##------------------------- Status bar ---------------------------------------------------------

#-------------------------- Start Count Time ---------------------------------------------------------
def StrokeCount():
    global strokeEndTime   
    try:  
        strokeEndTime = strokeEndTime + 1
        #print("strokeEndTime=" + str(strokeEndTime))
    except:
        pass
    finally:
        if (isCounterEnable):
            threading.Timer(1, StrokeCount).start()

#-------------------------- Ends Count Time ---------------------------------------------------------

#----- Check and Create sqlite3 aimdr.db -------------------------------------------------------
AIMDatabase.CreateAllTable()
ScannerId = AIMDatabase.GetRegistrerScannerId()

def GetBarcodePrefixInformation():
    #WriteToLog('GetBarcodePrefixInformation Function Starts')
    global AllowedBarcodePrefix, AllowedBarcodePrefixType
    try:
        cursorDrScanner = AIMDatabase.Select_DrScannerInfo()
        for drScannerInfo in cursorDrScanner:
            try:
                print "Registered MacId=" + drScannerInfo[0].strip()
                BarcodePrefixInfo = XMLReader.GetAllPrefixAndBarcodeType(drScannerInfo[0].strip()).split(';')
                AllowedBarcodePrefix = BarcodePrefixInfo[0]
                AllowedBarcodePrefixType = BarcodePrefixInfo[1]
            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog('GetBarcodePrefixInformation Function Starts')

def CheckAndSetGroupId():
    #WriteToLog('CheckAndSetGroupId Function Starts')
    try:
        global DROutUnique_Id, aimLocation, data1, data2, data3, data4, data5, data6, data7, data8, data9, data10, aimPrice, aimQty
        global currLoopPosition, currentId, currentPointer, aimDataValue, isAutoQtyFound
        maxClosedId = AIMDatabase.GetMaxGroupNotClosed(ScheduleCode)
        if (maxClosedId) > 0:
            print("maxClosedId=" + str(maxClosedId))
            cursor = AIMDatabase.Select_DRDataByNotClosedId(str(maxClosedId))
            try:
                for row in cursor:
                    DROutUnique_Id = row[0]
                    aimLocation = row[1]
                    k = 2
                    if (isDataLoopBak):
                        for m in range(loopBackNo-1):
                            aimDataValue.append(row[k])
                            k = k + 1
                    else:
                        for m in range(totDataCount):
                            aimDataValue.append(row[k])
                            k = k + 1
                    #aimPrice = row[12]
                    #aimQty = row[13]
                    print("aimDataValue Length=" + str(len(aimDataValue)))                
            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
            currLocation = float(aimLocation)
            if (currLocation >= startLocation and currLocation <= endLocation):
                isAutoQtyFound = True
            else:
                isAutoQtyFound = False
            print("isAutoQtyFound=" + str(isAutoQtyFound))
            currLoopPosition = loopBackNo-1
            LoopLogic()
            currentId = AIMDatabase.GetDrDataMaxId(str(DROutUnique_Id), aimLocation)
            currentPointer = AIMDatabase.GetMaxCountId(str(currentId), str(DROutUnique_Id), aimLocation)
            ShowBottomInfo()
        else:
            DROutUnique_Id = AIMDatabase.GetScheduleGroupId(ScheduleCode) + 1
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
    #    WriteToLog('CheckAndSetGroupId Function Ends')

##---- Read Config file
ReadXMLData.ReadConfigData()
ReadXMLData.ReadAdminConfigData()
GetBarcodePrefixInformation()
FillStatusInfo()
   
try:
    if (len(cData) > 0):
        if (cData.get('ScheduleId') <> ""):
            ScheduleCode = cData.get('ScheduleId')
            Keyboard_App.title("AIM DR : " + ScheduleCode)
        CurrentHeadDescription = cData.get('L_Description')
        lblDescText.set(CurrentHeadDescription)

        CheckAndSetGroupId()
    else:
        CurrentHeadDescription = "Location"
        lblDescText.set(CurrentHeadDescription)

except Exception as e:
    exc_type, exc_obj, exc_tb = sys.exc_info()
    logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

try:
    #DRId = get_mac()
    DRId= socket.gethostname()
    IPAddr = socket.gethostbyname(DRId)
    print "MachineName=" + str(DRId)
except Exception as e:
    exc_type, exc_obj, exc_tb = sys.exc_info()
    logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

#-----------------------------------------------------GPIO----------------------------------------------------------------------
def ping():
    try:
        while 1:
            time.sleep(0.06)
            Keyboard_App.event_generate('<<Ping>>', when='tail')
    except:
        pass

def gotPing(event):
    gpiovalue = gpio.get_keypad_value()
    try:
        if (gpiovalue.strip() !=''):
            #WriteToLog("I2C key read Started for key " + gpiovalue.strip())
            select(gpiovalue)
            #WriteToLog("I2C key read Ended for key " + gpiovalue.strip())
    except:
        pass
        

Keyboard_App.bind('<<Ping>>', gotPing)
th = threading.Thread(target=ping)
th.setDaemon(1)
th.start()
###---------------------------------------------------------------------------------------------------------------------------

#-----------------------------------------------------SOUND----------------------------------------------------------------------
isSoundsPlay = False
def soundKey():
    try:
        while 1:
            time.sleep(0.5)
            Keyboard_App.event_generate('<<SOUND>>', when='tail')
    except:
        pass

def playSoundKey(event):
    global isSoundsPlay
    try:
        if (isDataValidate == False):
            if (isSoundsPlay):
                #time.sleep(0.5)
                isSoundsPlay = False
            else:  
                isSoundsPlay = True
                PlaySounds(1)
    except:
        pass

Keyboard_App.bind('<<SOUND>>', playSoundKey)
th1 = threading.Thread(target=soundKey)
th1.setDaemon(1)
th1.start()
#---------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------Bottom Status-----------------------------------------------------------------------
def CheckWifiStatus():
    global img1, lblStaWifi
    print "Wifi Checking"
    status = False
    try:  
        img1 = ImageTk.PhotoImage(Image.open(wyIcon))
        lblStaWifi.configure(image=img1)
        status = True if os.system("ping -c 1 " + WifiIp) is 0 else False
    except:
        pass
    finally:
        if (status):
            img1 = ImageTk.PhotoImage(Image.open(wgIcon))
            lblStaWifi.configure(image=img1)
        else:
            img1 = ImageTk.PhotoImage(Image.open(wrIcon))
            lblStaWifi.configure(image=img1)
        threading.Timer(WifiCheckInterval, CheckWifiStatus).start()   

def CheckFTPStatus():
    global img2, lblStaFTP
    print "FTP Checking"
    status = False
    try:                 
        img2 = ImageTk.PhotoImage(Image.open(fyIcon))
        lblStaFTP.configure(image=img2)
        countFile = 0
        ftp = FTPSync.getFTPConnection(ftpHost, ftpUser, ftpPass, statusDirName)
        Ftpfiles = []
        Ftpfiles = FTPSync.getListofFile(ftp)
        for f in Ftpfiles:
            countFile= countFile + 1
            try:
                if os.path.isfile(statusDirName + f):
                    os.unlink(statusDirName + f)
                    FTPSync.downloadFile(f, statusDirName, ftp)
            except Exception as e:
                print(e)
        print "countFile=" + str(countFile)
        ftp.quit()
        if (countFile > 0):   
            status = True
        timeFileSource = statusDirName + drTimeConfigFileName
        if os.path.isfile(timeFileSource):
            try:
                file = open(timeFileSource, "r") 
                bsDate = file.read() 
                print "bsDate=" + bsDate
                if (bsDate.strip() !=''):
                    os.system("sudo date -s " + "\"" + bsDate + "\"")
                    UpdateStatusTime()
            except Exception as e:
                pirnt(e)
    except:
        pass
    finally:
        if (status):
            img2 = ImageTk.PhotoImage(Image.open(fgIcon))
            lblStaFTP.configure(image=img2)
        else:
            img2 = ImageTk.PhotoImage(Image.open(frIcon))
            lblStaFTP.configure(image=img2)
        threading.Timer(FtpCheckInterval, CheckFTPStatus).start()

def CheckBluetoothStatus():
    global img3, lblStaBlue 
    print "Bluetooth Checking"
    status = False
    try:
        img3 = ImageTk.PhotoImage(Image.open(byIcon))
        lblStaBlue.configure(image=img3)
        bl = Bluetoothctl()
        status =  bl.is_connected()
    except:
        pass
    finally:
        if (status):
            img3 = ImageTk.PhotoImage(Image.open(bgIcon))
            lblStaBlue.configure(image=img3)
        else:
            img3 = ImageTk.PhotoImage(Image.open(brIcon))
            lblStaBlue.configure(image=img3)
        threading.Timer(BluetoothCheckInterval, CheckBluetoothStatus).start()

threading.Timer(WifiCheckInterval, CheckWifiStatus).start()
threading.Timer(FtpCheckInterval, CheckFTPStatus).start()
threading.Timer(BluetoothCheckInterval, CheckBluetoothStatus).start()
#------------------------------------------------------Bottom Status---------------------------------------------------------------------

#IsVKShow = True
#frameBottom.pack_forget()
#frameLowerButton.pack_forget()
#frameButton.pack()

#print "Group Id=" + str(DROutUnique_Id)
#print "aimLocation=" + aimLocation
#print "ScheduleCode=" + ScheduleCode

#WriteToLog('Ends The Program Line')
Keyboard_App.mainloop()
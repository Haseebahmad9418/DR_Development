#!/usr/bin/env python
# coding: utf-8
__version__ = "3.0"
__Date__ = "27MAR2019"

import logging
import socket
import time
from configfile import *
import subprocess

def WriteToLog(comments):
    if (IsLogging):
        try:
            logData = " " + socket.gethostname() + " : " + str(time.strftime("%d-%m-%Y %H:%M:%S")) + " :  " + __file__ + " :  " + comments
            logging.debug(logData)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

LOG_FILENAME = 'aimdr.log'
logging.basicConfig(filename=LOG_FILENAME,level=logging.DEBUG)
#WriteToLog('First Line Started')

try:
    from Tkinter import *   ## notice capitalized T in Tkinter
    import Tkinter as tk
    import ttk
    import os
    from ftplib import FTP    
    import threading
    from threading import Thread
    import time    
    from PIL import ImageTk, Image
    import sys    
    import csv
    import filecmp
    import shutil
    from bluetoothctl import *
    import XMLReader
    import AIMVersionCheck
    import FTPSync
    import ZipFunction
    import AIMDatabase
    import DR_Key_GPIO as gpio
    import datetime
    from ttk import Separator
except Exception as e:
    exc_type, exc_obj, exc_tb = sys.exc_info()
    logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

AimFTP = tk.Tk()
AimFTP.title("FTP Settings")
AimFTP.resizable(0, 0)
w, h = 480, 320
AimFTP.geometry("%dx%d+0+0" % (w, h))
AimFTP.wm_attributes('-fullscreen', 'true')

#-------- Global Variable Start Here
lblHostText = StringVar()
lblUserText = StringVar()
lblPassText = StringVar()
lblDirText = StringVar()
lblFTPText = StringVar()
lblNextText = StringVar()
lblStatus = StringVar()
lblInfoText = StringVar()
enHostText = StringVar(AimFTP, value='')
enUserText = StringVar(AimFTP, value='')
enPassText = StringVar(AimFTP, value='')
enDirText = StringVar(AimFTP, value='DRConfig')
downIdText = StringVar()
wifiScannerText = StringVar()
ipVerText = StringVar()
timeText = StringVar()
stoNameText = StringVar()
ssid = ''
ipaddress = ''

####------------- FTP Information------------------------------------------------------------------------------------
ftpHost = ''
ftpUser = ''
ftpPass = ''
ftpHost1 = ''
ftpUser1 = ''
ftpPass1 = ''
ftpRemoteConfigDir = ''
storeName = ''
downloadCode = ''
TimeSyncServer = ''
ftpAdminConfig = ''
####-----------------------------------------------------------------------------------------------------------------

fontName = "Helvetica"
fontSize = 19
statusFontSize = (fontName, 12, 'bold')
doubleStatusFontSize = (fontName, 10, 'bold')
btnFontSize = 18
infoFontSize = 18
deleteFontSize = 16
pady= 3
btnWidth = 15
isHideShows = False
isProcessDone = False
isProcessing = False
ErrorCount = 1
frmDeletePopup = None
isDeleteFormShow = False
isDifferentScheduleDataFound = False
isSameScheduleDataFound = False
#-------- Global Variable Ends Here -------------------------------------------------

class CheckVersionNumber():
    @staticmethod
    def CheckVersion(updateDirName, updateScriptName, currentScriptName):
       ###---------Extract all zip files from local directory
       fileAPath = ""
       fileBPath = ""
       curFile = ""
       status = False
       isFound = False
       try:
           dFiles = os.listdir(updateDirName)
           for df in dFiles:
               updateFile_path = updateDirName + "/" + updateScriptName
               if os.path.exists(updateFile_path):
                fileAPath = updateFile_path
                break

           files = [f for f in os.listdir('.') if os.path.isfile(f)]
           for f in files:
            if (f == currentScriptName):
                fileBPath = currentScriptName
                isFound = True
                break
           if (isFound):
               if filecmp.cmp(fileAPath, fileBPath) == False:
                   status = True
           else:
                shutil.copy2(updateDirName+ '/' + currentScriptName, currentScriptName)
       except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
       finally:
            return status

    @staticmethod
    def CheckUpdateVersionStatus():
        isDone = True
        try:
            #Initialize Section
            arrProg = updateFileNames.split('~')
            if (len(arrProg) > 0):
                for m in range(len(arrProg)):
                    try:
                        status = False
                        status = CheckVersionNumber.CheckVersion(updateDirName, arrProg[m], arrProg[m])
                        print "status=" + str(status)
                        if (status):
                            os.unlink(arrProg[m])
                            shutil.copy2(updateDirName+ '/' + arrProg[m], arrProg[m])
                            print str(arrProg[m]) + " is Updated"
                    except Exception as e:
                        print(e)
                        isDone = False
        except Exception as e:
            print(e)
            isDone = False
        finally:
            return isDone

    @staticmethod
    def CopyConfigFiles(types):
        isDone = False
        try:
            #Copy Files
            for the_file in os.listdir(configTempDirName):
                if (the_file == drConfigZipFileName):
                    if (types ==1):
                        srcfile = os.path.join(configTempDirName, the_file)
                        try:
                            if os.path.isfile(srcfile):
                                dstfile = os.path.join(configDirName, the_file)
                                if os.path.isfile(dstfile):
                                    os.unlink(dstfile)
                                shutil.copy2(srcfile, dstfile)
                        except Exception as e:
                            exc_type, exc_obj, exc_tb = sys.exc_info()
                            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

                if (the_file == drConfigZipFileNameNew or the_file == drDbLookupFileName):
                    srcfile = os.path.join(configTempDirName, the_file)
                    try:
                        if os.path.isfile(srcfile):
                            dstfile = os.path.join(configDirName, the_file)
                            if os.path.isfile(dstfile):
                                os.unlink(dstfile)
                            shutil.copy2(srcfile, dstfile)
                    except Exception as e:
                        exc_type, exc_obj, exc_tb = sys.exc_info()
                        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
            isDone = True
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        finally:
            return isDone

#---Read Config Data
def GetConfigData():
   #WriteToLog('GetConfigData Functions Starts')
   ###---------Extract all zip files from local directory
   global ftpHost, ftpHost1, ftpPass, ftpPass1, ftpUser, ftpUser1, ftpRemoteConfigDir, storeName, downloadCode, TimeSyncServer, ftpAdminConfig
   try:
       cData = XMLReader.ReadAdminConfigData()
       if (len(cData) > 0):
           print cData.get('FTP_Host')
           print cData.get('FTP_User')
           print cData.get('FTP_Pass')
           print cData.get('FTP1_Host')
           print cData.get('FTP1_User')
           print cData.get('FTP1_Pass')
           print cData.get('FTP_DrConfigDir')

           ftpHost = cData.get('FTP_Host')
           enHostText.set(ftpHost)
           ftpUser = cData.get('FTP_User')
           enUserText.set(ftpUser)
           ftpPass = cData.get('FTP_Pass')
           enPassText.set(ftpPass)
           ftpRemoteConfigDir = cData.get('FTP_DrConfigDir')
           enDirText.set(ftpRemoteConfigDir)
           ftpAdminConfig = cData.get('FTP_DrUpdateDir')

           ftpHost1 = cData.get('FTP1_Host')
           ftpUser1 = cData.get('FTP1_User')
           ftpPass1 = cData.get('FTP1_Pass')
           TimeSyncServer = cData.get('TimeSyncServer')

           if (isProcessDone):
               cData1 = XMLReader.ReadDRConfigData()
               if (len(cData1) > 0):           
                   print cData1.get('StoreName')
                   print cData1.get('DownloadCode')

                   storeName = cData1.get('StoreName')
                   downloadCode = cData1.get('DownloadCode')
                   downIdText.set(downloadCode)
                   stoNameText.set(storeName)
           
                   #HideFtpForm()
                   #ShowHideInfoForm(1)
                   try:
                       os.system("sudo ntpdate -u " + TimeSyncServer)
                   except Exception as e:
                       exc_type, exc_obj, exc_tb = sys.exc_info()
                       logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

               lblInfoText.set(storeName + "-" + downloadCode + "\n" + str(time.strftime("%d-%m-%Y %H:%M:%S")))
   except Exception as e:
       exc_type, exc_obj, exc_tb = sys.exc_info()
       logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
   #finally:
        #WriteToLog('GetConfigData Functions Ends')

####---------------------- GPIO Start ----------------------------------------------------------------------------------------
entry = None

def currentEntry(userEntry):
    global entry
    entry = userEntry
    print entry

def select(value):
    global entry
    global isHideShows
    try:
        print value
        if value == "DEL":
           pos= entry.index(INSERT)
           entry.delete(pos-1, pos)
        elif value == "ESC":
            if (isDeleteFormShow):
               frmDeletePopups.submitCancel()
            else:
               entry.delete(0, END)
        elif value == "LEFT":
           pos= entry.index(INSERT)
           entry.icursor(pos-1)
        elif value == "RIGHT":
           pos= entry.index(INSERT)
           entry.icursor(pos+1)
        elif value == "UP":
           entry.icursor(0)
        elif value == "DOWN":
           entry.icursor(len(entry.get()))
        elif value == "F2":
           if (isDeleteFormShow):
               if (isDifferentScheduleDataFound):
                  frmDeletePopups.SubmitClearAndReplace()
               else:
                  frmDeletePopups.submitOK()
           elif (isProcessing == False):
               btnNexts()
        elif value == "2nd1":
           Show2ndStatus()
        elif value == "2nd2":
           ShowDefaultStatus()
        elif value == "NEX":
           if (isProcessing == False):               
                btnNexts()
        elif value == "HID":
            if (isHideShows):
              isHideShows = False
              HideFtpForm()
            else:
              isHideShows = True
              ShowFtpForm()
        #elif value == "CLO":
        #   os._exit(1)
        elif (value == "0" or value == "1" or value == "2" or value == "3"  or value == "4" or value == "5" or 
                value == "6" or value == "7" or value == "8" or value == "9"):
           pos= entry.index(INSERT)
           entry.insert(pos,value)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
####---------------------- GPIO Ends ----------------------------------------------------------------------------------------

def HideFtpForm():
   frameHost.pack_forget()
   frameUser.pack_forget()
   framePass.pack_forget()
   frameDir.pack_forget()
   frameButton.pack_forget()
   
def ShowFtpForm():
   frameInfo.pack_forget()
   frameHost.pack()
   frameUser.pack()
   framePass.pack()
   frameDir.pack()
   frameButton.pack()

def ShowHideInfoForm(types):
    if (types == 0):
       ShowFtpForm()
    else:
       HideFtpForm()
       frameInfo.pack()
   
frameLabel = Frame(AimFTP, height=10)
frameLabel.pack()

### Information Frame
frameInfo = Frame(AimFTP, pady=80)
frameInfo.pack()
lblInfoText.set("Connecting...")
lblInfo = Label(frameInfo, textvariable=lblInfoText, font=(fontName, infoFontSize))
lblInfo.pack(side = LEFT)
frameInfo.pack_forget()


### Host Frame
frameHost = Frame(AimFTP, pady=pady)
frameHost.pack()

lblHostText.set("Host:")
lblHost = Label(frameHost, textvariable =lblHostText, font=(fontName, fontSize))
lblHost.pack(side = LEFT)

enHost = Entry(frameHost, textvariable=enHostText, width=25, font=(fontName, fontSize))
enHost.focus()
enHost.pack(side = LEFT)


### User Frame
frameUser = Frame(AimFTP, pady=pady)
frameUser.pack()

lblUserText.set("User:")
lblUser = Label(frameUser, textvariable =lblUserText, font=(fontName, fontSize))
lblUser.pack(side = LEFT)

enUser = Entry(frameUser, textvariable=enUserText, width=25, font=(fontName, fontSize))
enUser.pack(side = LEFT)


### Password Frame
framePass = Frame(AimFTP, pady=pady)
framePass.pack()

lblPassText.set("Pass:")
lblPass = Label(framePass, textvariable =lblPassText, font=(fontName, fontSize))
lblPass.pack(side = LEFT)

enPass = Entry(framePass, textvariable=enPassText, show="*", width=25, font=(fontName, fontSize))
enPass.pack(side = LEFT)


### Remote Directory Frame
frameDir = Frame(AimFTP, pady=pady)
frameDir.pack()

lblDirText.set("R.Dir:")
lblDir = Label(frameDir, textvariable =lblDirText, font=(fontName, fontSize))
lblDir.pack(side = LEFT)

enDir = Entry(frameDir, textvariable=enDirText, width=25, font=(fontName, fontSize))
enDir.pack(side = LEFT)

#-------------------------Show delete popup screen ---------------------------------------------------------------------------------------------------------------------------------
class frmDeletePopups:
    @staticmethod
    def submitOK():
        global isDeleteFormShow
        try:
            print "DrData Directory Clearing started"
            frmDeletePopups.ClearBackupDirectory()
            print "Database Clearing started"
            if (AIMDatabase.ResetDRBasicTables()):
                if (CheckVersionNumber.CopyConfigFiles(2)):
                    UnzipConfigFiles()
                    isDeleteFormShow = False
                    ShowSuccessButton()
                    ShowSuccessStatus()
                    frmDeletePopup.destroy()
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

    @staticmethod
    def SubmitClearAndReplace():
        global isDeleteFormShow
        try:
            print "DrData Directory Clearing started"
            frmDeletePopups.ClearBackupDirectory()
            print "Database Clearing started"
            if (AIMDatabase.ResetDRBasicTables()):                
                if (CheckVersionNumber.CopyConfigFiles(1)):
                    UnzipConfigFiles()
                    isDeleteFormShow = False
                    ShowSuccessButton()
                    ShowSuccessStatus()
                    frmDeletePopup.destroy()
            
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    
    @staticmethod
    def ClearBackupDirectory():        
        for the_file in os.listdir(drDataDirName):
            file_path = os.path.join(drDataDirName, the_file)
            try:
                if os.path.isfile(file_path):
                    os.unlink(file_path)
            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

    @staticmethod
    def submitCancel():
        global isDeleteFormShow        
        isDeleteFormShow = False
        ShowSuccessButton()
        ShowSuccessStatus()        
        AimFTP.destroy()
        os.system("python AimScanner.py")        

    def __init__(self, master):
        self.master = master
        self.frame = Frame(self.master)
        self.frame.pack()

        self.frameSync = Frame(self.frame, pady=5)
        self.frameSync.pack()

        self.frame1 = Frame(self.frame, pady=5)
        self.frame1.pack()
        
        self.lblReady = Label(self.frame1, text ="Data exist. Delete?", font=(fontName, deleteFontSize))
        self.lblReady.pack()

        self.frameButton = Frame(self.frame, pady=5)
        self.frameButton.pack()

        if (isDifferentScheduleDataFound):
            self.btnOK = Button(self.frameButton, text ="Replace Schedule", width=20, font=(fontName, deleteFontSize), command = frmDeletePopups.SubmitClearAndReplace) 
            self.btnOK.bind("<Return>", lambda event:frmDeletePopups.SubmitClearAndReplace())
            self.btnOK.pack(side = LEFT)
        
        elif (isSameScheduleDataFound):
            self.btnOK = Button(self.frameButton, text ="Yes", width=12, font=(fontName, deleteFontSize), command = frmDeletePopups.submitOK) 
            self.btnOK.bind("<Return>", lambda event:frmDeletePopups.submitOK())
            self.btnOK.pack(side = LEFT)

            self.btnCancel = Button(self.frameButton, text ="No", width=12, font=(fontName, deleteFontSize), command = frmDeletePopups.submitCancel) 
            self.btnCancel.bind("<Return>", lambda event:frmDeletePopups.submitCancel())
            self.btnCancel.pack(side = RIGHT)        

def center(toplevel):
    toplevel.update_idletasks()
    w = toplevel.winfo_screenwidth()
    h = toplevel.winfo_screenheight()
    size = tuple(int(_) for _ in toplevel.geometry().split('+')[0].split('x'))
    x = w/2 - size[0]/2
    y = h/2 - size[1]/2
    toplevel.geometry("%dx%d+%d+%d" % (size + (x, y)))

def ShowDeletePopupForm():
    #WriteToLog("ShowDeletePopupForm Function started")
    try:
        global isDeleteFormShow, frmDeletePopup
        isDeleteFormShow = True
        gpio.SECOND_KEY_VALUE = 0
        ShowDefaultStatus()
        #Delete Form
        frmDeletePopup = tk.Toplevel()
        frmDeletePopup.title("Delete Confirmation")
        frmDeletePopup.resizable(0, 0)
        w, h = 400, 150
        frmDeletePopup.geometry("%dx%d+0+0" % (w, h))
        center(frmDeletePopup)
        app = frmDeletePopups(frmDeletePopup)
        frmDeletePopup.mainloop()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

def CheckPreviousDataExist():
    #WriteToLog('CheckPreviousDataExist Functions Starts')
    isDone = False
    try:
        global isDifferentScheduleDataFound, isSameScheduleDataFound
        isDifferentScheduleDataFound = False
        isSameScheduleDataFound = False
        #----- Check DrData Table ------ 
        downloadSchedule = ''
        cData1 = XMLReader.ReadDRConfigData()
        if (len(cData1) > 0):            
            downloadSchedule = cData1.get('ScheduleCode')
            print downloadSchedule

        if (downloadSchedule.strip() !=""):
            cursorDRData = AIMDatabase.GetTableDataExist("DrData")
            for drData in cursorDRData:
                isSameScheduleDataFound = True
                if (str(drData[0]).strip() != downloadSchedule.strip()):
                    isDifferentScheduleDataFound = True
                    break                

            if (isDifferentScheduleDataFound==False):
                #----- Check DrMainHead Table ------
                cursorDRData1 = AIMDatabase.GetTableDataExist("DrMainHead")
                for drData1 in cursorDRData1:
                    isSameScheduleDataFound = True
                    if (str(drData1[0]).strip() != downloadSchedule.strip()):
                        isDifferentScheduleDataFound = True
                        break

            if (isDifferentScheduleDataFound==False):
                #----- Check DrColumnHead Table ------                
                cursorDRData2 = AIMDatabase.GetTableDataExist("DrColumnHead")
                for drData2 in cursorDRData2:
                    isSameScheduleDataFound = True
                    if (str(drData2[0]).strip() != downloadSchedule.strip()):
                        isDifferentScheduleDataFound = True
                        break
        isDone = True
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    finally:
        #WriteToLog('CheckPreviousDataExist Functions Ends')
        return isDone
#-------------------------Show delete popup screen ---------------------------------------------------------------------------------------------------------------------------------


def ReadAndSaveLookUpData():
    #WriteToLog('ReadAndSaveLookUpData Functions Starts') 
    try:
        if os.path.isfile(configDirName + drDbLookupConfigFileName): 
            with open(configDirName + drDbLookupConfigFileName) as csvfile:
                spamreader = csv.reader(csvfile, delimiter=',')
                if (AIMDatabase.Reset_DrDbLookup()):
                    AIMDatabase.Insert_DrDbLookup(spamreader)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    #finally:
        #WriteToLog('ReadAndSaveLookUpData Functions Ends')


def UnzipConfigFiles():
       #WriteToLog('UnzipConfigFiles Functions Starts') 
       ###---------Extract all zip files from local directory
       dFiles = []
       isDownloaded = False
       try:
           dFiles = os.listdir(configDirName)
           if os.path.isfile(configDirName + drConfigZipFileNameNew):
              if os.path.isfile(configDirName + drAdminConfigFileName):
                os.unlink(configDirName + drAdminConfigFileName)

              if os.path.isfile(configDirName + drMacConfigFileName):
                os.unlink(configDirName + drMacConfigFileName)

              if os.path.isfile(configDirName + drBarcodePrefixHeadConfigFileName):
                os.unlink(configDirName + drBarcodePrefixHeadConfigFileName)

              if os.path.isfile(configDirName + drBarcodePrefixDetailsConfigFileName):
                os.unlink(configDirName + drBarcodePrefixDetailsConfigFileName)

           if os.path.isfile(configDirName + drConfigZipFileName): 
                if os.path.isfile(configDirName + drConfigFileName):
                    os.unlink(configDirName + drConfigFileName)
                
           for df in dFiles:               
               zipConfigfile_path = configDirName + "/" + drConfigZipFileNameNew
               if os.path.isfile(zipConfigfile_path):
                   if (ZipFunction.UnZipFile(zipConfigfile_path, configDirName)):
                     isDownloaded = True

               zipMainConfigfile_path = configDirName + "/" + drConfigZipFileName
               if os.path.isfile(zipMainConfigfile_path):
                   if (ZipFunction.UnZipFile(zipMainConfigfile_path, configDirName)):
                     isDownloaded = True

               dblookupConfigfile_path = configDirName + "/" + drDbLookupFileName
               if os.path.isfile(dblookupConfigfile_path):
                   if os.path.isfile(configDirName + drDbLookupConfigFileName): 
                       os.unlink(configDirName + drDbLookupConfigFileName)
                   if (ZipFunction.UnZipFile(dblookupConfigfile_path, configDirName)):
                       isDownloaded = True
       except Exception as e:
           exc_type, exc_obj, exc_tb = sys.exc_info()
           logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
       finally:           
           #WriteToLog('UnzipConfigFiles Functions Ends')
           return isDownloaded

def UpdateStatus(status):
    lblInfoText.set(status)

def btnFTPCallBack():   
   #WriteToLog('btnFTPCallBack Functions Starts')
   ###---------Delete all files from local directory
   #FTPSync.ClearADirectory(configDirName)
   global ErrorCount, isProcessing
   ###---------Download all files from remote directory
   try:
       isErrorFound = False
       #Download Configruation Files
       if (ErrorCount > 1):
        lblInfoText.set("Connecting... " + str(ErrorCount))
       else:
        lblInfoText.set("Connecting...")
       ftp = FTPSync.getFTPConnection(enHost.get().strip(), enUser.get(), enPass.get(), enDir.get().strip())
       if (ftp !=None):
           threading.Timer(1, UpdateStatus('Connected')).start()
           files = []
           files = FTPSync.getListofFile(ftp)
           if (files.count > 0):
            threading.Timer(1, UpdateStatus('Downloading Config Files')).start()
            for f in files:
                try:
                    if os.path.isfile(configTempDirName + f):
                        os.unlink(configTempDirName + f)
                    FTPSync.downloadFile(f, configTempDirName, ftp)
                except Exception as e:
                    print(e)
                    isErrorFound = True
           ftp.quit()

           #Download Update DR Files
           ftp = FTPSync.getFTPConnection(enHost.get().strip(), enUser.get(), enPass.get(), ftpAdminConfig)
           if (ftp !=None):
               files = []
               files = FTPSync.getListofFile(ftp)
               if (files.count > 0):
                 threading.Timer(1, UpdateStatus('Downloading Update Files')).start()
                 for f in files:
                    try:
                        if os.path.isfile(updateDirName + f):
                            os.unlink(updateDirName + f)
                        FTPSync.downloadFile(f, updateDirName, ftp)
                    except Exception as e:
                        print(e)
               ftp.quit()

           #Check DR Files if any update found
           threading.Timer(1, UpdateStatus('Verifying Update Files')).start()
           CheckVersionNumber.CheckUpdateVersionStatus()

           #Check if previous data exists
           threading.Timer(1, UpdateStatus('Checking Previous Data Exists')).start()
           if (CheckPreviousDataExist()):
              if (isDifferentScheduleDataFound):
                print "isDifferentScheduleDataFound"
                ShowDeletePopupForm()
              elif (isSameScheduleDataFound):
                print "isSameScheduleDataFound"
                ShowDeletePopupForm()
              else:
                print "No Schedule Data Found"
                if (CheckVersionNumber.CopyConfigFiles(1)):
                    AIMDatabase.Delete_DrScheduleTrack()
                    #frmDeletePopups.ClearBackupDirectory()
                    UnzipConfigFiles()
                    ShowSuccessButton()
                    ShowSuccessStatus()
       else:
        ShowNotSuccessStatus()
        ErrorCount = ErrorCount + 1
        if (ErrorCount < 4):
            ProcessWork(1)
        else:
            ErrorCount = 1
            lblInfoText.set("FTP not working")
            lblFTPText.set("Retry")
            frameButton.pack()
   except Exception as e:
       isErrorFound = True
       exc_type, exc_obj, exc_tb = sys.exc_info()
       logging.debug(str(exc_tb.tb_lineno) + " " + e.message)   
       ShowNotSuccessStatus()
       ErrorCount = ErrorCount + 1
       if (ErrorCount < 4):
            ProcessWork(1)
       else:
            ErrorCount = 1
            
   finally:  
       #WriteToLog('btnFTPCallBack Functions Ends')
       isProcessing = False

def ShowSuccessButton():
    global ErrorCount, isProcessDone
    ReadAndSaveLookUpData()                           
    isProcessDone = True
    GetConfigData()            
    lblFTPText.set("Connect")
    btnFTP.pack_forget()
    frameButton.pack()            
    btnNext.pack()
    ErrorCount = 1

def ShowRetrieveButton():
    lblInfoText.set("FTP not working")     
    lblFTPText.set("Retry")
    frameButton.pack()

def btnNexts():
    AimFTP.destroy()
    os.system("python AimScanner.py")

def ProcessWork(types):
   global isProcessDone, isProcessing
   isProcessDone = False
   isProcessing = True
   ShowHideInfoForm(1)
   ShowProcessStatus()
   if (types==1):
      th1 = threading.Thread(target=btnFTPCallBack)
      th1.setDaemon(1)
      th1.start()

### Button Connect Frame
frameButton = Frame(AimFTP, pady=2)
frameButton.pack()

lblFTPText.set("Connect")
btnFTP = Button(frameButton, textvariable =lblFTPText, font=(fontName, btnFontSize), width=btnWidth, command = lambda: ProcessWork(1))
btnFTP.bind("<Return>", lambda event:ProcessWork(1))
btnFTP.pack(side = LEFT)
btnFTP.configure(height=2)

lblNextText.set("Next")
btnNext = Button(frameButton, textvariable =lblNextText, font=(fontName, btnFontSize), width=btnWidth, command = btnNexts)
btnNext.bind("<Return>", lambda event:btnNexts())
btnNext.pack(side = RIGHT)
btnNext.configure(height=2)


## Status bar
frameStatus = Frame(AimFTP, bd=1, relief=SUNKEN, height=18)
frameStatus.pack(side=BOTTOM, fill='x')

lblStaWifiScaner = Label(frameStatus, textvariable=wifiScannerText, font=doubleStatusFontSize)
lblStaWifiScaner.pack(side=LEFT)

sep1 = Separator(frameStatus, orient=VERTICAL)
sep1.pack(side=LEFT, fill="y")

lblStaIpVer = Label(frameStatus, textvariable=ipVerText, font=doubleStatusFontSize)
lblStaIpVer.pack(side=LEFT)

sep2 = Separator(frameStatus, orient=VERTICAL)
sep2.pack(side=LEFT, fill="y")

lblStaDownId = Label(frameStatus, textvariable=downIdText, font=statusFontSize)
lblStaDownId.pack(side=LEFT)

sep3 = Separator(frameStatus, orient=VERTICAL)
sep3.pack(side=LEFT, fill="y")

lblStaTime = Label(frameStatus, textvariable=timeText, font=doubleStatusFontSize)
lblStaTime.pack(side=LEFT)

sep4 = Separator(frameStatus, orient=VERTICAL)
sep4.pack(side=LEFT, fill="y")

lblStaStore = Label(frameStatus, textvariable=stoNameText, font=statusFontSize)
lblStaStore.pack(side=LEFT)

lblStaWifi = Label(frameStatus, font=statusFontSize)
lblStaWifi.pack(side=RIGHT)
img1 = ImageTk.PhotoImage(Image.open(wgIcon))
lblStaWifi.configure(image=img1)

lblStaFTP = Label(frameStatus, font=statusFontSize)
lblStaFTP.pack(side=RIGHT)

lblStaBlue = Label(frameStatus, font=statusFontSize)
lblStaBlue.pack(side=RIGHT)

lblSta2nd = Label(frameStatus, font=statusFontSize)
lblSta2nd.pack(side=RIGHT)

def ShowDefaultStatus():
   lblSta2nd.configure(image='')
   lblSta2nd.image= ''

def ShowProcessStatus():
   img = ImageTk.PhotoImage(Image.open(fyIcon))
   lblStaFTP.configure(image=img)
   lblStaFTP.image= img
   #print "1"

def ShowSuccessStatus():
   img = ImageTk.PhotoImage(Image.open(fgIcon))
   lblStaFTP.configure(image=img)
   lblStaFTP.image= img

def ShowNotSuccessStatus():   
   img = ImageTk.PhotoImage(Image.open(frIcon))
   lblStaFTP.configure(image=img)
   lblStaFTP.image= img

def Show2ndStatus():
   img = ImageTk.PhotoImage(Image.open(secondIcon))
   lblSta2nd.configure(image=img)
   lblSta2nd.image= img

def FillStatusInfo():  
    global ssid, ipaddress
    ssid = os.popen("iwconfig wlan0 \
                | grep 'ESSID' \
                | awk '{print $4}' \
                | awk -F\\\" '{print $2}'").read()    
    
    if (ssid.strip() !=""):
        if ("AIM" in ssid):
            ssid = ssid.replace("AIM", "").strip()
        if ("INV" in ssid):
            ssid = ssid.replace("INV", "").strip()
        print ssid
    if (len(ssid) == 1):
        ssid = "000" + ssid
    elif (len(ssid) == 2):
        ssid = "00" + ssid
    elif (len(ssid) == 3):
        ssid = "0" + ssid
    elif (len(ssid) > 4):
        ssid = ssid[:4]

    ipaddress = os.popen("ifconfig wlan0 \
                     | grep 'inet addr' \
                     | awk -F: '{print $2}' \
                     | awk '{print $1}'").read()
    
    if (ipaddress.strip() !=""):
        currIPAddress = ipaddress.split('.')
        if (len(currIPAddress) > 1):
            myIps = currIPAddress[2].strip()[-1:]
            ipaddress = myIps + "." + currIPAddress[3]
        print ipaddress

    scannerid = AIMDatabase.GetRegistrerScannerId()
    if (len(scannerid) == 1):
        scannerid = "000" + scannerid
    elif (len(scannerid) == 2):
        scannerid = "00" + scannerid
    elif (len(scannerid) == 3):
        scannerid = "0" + scannerid

    wifiScannerText.set(ssid + "\n" + scannerid)
    ipVerText.set(ipaddress.strip() + "\n" + __version__)
    UpdateStatusTime()

def UpdateStatusTime():
    now = datetime.datetime.now()
    myHour = str(now.hour)
    if (len(myHour) == 1):
        myHour = "0" + str(myHour)
    myMin = str(now.minute)
    if (len(myMin) == 1):
        myMin = "0" + str(myMin)
    myDay = str(now.day)
    if (len(myDay) == 1):
        myDay = "0" + str(myDay)
    myMonth = str(now.month)
    if (len(myMonth) == 1):
        myMonth = "0" + str(myMonth)
    timeText.set(myHour + myMin + "\n" + myDay + myMonth + str(now.year)[2:])   

#----- Get Admin Configuration
GetConfigData()
FillStatusInfo()

#Check defautl directory and create if not exists
if not os.path.exists("config"):
    os.makedirs("config")
if not os.path.exists("update"):
    os.makedirs("update")
if not os.path.exists("status"):
    os.makedirs("status")
if not os.path.exists("drdata"):
    os.makedirs("drdata")
if not os.path.exists("configTemp"):
    os.makedirs("configTemp")

#-----------------------------------------------------GPIO----------------------------------------------------------------------
enHost.bind("<FocusIn>", lambda event:currentEntry(enHost))
enUser.bind("<FocusIn>", lambda event:currentEntry(enUser))
enPass.bind("<FocusIn>", lambda event:currentEntry(enPass))
enDir.bind("<FocusIn>", lambda event:currentEntry(enDir))

def ping():
    try:
        while 1:
            time.sleep(0.06)
            AimFTP.event_generate('<<Ping>>', when='tail')
    except:
        pass

def gotPing(event):
    gpiovalue = gpio.get_keypad_value()
    try:
        if (gpiovalue.strip() !=''):
            select(gpiovalue)
    except:
        pass

AimFTP.bind('<<Ping>>', gotPing)
th = threading.Thread(target=ping)
th.setDaemon(1)
th.start()
#------------------------------------------------------GPIO---------------------------------------------------------------------

#----------------------------------------------------Bottom Status-----------------------------------------------------------------------
def CheckWifiStatus():
    global img1, lblStaWifi
    print "Wifi Checking"
    status = False
    try:  
        img1 = ImageTk.PhotoImage(Image.open(wyIcon))
        lblStaWifi.configure(image=img1)
        status = True if os.system("ping -c 1 " + WifiIp) is 0 else False
    except:
        pass
    finally:
        if (status):
            img1 = ImageTk.PhotoImage(Image.open(wgIcon))
            lblStaWifi.configure(image=img1)
        else:
            img1 = ImageTk.PhotoImage(Image.open(wrIcon))
            lblStaWifi.configure(image=img1)
        threading.Timer(WifiCheckInterval, CheckWifiStatus).start()   

threading.Timer(WifiCheckInterval, CheckWifiStatus).start()
#------------------------------------------------------Bottom Status---------------------------------------------------------------------

AIMDatabase.CreateAllTable()
HideFtpForm()
ProcessWork(1)
#WriteToLog('Ends The Program Line')
AimFTP.mainloop()
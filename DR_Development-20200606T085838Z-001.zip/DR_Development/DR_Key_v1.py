import os
import RPi.GPIO as GPIO
import time
import sysv_ipc

#
# Set GPIO mode
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

MATRIX_FIRST = [['ESC', 'F1', 'F2'],
                [7, 8, 9],
                [4, 5, 6],
                [1, 2, 3],
                [0, '2nd', 'F3']]
# Set MATRIX for KeyPad: second key.
MATRIX_SECOND = [['', '', ''],
                 ['ST', 'UP', 'GT'],
                 ['LEFT', '', 'RIGHT'],
                 ['', 'DOWN', ''],
                 ['', '2nd', '']]

# Set PINS for KeyPad.
# Set PINS for KeyPad.
PIN = [[21, 13, 22],
       [26, 6, 23],
       [20, 12, 27],
       [19, 5, 17],
       [16, 24, 18]]

# Set prev_input for Keypad.
PREV_INPUT = [
    [1, 1, 1],
    [1, 1, 1],
    [1, 1, 1],
    [1, 1, 1],
    [1, 1, 1]]
INPUT = [
    [1, 1, 1],
    [1, 1, 1],
    [1, 1, 1],
    [1, 1, 1],
    [1, 1, 1]]

# Set second_key for Keypad
SECOND_KEY_PIN = 24
SECOND_KEY_VALUE = 0
FLAG_KEY = 1

# Set queue
queue_key = 111
mq = sysv_ipc.MessageQueue(queue_key, sysv_ipc.IPC_CREAT)

# Set Row Pins to Input type and set pull-up.
for row in PIN:
    for pin in row:
        GPIO.setup(pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)


# Get the value of keypad.
def get_first_keypad_value():
    for i in range(5):
        for j in range(3):
            INPUT[i][j] = GPIO.input(PIN[i][j])
            if (not PREV_INPUT[i][j]) and INPUT[i][j]:
                if MATRIX_FIRST[i][j] == '2nd':
                    pass

                else:
                    # print MATRIX_FIRST[i][j]
                    mq.send(str(MATRIX_FIRST[i][j]))
            PREV_INPUT[i][j] = INPUT[i][j]


# Get the value of keypad about second key
def get_second_keypad_value():
    for i in range(5):
        for j in range(3):
            INPUT[i][j] = GPIO.input(PIN[i][j])
            if (not PREV_INPUT[i][j]) and INPUT[i][j]:
                if MATRIX_SECOND[i][j] == '2nd':
                    pass
                else:
                    # print MATRIX_SECOND[i][j]
                    mq.send(str(MATRIX_SECOND[i][j]))
            PREV_INPUT[i][j] = INPUT[i][j]


# Detect the second key.
def detect_second_key(*args):
    global FLAG_KEY
    global SECOND_KEY_VALUE
    FLAG_KEY += 1
    print 'FLAG_KEY: {}'.format(FLAG_KEY)
    if (FLAG_KEY % 2) == 0:
        SECOND_KEY_VALUE = 0
    else:
        SECOND_KEY_VALUE = 1


# Get the value for Keypad.
def get_keypad_value():
    try:
        while (True):
            if SECOND_KEY_VALUE == 1:
                get_second_keypad_value()
                time.sleep(0.05)
            else:
                get_first_keypad_value()
                time.sleep(0.05)
    except KeyboardInterrupt:
        GPIO.cleanup()


# Main
if __name__ == '__main__':
    # Set Messagequeue
    GPIO.add_event_detect(SECOND_KEY_PIN, GPIO.RISING, callback=detect_second_key)
    get_keypad_value()

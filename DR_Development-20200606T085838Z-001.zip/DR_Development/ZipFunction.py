#!/usr/bin/env python
# coding: utf-8
__version__ = "1.0.0"

import os
import zipfile

def zipdirectory(src, dst):
    try:
        zf = zipfile.ZipFile("%s.zip" % (dst), "w", zipfile.ZIP_DEFLATED)
        abs_src = os.path.abspath(src)
        for dirname, subdirs, files in os.walk(src):
            for filename in files:
                absname = os.path.abspath(os.path.join(dirname, filename))
                arcname = absname[len(abs_src) + 1:]
                print 'zipping %s as %s' % (os.path.join(dirname, filename), arcname)
                zf.write(absname, arcname)
        zf.close()
    except Exception as e:
       print(e)
    finally:
        return "ZipDirectory"

def ZipFile(srcFileName, outFileName):
    isZipped = False
    try:
        z = zipfile.ZipFile(outFileName, "w", zipfile.ZIP_DEFLATED)
        z.write(srcFileName)
        os.remove(srcFileName)
        z.close()
        isZipped = True
    except Exception as e:
       print(e)
    finally:
        return isZipped

def UnZipFile(path_to_zip_file, directory_to_extract_to):
    isZipped = False
    try:
        z = zipfile.ZipFile(path_to_zip_file, "r")
        z.extractall(directory_to_extract_to)
        z.close()
        isZipped = True
    except Exception as e:
       print(e)
    finally:
       return isZipped


#zipdirectory("Zip", "Zip/testhasnat")
#xyz = ZipFile("testhasnat.txt", "ZIP/testhasnat.zip")
#xyz = ZipFile("drData_23443904012017.csv", "drData_23443904012017.zip")
#xyz = UnZipFile("config/02a43c7d-1e46-449e-91a1-dfb002e3577e_20161026090615.zip", "config")
#print xyz
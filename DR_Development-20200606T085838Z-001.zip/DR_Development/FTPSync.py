#!/usr/bin/env python
# coding: utf-8
__version__ = "1.1"

import os
from ftplib import FTP
#ftp = FTP('www.aiminv.net')     # connect to host, default port
#ftp.login(user='hasnat', passwd = 'aiminv')
#ftp.cwd('/ACCDataFile/DRConfig/')

def getFTPConnection(host, user, password, remoteDir):
    try:
        ftp = FTP(host)     # connect to host, default port
        ftp.login(user=user, passwd = password)
        ftp.cwd("/" + remoteDir + "/")
        return ftp
    except Exception as e:
        print(e)

def downloadFile(remoteFileName, dstSave, ftp):
    isDownloaded = False
    try:
        filename = remoteFileName
        localfile = open(dstSave + filename, 'wb')
        ftp.retrbinary('RETR ' + filename, localfile.write, 1024)
        #ftp.quit()
        localfile.close()
        print "Download Done" + remoteFileName
        isDownloaded = True
    except Exception as e:
        print(e)
        isDownloaded = False
    finally:
        return isDownloaded

def uploadFile(localFileName, localDirectory, ftp):
    isUploaded = False
    try:
        filename = localFileName
        ftp.storbinary('STOR ' + filename, open(localDirectory + filename, 'rb'))
        print "Upload Done" + localFileName
        isUploaded = True
    except Exception as e:
        print(e)
        isUploaded = False
    finally:
        ftp.quit()
        return isUploaded

def CheckFileExist(fileName, ftp):
    isFileFound = False
    try:        
       newfiles = []
       newfiles = getListofFile(ftp)
       if (newfiles.count > 0):
        for f in newfiles:
            try:
                if (f == fileName):
                   isFileFound = True
                   break
            except Exception as e:
                print(e)
    except Exception as e:
        print(e)
    finally:
        return isFileFound

def getListofFile(ftp):
    files = []
    try:
        files = ftp.nlst()
    except ftplib.error_perm, resp:
        if str(resp) == "550 No files found":
            print "No files in this directory"
        else:
            raise

    return files

    #for f in files:
    #    print f


###---------Delete all files from local directory
def ClearADirectory(dirName):
    dFiles = []
    folder = dirName
    dFiles = os.listdir(folder)
    for df in dFiles:
        file_path = os.path.join(folder, df)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
        except Exception as e:
            print(e)
    

#placeFile('02a43c7d-1e46-449e-91a1-dfb002e3577e_20161026090615.zip', "config")
#grabFile('02a43c7d-1e46-449e-91a1-dfb002e3577e_20161026090615.zip', "Config")
#getListofFile()
import RPi.GPIO as GPIO
#import time
__version__ = "1.4"

# Set GPIO mode
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

MATRIX_FIRST = [['ESC', 'F2', 'F1'],
                [7, 8, 9],
                [4, 5, 6],
                [1, 2, 3],
                [0, '2nd', 'F3']]

# Set MATRIX for KeyPad: second key.
MATRIX_SECOND = [['CLO', '', ''],
                 ['ST', 'UP', 'GT'],
                 ['LEFT', 'TR', 'RIGHT'],
                 ['HID', 'DOWN', 'DEL'],
                 ['NEX', '2nd', '']]


ROW = [5,6,13,19,26]
COL = [16,20,21]

SECOND_KEY_VALUE = 0

for j in range(3):
    GPIO.setup(COL[j], GPIO.OUT)
    GPIO.output(COL[j], 1)

for i in range (5):
    GPIO.setup(ROW[i], GPIO.IN, pull_up_down = GPIO.PUD_UP)

# Get the value of keypad.
def get_first_keypad_value():
    global SECOND_KEY_VALUE
    firstVal = ''
    try:
       for j in range (3):
            GPIO.output(COL[j],0)
            for i in range(5):
                if GPIO.input (ROW[i]) == 0:
                   if MATRIX_FIRST[i][j] == '2nd':
                        SECOND_KEY_VALUE = 1
                        firstVal = '2nd1'
                        pass
                   else:
                        firstVal = str(MATRIX_FIRST[i][j])

                   while (GPIO.input(ROW[i]) == 0):
                        pass

            GPIO.output(COL[j],1)
    except Exception as e:
       print(e)
    finally:
        return firstVal



# Get the value of keypad about second key
def get_second_keypad_value():
    global SECOND_KEY_VALUE
    secondVal = ''
    try:
         for j in range (3):
            GPIO.output(COL[j],0)
            for i in range(5):
                if GPIO.input (ROW[i]) == 0:
                   if MATRIX_SECOND[i][j] == '2nd':
                        SECOND_KEY_VALUE = 0
                        secondVal = '2nd2'
                        pass
                   else:
                        secondVal = str(MATRIX_SECOND[i][j])
                   while (GPIO.input(ROW[i]) == 0):
                        pass
            GPIO.output(COL[j],1)
    except Exception as e:
       print(e)
    finally:
        return secondVal


# Get the value for Keypad.
def get_keypad_value():
    global SECOND_KEY_VALUE
    gpioval = ''
    try:
        if SECOND_KEY_VALUE == 1:
            gpioval = get_second_keypad_value()
            if (gpioval !=''):
                return gpioval
        else:
            gpioval = get_first_keypad_value()
            if (gpioval !=''):
                return gpioval
        #time.sleep(0.05)
    except KeyboardInterrupt:
        GPIO.cleanup()
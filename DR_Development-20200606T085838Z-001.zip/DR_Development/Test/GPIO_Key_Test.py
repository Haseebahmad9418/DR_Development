import RPi.GPIO as GPIO
import time
__version__ = "1.4"

# Set GPIO mode
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

MATRIX_FIRST = [['ESC', 'F2', 'F1'],
                [7, 8, 9],
                [4, 5, 6],
                [1, 2, 3],
                [0, '2nd', 'F3']]

# Set MATRIX for KeyPad: second key.
MATRIX_SECOND = [['CLO', '', ''],
                 ['ST', 'UP', 'GT'],
                 ['LEFT', 'TR', 'RIGHT'],
                 ['HID', 'DOWN', 'DEL'],
                 ['NEX', '2nd', '']]


ROW = [5,6,13,19,26]
COL = [16,20,21]

SECOND_KEY_VALUE = 0
CurrentKey=''

for j in range(3):
    GPIO.setup(COL[j], GPIO.OUT)
    GPIO.output(COL[j], 1)

for i in range (5):
    GPIO.setup(ROW[i], GPIO.IN, pull_up_down = GPIO.PUD_UP)
        

# Get the value of keypad.
def get_first_keypad_value():
    global SECOND_KEY_VALUE, CurrentKey
    firstVal = ''
    tmpVal = ''
    try:
       for j in range (3):
            GPIO.output(COL[j],0)
            for i in range(5):
                if GPIO.input (ROW[i]) == 0:                   
                   tmpVal = str(MATRIX_FIRST[i][j])                    
                   
                   if tmpVal==CurrentKey:               
                        firstVal = ''
                   else:
                        CurrentKey=tmpVal                        
                        firstVal = tmpVal
                   break
            GPIO.output(COL[j],1)        
       else:
           if tmpVal != CurrentKey: 
              CurrentKey = ''
    except Exception as e:
       print(e)
    finally:
        return firstVal


# Get the value of keypad about second key
def get_second_keypad_value():
    global SECOND_KEY_VALUE, CurrentKey
    firstVal = ''
    tmpVal = ''
    try:       
       for j in range (3):
            GPIO.output(COL[j],0)
            for i in range(5):
                if GPIO.input (ROW[i]) == 0:
                   tmpVal = str(MATRIX_SECOND[i][j])                    
                   
                   if tmpVal==CurrentKey:
                        firstVal = ''
                   else:
                        CurrentKey=tmpVal
                        if (tmpVal == "2nd"):
                            SECOND_KEY_VALUE = 0
                            firstVal = "2nd2"                            
                        else:
                            firstVal = tmpVal
                   break

            GPIO.output(COL[j],1)
       else:
            if tmpVal != CurrentKey: 
                CurrentKey = ''
    except Exception as e:
       print(e)
    finally:
        return firstVal


# Get the value for Keypad.
def get_keypad_value():
    gpioval = ''
    try:
        while (True):
            if SECOND_KEY_VALUE == 1:
                gpioval = get_second_keypad_value()
            else:
                gpioval = get_first_keypad_value()

            if (gpioval !=''):            
                print gpioval
    except KeyboardInterrupt:
        GPIO.cleanup()
    finally:
        GPIO.cleanup()


get_keypad_value()

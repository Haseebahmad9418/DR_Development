#!/usr/bin/env python
# coding: utf-8
__version__ = "1.7"
__Date__ = "09SEP2018"

from xml.dom.minidom import parse
import xml.dom.minidom
import os
from configfile import *

def ReadDRConfigData():
    dFiles = []
    cData = {}
    try:
        dFiles = os.listdir(configDirName)
        for df in dFiles:
            cFilePath = configDirName + "/" + drConfigFileName
            if os.path.isfile(cFilePath):
                cData = ReadConfigFile(cFilePath)
                break;
    except Exception as e:
        print(e)
    finally:
        return cData
    
def ReadAdminConfigData():
   dFiles = []
   cData = {}
   try:
       dFiles = os.listdir(configDirName)
       for df in dFiles:
           adminConfig_path = configDirName + "/" + drAdminConfigFileName
           if os.path.isfile(adminConfig_path):
                cData = ReadAdminConfigFile(adminConfig_path)
                break;
   except Exception as e:
       print(e)
   finally:
       return cData

def ReadBarcodePrefixHeadConfigData():
   dFiles = []
   cData = {}
   try:
       dFiles = os.listdir(configDirName)
       for df in dFiles:
           adminConfig_path = configDirName + "/" + drBarcodePrefixHeadConfigFileName
           if os.path.isfile(adminConfig_path):
                cData = ReadBarcodePrefixHeadConfigFile(adminConfig_path)
                break;
   except Exception as e:
       print(e)
   finally:
       return cData

def ReadBarcodePrefixDetailsConfigData():
   dFiles = []
   cData = {}
   try:
       dFiles = os.listdir(configDirName)
       for df in dFiles:
           adminConfig_path = configDirName + "/" + drBarcodePrefixDetailsConfigFileName
           if os.path.isfile(adminConfig_path):
                cData = ReadBarcodePrefixDetailsConfigFile(adminConfig_path)
                break;
   except Exception as e:
       print(e)
   finally:
       return cData

def GetAllPrefixAndBarcodeType(macId):
    barcodePrefix = ""
    barcodeType = ""
    prefixGroupId = 0
    cData = {}
    cData1 = {}
    cData = ReadBarcodePrefixHeadConfigData()
    if (len(cData) > 0):
        totDataCount = int(cData.get('BPH_RowCount')) 
        for x in range(totDataCount):
            if (macId == cData.get('BPH' + str(x) + '_BarcodeMacId')):
                prefixGroupId =  int(cData.get('BPH' + str(x) + '_PrefixsGroupId'))
                break;

    if (prefixGroupId > 0):
        cData1 = ReadBarcodePrefixDetailsConfigData()
        if (len(cData1) > 0):
            totDataCount1 = int(cData1.get('BPD_RowCount')) 
            for x in range(totDataCount1):
                if (str(prefixGroupId) == cData1.get('BPD' + str(x) + '_PrefixsGroupId')):
                    barcodePrefix = barcodePrefix + cData1.get('BPD' + str(x) + '_BarcodePrefix') + "~"
                    barcodeType = barcodeType + cData1.get('BPD' + str(x) + '_BarcodeType') + "~"

    return barcodePrefix + ";" + barcodeType

def ReadConfigFile(xmlDirName):
    # Open XML document using minidom parser
    D = {}
    DOMTree = xml.dom.minidom.parse(xmlDirName)
    collection = DOMTree.documentElement

    # Get Schedules Information
    schedules = collection.getElementsByTagName("Common")
    # Print detail of each movie.
    for schedule in schedules:       
       try:
            D['ScheduleId'] = schedule.getElementsByTagName('ScheduleId')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['ScheduleCode'] = schedule.getElementsByTagName('ScheduleCode')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['StoreName'] = schedule.getElementsByTagName('StoreName')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['DownloadCode'] = schedule.getElementsByTagName('DownloadCode')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['LoopBack'] = schedule.getElementsByTagName('LoopBack')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['KPh'] = schedule.getElementsByTagName('KPh')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['PPh'] = schedule.getElementsByTagName('PPh')[0].childNodes[0].data
       except IndexError:
           pass

    # Get all the locations in the collection
    locations = collection.getElementsByTagName("Location")

    # Print detail of each movie.
    for location in locations:       
       try:
            D['L_LocationID'] = location.getElementsByTagName('LocationID')[0].childNodes[0].data
       except IndexError:
           pass

       #try:
       #     D['L_InventoryID'] = location.getElementsByTagName('InventoryID')[0].childNodes[0].data
       #except IndexError:
       #    pass

       try:
            D['L_Description'] = location.getElementsByTagName('Description')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['L_Fieldlength'] = location.getElementsByTagName('Fieldlength')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['L_ExactFieldLength'] = location.getElementsByTagName('ExactFieldLength')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['L_DoubleKey'] = location.getElementsByTagName('DoubleKey')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['L_Forced'] = location.getElementsByTagName('Forced')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['L_DbLookup'] = location.getElementsByTagName('DbLookup')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['L_BarCode'] = location.getElementsByTagName('BarCode')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['L_PlaySoundAccept'] = location.getElementsByTagName('PlaySoundAccept')[0].childNodes[0].data
       except IndexError:
           pass
    

    # Get all the inventories in the collection
    inventories = collection.getElementsByTagName("InventoryData")
    D['I_RowCount'] = str(len(inventories))
        
    x = 0
    for inventory in inventories:
        try:
            D['I' + str(x) + '_DataID'] = inventory.getElementsByTagName('DataID')[0].childNodes[0].data
        except IndexError:
            pass

        try:
            D['I' + str(x) + '_InventoryID'] = inventory.getElementsByTagName('InventoryID')[0].childNodes[0].data
        except IndexError:
            pass

        try:
            D['I' + str(x) + '_Description'] = inventory.getElementsByTagName('Description')[0].childNodes[0].data
        except IndexError:
            pass

        try:
            D['I' + str(x) + '_Fieldlength'] = inventory.getElementsByTagName('Fieldlength')[0].childNodes[0].data
        except IndexError:
            pass

        try:
            D['I' + str(x) + '_ExactFieldLength'] = inventory.getElementsByTagName('ExactFieldLength')[0].childNodes[0].data
        except IndexError:
            pass

        try:
            D['I' + str(x) + '_DoubleKey'] = inventory.getElementsByTagName('DoubleKey')[0].childNodes[0].data
        except IndexError:
            pass

        try:
            D['I' + str(x) + '_Type'] = inventory.getElementsByTagName('Type')[0].childNodes[0].data
        except IndexError:
            pass

        try:
            D['I' + str(x) + '_BarCode'] = inventory.getElementsByTagName('BarCode')[0].childNodes[0].data
        except IndexError:
            pass

        try:
            D['I' + str(x) + '_Forced'] = inventory.getElementsByTagName('Forced')[0].childNodes[0].data
        except IndexError:
            pass

        try:
            D['I' + str(x) + '_DbLookup'] = inventory.getElementsByTagName('DbLookup')[0].childNodes[0].data
        except IndexError:
            pass
        try:
            D['I' + str(x) + '_ShowsInReport'] = inventory.getElementsByTagName('ShowsInReport')[0].childNodes[0].data
        except IndexError:
            pass

        try:
            D['I' + str(x) + '_PlaySoundAccept'] = inventory.getElementsByTagName('PlaySoundAccept')[0].childNodes[0].data
        except IndexError:
           pass

        x = x + 1

    # Get all the Prices in the collection
    prices = collection.getElementsByTagName("Price")
    #print("Total Price Found=%s" % len(prices))

    for price in prices:
       try:
            D['P_PriceID'] = price.getElementsByTagName('PriceID')[0].childNodes[0].data
       except IndexError:
           pass

       #try:
       #     D['P_InventoryID'] = price.getElementsByTagName('InventoryID')[0].childNodes[0].data
       #except IndexError:
       #    pass

       try:
            D['P_Description'] = price.getElementsByTagName('Description')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['P_Fieldlength'] = price.getElementsByTagName('Fieldlength')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['P_ExactFieldLength'] = price.getElementsByTagName('ExactFieldLength')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['P_DoubleKey'] = price.getElementsByTagName('DoubleKey')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['P_Forced'] = price.getElementsByTagName('Forced')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['P_DbLookup'] = price.getElementsByTagName('DbLookup')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['P_DefaultPrice'] = price.getElementsByTagName('DefaultPrice')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['P_BarCode'] = price.getElementsByTagName('BarCode')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['P_ShowsInReport'] = price.getElementsByTagName('ShowsInReport')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['P_PlaySoundAccept'] = price.getElementsByTagName('PlaySoundAccept')[0].childNodes[0].data
       except IndexError:
           pass


    # Get all the Quantities in the collection
    quantities = collection.getElementsByTagName("Qty")
    #print("Total Qty Found=%s" % len(prices))

    for quantity in quantities:
       try:
            D['Q_QtyID'] = quantity.getElementsByTagName('QtyID')[0].childNodes[0].data
       except IndexError:
           pass

       #try:
       #     D['Q_InventoryID'] = quantity.getElementsByTagName('InventoryID')[0].childNodes[0].data
       #except IndexError:
       #    pass

       try:
            D['Q_Description'] = quantity.getElementsByTagName('Description')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Q_Name'] = quantity.getElementsByTagName('Name')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Q_DefaultQty'] = quantity.getElementsByTagName('DefaultQty')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Q_Fieldlength'] = quantity.getElementsByTagName('Fieldlength')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Q_ExactFieldLength'] = quantity.getElementsByTagName('ExactFieldLength')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Q_BarCode'] = quantity.getElementsByTagName('BarCode')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Q_Forced'] = quantity.getElementsByTagName('Forced')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Q_DbLookup'] = quantity.getElementsByTagName('DbLookup')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Q_Counteachpcs'] = quantity.getElementsByTagName('Counteachpcs')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Q_StartLocation'] = quantity.getElementsByTagName('StartLocation')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Q_EndLocation'] = quantity.getElementsByTagName('EndLocation')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Q_ShowsInReport'] = quantity.getElementsByTagName('ShowsInReport')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Q_PlaySoundAccept'] = quantity.getElementsByTagName('PlaySoundAccept')[0].childNodes[0].data
       except IndexError:
           pass

    return D

def ReadAdminConfigFile(xmlDirName):
    # Open XML document using minidom parser
    D = {}
    DOMTree = xml.dom.minidom.parse(xmlDirName)
    collection = DOMTree.documentElement

    # Get all the locations in the collection
    adminConfigs = collection.getElementsByTagName("AdminConfig")

    # Print detail of each movie.
    for adminConfig in adminConfigs:       
       try:
            D['LanguageId'] = adminConfig.getElementsByTagName('LanguageId')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Wifi_SSID'] = adminConfig.getElementsByTagName('Wifi_SSID')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Wifi_PSK'] = adminConfig.getElementsByTagName('Wifi_PSK')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Wifi_Prefix'] = adminConfig.getElementsByTagName('Wifi_Prefix')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Wifi_Postfix'] = adminConfig.getElementsByTagName('Wifi_Postfix')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Wifi1_SSID'] = adminConfig.getElementsByTagName('Wifi1_SSID')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Wifi1_PSK'] = adminConfig.getElementsByTagName('Wifi1_PSK')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Wifi1_Prefix'] = adminConfig.getElementsByTagName('Wifi1_Prefix')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['Wifi1_Postfix'] = adminConfig.getElementsByTagName('Wifi1_Postfix')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['FTP_Host'] = adminConfig.getElementsByTagName('FTP_Host')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['FTP_User'] = adminConfig.getElementsByTagName('FTP_User')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['FTP_Pass'] = adminConfig.getElementsByTagName('FTP_Pass')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['FTP1_Host'] = adminConfig.getElementsByTagName('FTP1_Host')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['FTP1_User'] = adminConfig.getElementsByTagName('FTP1_User')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['FTP1_Pass'] = adminConfig.getElementsByTagName('FTP1_Pass')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['FTP_DrData'] = adminConfig.getElementsByTagName('FTP_DrData')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['FTP_DrConfigDir'] = adminConfig.getElementsByTagName('FTP_DrConfigDir')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['FTP_DrUpdateDir'] = adminConfig.getElementsByTagName('FTP_DrUpdateDir')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['TimeSyncServer'] = adminConfig.getElementsByTagName('TimeSyncServer')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['ManualSync'] = adminConfig.getElementsByTagName('ManualSync')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['XNumSync'] = adminConfig.getElementsByTagName('XNumSync')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['XTimeSync'] = adminConfig.getElementsByTagName('XTimeSync')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['GoodSoundPitch'] = adminConfig.getElementsByTagName('GoodSoundPitch')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['BadSoundPitch'] = adminConfig.getElementsByTagName('BadSoundPitch')[0].childNodes[0].data
       except IndexError:
           pass

       try:
            D['ReviewName'] = adminConfig.getElementsByTagName('ReviewName')[0].childNodes[0].data
       except IndexError:
           pass

    return D

def ReadMacConfigFile(xmlDirName):
    # Open XML document using minidom parser
    D = {}
    DOMTree = xml.dom.minidom.parse(xmlDirName)
    collection = DOMTree.documentElement

    # Get all the locations in the collection
    adminConfigs = collection.getElementsByTagName("MacConfig")
    D['M_RowCount'] = str(len(adminConfigs))
    x = 0

    # Print detail of each movie.
    for adminConfig in adminConfigs:
         try:
            D['M' + str(x) + '_Mac_No'] = adminConfig.getElementsByTagName('Mac_No')[0].childNodes[0].data
         except IndexError:
            pass

         try:
            D['M' + str(x) + '_Mac_Value'] = adminConfig.getElementsByTagName('Mac_Value')[0].childNodes[0].data
         except IndexError:
            pass

         x = x + 1

    return D

def ReadBarcodePrefixHeadConfigFile(xmlDirName):
    # Open XML document using minidom parser
    D = {}
    DOMTree = xml.dom.minidom.parse(xmlDirName)
    collection = DOMTree.documentElement

    # Get all the locations in the collection
    adminConfigs = collection.getElementsByTagName("BarcodePrefixHead")
    D['BPH_RowCount'] = str(len(adminConfigs))
    x = 0

    # Print detail of each movie.
    for adminConfig in adminConfigs:
         try:
            D['BPH' + str(x) + '_BarcodeMacId'] = adminConfig.getElementsByTagName('BarcodeMacId')[0].childNodes[0].data
         except IndexError:
            pass

         try:
            D['BPH' + str(x) + '_MacRegisteredId'] = adminConfig.getElementsByTagName('MacRegisteredId')[0].childNodes[0].data
         except IndexError:
            pass

         try:
            D['BPH' + str(x) + '_PrefixsGroupId'] = adminConfig.getElementsByTagName('PrefixsGroupId')[0].childNodes[0].data
         except IndexError:
            pass

         x = x + 1

    return D

def ReadBarcodePrefixDetailsConfigFile(xmlDirName):
    # Open XML document using minidom parser
    D = {}
    DOMTree = xml.dom.minidom.parse(xmlDirName)
    collection = DOMTree.documentElement

    # Get all the locations in the collection
    adminConfigs = collection.getElementsByTagName("BarcodePrefixDetail")
    D['BPD_RowCount'] = str(len(adminConfigs))
    x = 0

    # Print detail of each movie.
    for adminConfig in adminConfigs:
         try:
            D['BPD' + str(x) + '_PrefixsGroupId'] = adminConfig.getElementsByTagName('PrefixsGroupId')[0].childNodes[0].data
         except IndexError:
            pass

         try:
            D['BPD' + str(x) + '_BarcodePrefix'] = adminConfig.getElementsByTagName('BarcodePrefix')[0].childNodes[0].data
         except IndexError:
            pass

         try:
            D['BPD' + str(x) + '_BarcodeType'] = adminConfig.getElementsByTagName('BarcodeType')[0].childNodes[0].data
         except IndexError:
            pass

         x = x + 1

    return D


#data = ReadConfigFile("config/02a43c7d-1e46-449e-91a1-dfb002e3577e_20161026090615.xml")
#print ("Total Length=" + str(len(data)))
#for Key,Value in data.iteritems():
#  print Key,"==",Value
#ReadBarcodePrefixHeadConfigData()
#ReadBarcodePrefixDetailsConfigData()
#GetAllPrefixAndBarcodeType("DC:2C:26:01:64:D5")
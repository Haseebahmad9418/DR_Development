#!/usr/bin/env python
# coding: utf-8
__version__ = "1.0.0"

from Tkinter import *   ## notice capitalized T in Tkinter
import Tkinter as tk
import os
from configfile import *
import threading
from threading import Thread
import time
from DR_Key import *
import sys

AimInitialize = tk.Tk()
AimInitialize.title("AIM Initialize")
AimInitialize.resizable(0, 0)
w, h = 480, 320
AimInitialize.geometry("%dx%d+0+0" % (w, h))
#AimInitialize.iconbitmap(iconPath)
AimInitialize.wm_attributes('-fullscreen', 'true')

#-------- Global Variable Start Here
fontName = "Helvetica"
fontSize = 25

lblUserText = StringVar()
sec = 1
keyString = ''

####---------------------- GPIO Start ----------------------------------------------------------------------------------------
def select(value):
    try:
        global keyString
        print value
        if value == "DEL":
           if (keyString.strip() !=''):
              keyString = keyString[:-1]
        elif value == "ESC":
           keyString = ''
        elif value == "LEFT":
           print value
        elif value == "RIGHT":
           print value
        elif value == "UP":
           print value
        elif value == "DOWN":
           print value
        elif value == "F2":
           if (keyString == "1234567890"):
               print "DONE"
        elif value == "2nd1":
           print value
        elif value == "2nd2":
           print value
        elif value == "NEX":
           print value
        elif value == "HID":
           print value
        elif value == "CLO":
           os._exit(1)
        elif (value == "0" or value == "1" or value == "2" or value == "3"  or value == "4" or value == "5" or 
                value == "6" or value == "7" or value == "8" or value == "9"):
            keyString = keyString + value
    except Exception as e:
        print 'get key value Exception: {}'.format(e)
####---------------------- GPIO Ends ----------------------------------------------------------------------------------------
frameLabel = Frame(AimInitialize, height=70)
frameLabel.pack()

frame1 = Frame(AimInitialize, pady=5)
frame1.pack()

lblUserText.set(str(sec))
lblUser = Label(frame1, textvariable =lblUserText, font=(fontName, fontSize))
lblUser.pack(side = LEFT)

#----------------------------------------------------GPIO-----------------------------------------------------------------------
def ping():
    try:
        while 1:
            time.sleep(0.06)
            AimInitialize.event_generate('<<Ping>>', when='tail')
    except:
        pass

def gotPing(event):
    gpiovalue = get_keypad_value()
    try:
        if (gpiovalue.strip() !=''):
            select(gpiovalue)
    except:
        pass

AimInitialize.bind('<<Ping>>', gotPing)
th = threading.Thread(target=ping)
th.setDaemon(1)
th.start()

def checkKey():
    try:
        while 1:
            time.sleep(1)
            AimInitialize.event_generate('<<INIT>>', when='tail')
    except:
        pass

def finalKey(event):
    global keyString
    global sec
    global initializeMaxTime
    try:
        if (keyString !=""):
            print keyString
            lblUserText.set(keyString)
        else:
            sec = sec + 1
            lblUserText.set(str(sec))
            if (sec == initializeMaxTime):
                AimInitialize.destroy()
                os.system("python AimScanner.py")
    except:
        pass

AimInitialize.bind('<<INIT>>', finalKey)
th = threading.Thread(target=checkKey)
th.setDaemon(1)
th.start()
#------------------------------------------------------GPIO---------------------------------------------------------------------

AimInitialize.mainloop()

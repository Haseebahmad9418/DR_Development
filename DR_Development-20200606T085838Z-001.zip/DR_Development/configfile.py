#!/usr/bin/env python
# coding: utf-8

#Local config and update directory
iconPath = "@/home/pi/AIMLogo.xbm"
configDirName = "config/"
updateDirName = "update/"
statusDirName = "status/"
drDataDirName = "drdata/"
configTempDirName = "configTemp/"

#All Zip File Config Name
drConfigZipFileNameNew = "RangerConfig.zip"
drConfigZipFileName = "DrConfig.zip"
drDbLookupFileName = "DbLookup.zip"

#All Real Config File Name
drConfigFileName = "DRConfig.xml"
drAdminConfigFileName = "AdminConfig.xml"
drMacConfigFileName = "MacConfig.xml"
drBarcodePrefixHeadConfigFileName = "BarcodePrefixHead.xml"
drBarcodePrefixDetailsConfigFileName = "BarcodePrefixDetail.xml"
drDbLookupConfigFileName = "DbLookup.csv"
drTimeConfigFileName = "time.txt"
drStatusConfigFileName = "status.txt"

#List of all files which need to check and update during FTP download
updateFileNames = "configfile.py~AIMMain.py~AIMDr.py~AIMLogin.py~AIMWifi.py~AimFTP.py~AimScanner.py~AIMDatabase.py~FTPSync.py~ZipFunction.py~XMLReader.py~AIMSyncService.py~AIMSyncPopup.py~AIMManualSync.py~AIMReview.py~DR_Key.py~DR_Key_GPIO.py~AIMSound.py~AIMDrRecovery.py~2B.png~WG.png~WR.png~WY.png~FG.png~FR.png~FY.png~BG.png~BR.png~BY.png"

# Bootom Bar image file
wgIcon = "WG.png"
wrIcon = "WR.png"
wyIcon = "WY.png"
fgIcon = "FG.png"
frIcon = "FR.png"
fyIcon = "FY.png"
bgIcon = "BG.png"
brIcon = "BR.png"
byIcon = "BY.png"
secondIcon = "2B.png"

#At the initialize count will be up 10 and user can reset db by the initializeResetKey
initializeMaxTime = 10
initializeResetKey = "1234567890"
#initializeResetKey = "111"

# Validation failed sound plays?
isPlaySound = True
badSoundFile = "bad.wav"
goodSoundFile = "good.wav"

# Manually sync confirmation key
syncConfirmKey = "123"

# barcode length settings
UPCALength =12
EAN13Length =13

#Login system On/off settings
IsLogging = True

#IP for status check, time in seconds
WifiIp ="192.168.0.100"
#WifiIp ="172.16.0.1"
WifiCheckInterval = 200
FtpIp = "192.168.0.100"
#FtpIp = "172.16.0.5"
FtpCheckInterval = 120
BluetoothCheckInterval = 300

RepeatText = "(Repeat Entry)"
#Key Pad Conditon 
IsGpioKeyPad = True
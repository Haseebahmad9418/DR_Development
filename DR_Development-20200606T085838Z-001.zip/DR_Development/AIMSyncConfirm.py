#!/usr/bin/env python
# coding: utf-8
__version__ = "1.0"

from Tkinter import *   ## notice capitalized T in Tkinter
import Tkinter as tk
import pickle
import os
from configfile import *
import threading
from threading import Thread
import time
from DR_Key import *
import sys
import XMLReader
from AIMManualSync import *
import tkMessageBox

AimSyncConfirm = tk.Tk()
AimSyncConfirm.title("Syncing Confirmation")
AimSyncConfirm.resizable(0, 0)
w, h = 400, 150
AimSyncConfirm.geometry("%dx%d+0+0" % (w, h))
#AimSyncConfirm.iconbitmap(iconPath)

#-------- Global Variable Start Here
fontName = "Helvetica"
fontSize = 16

lblReadyText = StringVar()
lblOKText = StringVar()
lblCancelText = StringVar()
lblSyncText = StringVar()
#-------- Global Variable Ends Here

####---------------------- GPIO Starts ----------------------------------------------------------------------------------------
def select(value):
    try:
        print value        
        if value == "ESC":
            submitCancel()
        elif value == "F2":
            submitOK()
        elif value == "2nd1":
           print value
        elif value == "2nd2":
           print value
        elif (value == "0" or value == "1" or value == "2" or value == "3"  or value == "4" or value == "5" or 
                value == "6" or value == "7" or value == "8" or value == "9"):
            pos= txtInput.index(INSERT)
            txtInput.insert(pos,value)
    except Exception as e:
        print 'get key value Exception: {}'.format(e)
####---------------------- GPIO Ends ----------------------------------------------------------------------------------------

frameSync = Frame(AimSyncConfirm, pady=5)
frameSync.pack()

frame1 = Frame(AimSyncConfirm, pady=5)
frame1.pack()

lblReadyText.set("Getting Data Ready to Transmit")
lblReady = Label(frame1, textvariable =lblReadyText, font=(fontName, fontSize))
lblReady.pack()

txtInput = Entry(frame1, width=18, font=(fontName, fontSize), fg="red")
txtInput.focus()
txtInput.pack()

frameButton = Frame(AimSyncConfirm, pady=5)
frameButton.pack()

def submitOK():
   lengthText = len(txtInput.get().strip())
   if (lengthText > 0):
      inputText = txtInput.get().strip()
      if (inputText == syncConfirmKey):
         print "Sync Data"
         isDone = SyncService.SyncData()
         if (isDone == "DONE" or isDone == ""):
            submitCancel()
         else:
            tkMessageBox.showinfo("Sync Error", isDone)
         
def submitCancel():
   AimSyncConfirm.destroy()

lblOKText.set("OK")
btnOK = Button(frameButton, textvariable =lblOKText, width=12, font=(fontName, fontSize), command = submitOK) 
btnOK.bind("<Return>", lambda event:submitOK())
btnOK.pack(side = LEFT)

lblCancelText.set("Cancel")
btnCancel = Button(frameButton, textvariable =lblCancelText, width=12, font=(fontName, fontSize), command = submitCancel) 
btnCancel.bind("<Return>", lambda event:submitCancel())
btnCancel.pack(side = RIGHT)


#----------------------------------------------------GPIO-----------------------------------------------------------------------
def ping():
    try:
        while 1:
            time.sleep(0.06)
            AimSyncConfirm.event_generate('<<Ping>>', when='tail')
    except:
        pass

def gotPing(event):
    gpiovalue = get_keypad_value()
    try:
        if (gpiovalue.strip() !=''):
            select(gpiovalue)
    except:
        pass

AimSyncConfirm.bind('<<Ping>>', gotPing)
th = threading.Thread(target=ping)
#th.setDaemon(1)
#th.start()
#------------------------------------------------------GPIO---------------------------------------------------------------------

AimSyncConfirm.mainloop()

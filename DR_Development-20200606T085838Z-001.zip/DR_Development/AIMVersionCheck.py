#!/usr/bin/env python
# coding: utf-8
__version__ = "1.1"

import os
import filecmp
import md5
import time
import FTPSync
from configfile import *
import XMLReader
import shutil

class CheckVersionNumber():
    @staticmethod
    def CheckVersion(updateDirName, updateScriptName, currentScriptName):
       ###---------Extract all zip files from local directory
       fileAPath = ""
       fileBPath = ""
       curFile = ""
       status = False
       isFound = False
       try:
           dFiles = os.listdir(updateDirName)
           for df in dFiles:
               updateFile_path = updateDirName + "/" + updateScriptName
               if os.path.exists(updateFile_path):
                #print "Yep - found it"
                fileAPath = updateFile_path
                break

           files = [f for f in os.listdir('.') if os.path.isfile(f)]
           for f in files:
            if (f == currentScriptName):
                #print f
                fileBPath = currentScriptName
                isFound = True
                break
           if (isFound):
               #print filecmp.cmp(fileAPath, fileBPath)
               if filecmp.cmp(fileAPath, fileBPath) == False:
                   status = True
                   #hash1 = md5.new()
                   #hash1.update(fileAPath)
                   #hash1.digest() # this generates the checksum

                   #hash2 = md5.new()
                   #hash1.update(fileBPath)
                   #hash2.digest() # this generates the checksum

                   #moddate = os.stat(fileAPath)[8] # there are 10 attributes this call returns and you want the next to last
                   #moddate1 = os.stat(fileBPath)[8] # there are 10 attributes this call returns and you want the next to last
           
                   #print moddate
                   #print moddate1

                   ##print time.ctime(moddate)
                   ##print time.ctime(moddate1)
                   #if float(moddate) > float(moddate1):
                   #    status =  True
           else:
                shutil.copy2(updateDirName+ '/' + currentScriptName, currentScriptName)
       except Exception as e:
            print(e)
       finally:
            return status

    @staticmethod
    def DeleteAndDownloadUpdateProgramFiles(updateDirName, configDirName, drAdminConfigFileName):
        try:
            FTPSync.ClearADirectory(updateDirName)
            cData1 = XMLReader.ReadAdminConfigFile(configDirName + "/" + drAdminConfigFileName)
            if (len(cData1) > 0):
                ftpHost = cData1.get('FTP_Host')
                ftpUser = cData1.get('FTP_User')
                ftpPass = cData1.get('FTP_Pass')
                ftpAdminConfig = cData1.get('FTP_DrUpdateDir')

                ###---------Download all files from remote directory
                try:
                    isErrorFound = False
                    ftp = FTPSync.getFTPConnection(ftpHost, ftpUser, ftpPass, ftpAdminConfig)
                    files = []
                    files = FTPSync.getListofFile(ftp)
                    if (files.count > 0):
                        for f in files:
                            try:
                                FTPSync.downloadFile(f, updateDirName, ftp)
                            except Exception as e:
                                print(e)
                    ftp.quit()
                except Exception as e:
                    print(e)
                    isErrorFound = True
                finally:
                    if (isErrorFound):
                        try:
                            isErrorFound = False
                            ftpHost1 = cData1.get('FTP1_Host')
                            ftpUser1 = cData1.get('FTP1_User')
                            ftpPass1 = cData1.get('FTP1_Pass')
                        
                            ftp1 = FTPSync.getFTPConnection(ftpHost1, ftpUser1, ftpPass1, ftpAdminConfig)
                            files = []
                            files = FTPSync.getListofFile(ftp1)
                            if (files.count > 0):
                                for f in files:
                                    try:
                                        FTPSync.downloadFile(f, updateDirName, ftp1)
                                    except Exception as e:
                                        print(e)
                            ftp1.quit()
                        except Exception as e:
                            print(e)
                            isErrorFound = True
                            tkMessageBox.showinfo("Download-Program", "Their is an error, Please try again")    
        except Exception as e:
            print(e)        


def CheckUpdateVersionStatus():
    try:
        #Initialize Section
        CheckVersionNumber.DeleteAndDownloadUpdateProgramFiles(updateDirName, configDirName, drAdminConfigFileName)
        arrProg = updateFileNames.split('~')
        if (len(arrProg) > 0):
            for m in range(len(arrProg)):
                try:
                    status = False
                    status = CheckVersionNumber.CheckVersion(updateDirName, arrProg[m], arrProg[m])
                    print "status=" + str(status)
                    if (status):
                        os.unlink(arrProg[m])
                        shutil.copy2(updateDirName+ '/' + arrProg[m], arrProg[m])
                        print str(arrProg[m]) + " is Updated"
                except Exception as e:
                    print(e)
    except Exception as e:
        print(e)

#CheckUpdateVersionStatus()
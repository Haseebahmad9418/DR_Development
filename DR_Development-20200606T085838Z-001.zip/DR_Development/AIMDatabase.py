#!/usr/bin/env python
# coding: utf-8
__version__ = "2.5"
__Date__ = "20JAN2019"

import sqlite3
import time

def GetDbConnection():
    conn = sqlite3.connect('aimdr.db')
    return conn

#def CreateAllTable(cursor):    
#    cursor.execute('''CREATE TABLE if not exists store
#             (id int, uLang text, cuUser text, cuPass text, ftpHost text, ftpUser text, ftpPass text, ftpRmtDir text)''')


#def CheckRowExist(cursor):
#    cursor.execute('SELECT *  FROM store')
#    data=cursor.fetchall()

#def IntitializeStore(cursor):
#    cursor.execute("INSERT INTO stocks(id, uLang, cuUser, cuPass, ftpHost, ftpUser, ftpPass, ftpRmtDir) VALUES (1, 'English','admin','aiminv','www.aiminv.net','hasnat','aiminv','ACCDataFile/DRConfig')")


def CreateAllTable():
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE if not exists DrData
             (Id int NOT NULL DEFAULT '0', GroupId int NOT NULL DEFAULT '0', Location text NOT NULL, ScheduleCode text NOT NULL, Data1 text, Data2 text, Data3 text, Data4 text, Data5 text, Data6 text, Data7 text, Data8 text, Data9 text, Data10 text, Price text, Qty text, Flag text NOT NULL DEFAULT '0', EntryTime text, SyncTime text, Active int NOT NULL DEFAULT '1', DelTime text)''')

        cursor.execute('''CREATE TABLE if not exists DrMainHead
             (GroupId int NOT NULL DEFAULT '0', Location text NOT NULL, ScheduleCode text NOT NULL, DRId text, UserId text, Flag text NOT NULL DEFAULT '0', EntryTime text, SyncTime text)''')

        cursor.execute('''CREATE TABLE if not exists DrColumnHead
             (GroupId int NOT NULL DEFAULT '0', Location text NOT NULL, ScheduleCode text NOT NULL, DrColumnHead text, DrColumnCount int, Flag text NOT NULL DEFAULT '0', EntryTime text, SyncTime text)''')

        cursor.execute('''CREATE TABLE if not exists DrScannerInfo
             (MacNo text NOT NULL, MacValue text NOT NULL)''')

        cursor.execute('''CREATE TABLE if not exists DrLog
             (Log text NOT NULL, LogTime text)''')

        cursor.execute('''CREATE TABLE if not exists DrDbLookup
             (Barcode text NOT NULL, Description text)''')

        cursor.execute('''CREATE TABLE if not exists DrScheduleTrack
             (GroupId int NOT NULL DEFAULT '0', Location text NOT NULL, ScheduleCode text NOT NULL)''')

        try:
            cursor.execute('''ALTER TABLE DrData ADD COLUMN PrefixData text''')
        except Exception as e:
            print(e)

        try:
            cursor.execute('''ALTER TABLE DrData ADD COLUMN Closed int NOT NULL DEFAULT '0' ''')
        except Exception as e:
            print(e)

        try:
            cursor.execute('''ALTER TABLE DrDbLookup ADD COLUMN FlagTypes text NOT NULL DEFAULT '' ''')
        except Exception as e:
            print(e)
    except Exception as e:
        print(e)
    finally:
        conn.close()

def ExecuteAnyTable(tabName):
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "SELECT *  FROM " + tabName
        cursor.execute(sql)
        data = cursor.fetchall()
        print data
    except Exception as e:
        print(e)
    finally:
        conn.close()

###------------------- DRData Starts Here ---------------------------------------------------------------------------------
def Insert_DRData(id, groupId, location, scheduleCode, data1, data2, data3, data4, data5, data6, data7, data8, data9, data10, price, qty, flag, entryTime, prefixData):
    isInserted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "INSERT INTO DrData(Id, GroupId, Location, scheduleCode, Data1, Data2, Data3, Data4, Data5, Data6, Data7, Data8, Data9, Data10, Price, Qty, Flag, EntryTime, PrefixData) VALUES (" + id + "," + groupId + ",'"+ location + "','" + scheduleCode  + "','" + data1 + "','" + data2 + "','" + data3 + "','" + data4 + "','" + data5 + "','" + data6 + "','" + data7 + "','" + data8 + "','" + data9 + "','" + data10 + "','" + price + "','" + qty + "','" + flag  + "','" + entryTime + "','" + prefixData + "')"
        cursor.execute(sql)
        conn.commit()
        isInserted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isInserted

def Update_DRDataSyncStatus(groupId, location, scheduleCode, flag, syncTime):
    isUpdated = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "UPDATE DrData SET Flag='" + flag + "', SyncTime='" + syncTime + "' Where GroupId=" + groupId + " AND Location='" + location + "' AND Flag='0'"
        cursor.execute(sql)
        conn.commit()
        isUpdated = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isUpdated

def Delete_DRData(groupId, location, scheduleCode):
    isDeleted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM DrData Where GroupId=" + groupId + " AND Location='" + location + "' AND ScheduleCode='" + scheduleCode + "'"
        cursor.execute(sql)
        conn.commit()
        isDeleted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isDeleted

def Update_DRDataDeleteStatus(id, active, delTime):
    isUpdated = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "UPDATE DrData SET Active=" + active + ", DelTime='" + delTime + "' Where Id=" + id
        cursor.execute(sql)
        conn.commit()
        isUpdated = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isUpdated

def Select_DRDataByLocation(groupId, location, scheduleCode):
    try:
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT Location, Data1, Data2, Data3, Data4, Data5, Data6, Data7, Data8, Data9, Data10, Price, Qty, Active  FROM DrData Where GroupId=" + groupId + " AND Location='" + location + "' AND ScheduleCode='" + scheduleCode + "' AND Flag='0'"
        cursor.execute(sql)
        data = cursor.fetchall()
        return data
    except Exception as e:
        print(e)
    finally:
        conn.close()

def Select_DRDataById(groupId, location, id):
    try:
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT Location, Data1, Data2, Data3, Data4, Data5, Data6, Data7, Data8, Data9, Data10, Price, Qty  FROM DrData Where GroupId=" + groupId + " AND Location='" + location + "' AND ACTIVE=1 AND id=" + id
        cursor.execute(sql)
        data = cursor.fetchall()
        return data
    except Exception as e:
        print(e)
    finally:
        conn.close()

def GetMaxDataId():
    try:
        maxId = 0
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT MAX(id) as maxId FROM DrData"
        cursor.execute(sql)
        for row in cursor:
            maxId = int(row[0])
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return maxId

def GetMaxDataIdByLocation(groupId, location):
    try:
        maxId = 0
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT MAX(id) as maxId FROM DrData Where GroupId=" + groupId + " AND Location='" + location + "'"
        cursor.execute(sql)
        for row in cursor:
            maxId = int(row[0])
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return maxId

def GetTotalRecord(groupId, location):
    try:
        maxId = 0
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT Count(id) as countId FROM DrData Where ACTIVE=1 AND GroupId=" + groupId + " AND Location='" + location + "'"
        cursor.execute(sql)
        for row in cursor:
            maxId = int(row[0])
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return maxId

def GetPreviousMaxId(currentId, groupId, location):
    try:
        maxId = 1
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT Max(id) as maxId FROM DrData Where id <" + currentId + " AND ACTIVE=1 AND GroupId=" + groupId + " AND Location='" + location + "'"
        cursor.execute(sql)
        for row in cursor:
            maxId = int(row[0])
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return maxId

def GetNextMaxId(currentId, groupId, location):
    try:
        maxId = 1
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT Min(id) as minId FROM DrData Where id >" + currentId + " AND ACTIVE=1 AND GroupId=" + groupId + " AND Location='" + location + "'"
        cursor.execute(sql)
        for row in cursor:
            maxId = int(row[0])
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return maxId

def GetMaxCountId(currentId, groupId, location):
    try:
        maxId = 1
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "select Max(id) as maxId, (select count(*) from DrData b where a.id >= b.id and b.GroupId=" + groupId + " and b.Location='" + location + "' and b.Active=1 and id<=" + currentId + ") as rowNo from DrData as a  Where GroupId=" + groupId + " and Location='" + location + "' and Active=1 and id <=" + currentId
        cursor.execute(sql)
        for row in cursor:
            maxId = int(row[1])
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return maxId

def GetDrDataMaxId(groupId, location):
    try:
        maxId = 1
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT Max(id) as maxId FROM DrData Where ACTIVE=1 AND GroupId=" + groupId + " AND Location='" + location + "'"
        cursor.execute(sql)
        for row in cursor:
            maxId = int(row[0])
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return maxId

def GetDrDataMinId(groupId, location):
    try:
        maxId = 1
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT Min(id) as maxId FROM DrData Where ACTIVE=1 AND GroupId=" + groupId + " AND Location='" + location + "'"
        cursor.execute(sql)
        for row in cursor:
            maxId = int(row[0])
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return maxId


def GetMaxGroupId(scheduleCode):
    try:
        maxId = 0
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT MAX(GroupId) as maxId FROM DrData Where ScheduleCode='" + scheduleCode  + "'"
        cursor.execute(sql)
        for row in cursor:
            maxId = int(row[0])
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return maxId

def GetTableDataExist(tableName):
    try:        
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT ScheduleCode FROM " + tableName + " Group By ScheduleCode Order by ScheduleCode"
        cursor.execute(sql)
        data = cursor.fetchall()
        return data
    except Exception as e:
        print(e)
    finally:
        conn.close()

def GetTableDataByScheduleCode(tableName, scheduleCode):
    try:
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT ScheduleCode FROM " + tableName + " Where ScheduleCode='" + scheduleCode  + "'"
        cursor.execute(sql)
        data = cursor.fetchall()
        return data
    except Exception as e:
        print(e)
    finally:
        conn.close()

def Update_DRDataLocationClosed(groupId, location, scheduleCode):
    isUpdated = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "UPDATE DrData SET Closed=1 Where GroupId=" + groupId + " AND Location='" + location + "' AND ScheduleCode='" + scheduleCode  + "'"
        cursor.execute(sql)
        conn.commit()
        isUpdated = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isUpdated

def GetMaxGroupNotClosed(scheduleCode):
    try:
        maxId = 0
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT MAX(Id) as maxId FROM DrData Where ScheduleCode='" + scheduleCode  + "' AND Closed=0 AND Active=1"
        cursor.execute(sql)
        for row in cursor:
            maxId = int(row[0])
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return maxId

def Select_DRDataByNotClosedId(id):
    try:
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT GroupId, Location, Data1, Data2, Data3, Data4, Data5, Data6, Data7, Data8, Data9, Data10, Price, Qty  FROM DrData Where id=" + id + " AND Active=1"
        cursor.execute(sql)
        data = cursor.fetchall()
        return data
    except Exception as e:
        print(e)
    finally:
        conn.close()
###------------------- DRData Starts Here ---------------------------------------------------------------------------------


###------------------- DrMainHead Starts Here -----------------------------------------------------------------------------

def Insert_DrMainHead(groupId, location, scheduleCode, dRId, userId, flag, entryTime):
    isInserted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "INSERT INTO DrMainHead(GroupId, Location, ScheduleCode, DRId, UserId, Flag, EntryTime) VALUES (" + groupId + ",'" + location + "','" + scheduleCode + "','" + dRId + "','" + userId + "','" + flag + "','" + entryTime + "')"
        cursor.execute(sql)
        conn.commit()
        isInserted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isInserted

def Update_DrMainHeadSyncStatus(groupId, location, scheduleCode, flag, syncTime):
    isUpdated = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "UPDATE DrMainHead SET Flag='" + flag + "', SyncTime='" + syncTime + "' Where GroupId=" + groupId + " AND  Location='" + location + "' AND ScheduleCode='" + scheduleCode + "' AND Flag='0'"
        cursor.execute(sql)
        conn.commit()
        isUpdated = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isUpdated

def Delete_DrMainHead(groupId, location):
    isDeleted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM DrMainHead Where GroupId=" + groupId + " AND Location='" + location + "' AND Flag='0'"
        cursor.execute(sql)
        conn.commit()
        isDeleted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isDeleted

def Select_DrMainHeadByLocation(groupId, location, scheduleCode):
    try:
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT GroupId, ScheduleCode, EntryTime, DRId, UserId  FROM DrMainHead Where GroupId=" + groupId + " AND Location='" + location + "' AND ScheduleCode='" + scheduleCode + "' AND Flag='0' Order By GroupId, EntryTime "
        cursor.execute(sql)
        data = cursor.fetchall()
        return data
    except Exception as e:
        print(e)
    finally:
        conn.close()

def GetAllLocation():    
    try:        
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT DISTINCT GroupId, Location, ScheduleCode FROM DrMainHead Where Flag='0' Order By Location, GroupId, EntryTime"
        cursor.execute(sql)
        data = cursor.fetchall()
        return data
    except Exception as e:
        print(e)
    finally:
        conn.close()

def CloseOpenLocation():
    isUpdated = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "UPDATE DrData SET Closed=1 Where Closed=0"
        cursor.execute(sql)
        conn.commit()
        isUpdated = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isUpdated

def GetTotalLocationReadyForTransfer():
    try:
        maxId = 0
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT Count(GroupId) as countId FROM DrMainHead Where Flag='0'"
        cursor.execute(sql)
        for row in cursor:
            maxId = int(row[0])
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return maxId

def GetTotalLocation():
    try:
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT Count(GroupId), Location, ScheduleCode FROM DrMainHead Where Flag='0' Order By Location, GroupId, EntryTime"
        cursor.execute(sql)
        data = cursor.fetchall()
        return data
    except Exception as e:
        print(e)
    finally:
        conn.close()

def GetOpenedLocation():
    try:
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "select Max(Id), GroupId, Location, ScheduleCode From DrData Where Active=1 and Closed=0 and Flag=0"
        cursor.execute(sql)
        data = cursor.fetchall()
        return data
    except Exception as e:
        print(e)
    finally:
        conn.close()

def GetTotalLocationReadyForSync():
    try:
        totalLocation = 1
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT Count(GroupId) FROM DrMainHead Where Flag='0'"
        cursor.execute(sql)
        for row in cursor:
            totalLocation = int(row[0])
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return totalLocation

###------------------- DrMainHead Ends Here -----------------------------------------------------------------------------

###------------------- DrColumnHead Star Here -----------------------------------------------------------------------------
def Insert_DrColumnHead(groupId, location, scheduleCode, DrColumnHead, DrColumnCount, flag, entryTime):
    isInserted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "INSERT INTO DrColumnHead(GroupId, Location, ScheduleCode, DrColumnHead, DrColumnCount, Flag, EntryTime) VALUES (" + groupId + ",'" + location + "','" + scheduleCode + "','" + DrColumnHead + "'," + DrColumnCount + ",'" + flag + "','" + entryTime + "')"
        cursor.execute(sql)
        conn.commit()
        isInserted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isInserted

def Update_DrColumnHeadSyncStatus(groupId, location, scheduleCode, flag, syncTime):
    isUpdated = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "UPDATE DrColumnHead SET Flag='" + flag + "', SyncTime='" + syncTime + "' Where GroupId=" + groupId + " AND Location='" + location + "' AND ScheduleCode='" + scheduleCode  + "' AND Flag='0'"
        cursor.execute(sql)
        conn.commit()
        isUpdated = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isUpdated

def Delete_DrColumnHead(groupId, location):
    isDeleted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM DrColumnHead Where GroupId=" + groupId + " AND Location='" + location + "' AND Flag='0'"
        cursor.execute(sql)
        conn.commit()
        isDeleted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isDeleted

def Select_DrColumnHeadByLocation(groupId, location, scheduleCode):
    try:
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT DrColumnHead, DrColumnCount  FROM DrColumnHead Where GroupId=" + groupId + " AND Location='" + location + "' AND ScheduleCode='" + scheduleCode + "' AND Flag='0'"
        cursor.execute(sql)
        data = cursor.fetchall()
        return data
    except Exception as e:
        print(e)
    finally:
        conn.close()

###------------------- DrColumnHead Ends Here -----------------------------------------------------------------------------

###------------------- DrScheduleTrack Star Here -----------------------------------------------------------------------------
def Insert_DrScheduleTrack(groupId, location, scheduleCode):
    print "Insert_DrScheduleTrack"
    isInserted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        print "Insert_DrScheduleTrack 0" 
        sql = "INSERT INTO DrScheduleTrack(GroupId, Location, ScheduleCode) VALUES (" + groupId + ",'" + location + "','" + scheduleCode + "')"
        print "Insert_DrScheduleTrack 1"
        cursor.execute(sql)
        conn.commit()
        isInserted = True
    except Exception as e:
        print(e)
        print "Insert_DrScheduleTrack 3" 
    finally:
        conn.close()
        return isInserted

def Update_DrScheduleTrack(groupId, location, scheduleCode):
    isUpdated = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "UPDATE DrColumnHead SET GroupId=" + groupId + ", Location='" + location + "'  Where  ScheduleCode='" + scheduleCode + "'"
        cursor.execute(sql)
        conn.commit()
        isUpdated = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isUpdated

def Delete_DrScheduleTrack():
    isDeleted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM DrScheduleTrack"
        cursor.execute(sql)
        conn.commit()
        isDeleted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isDeleted

def GetScheduleGroupId(scheduleCode):
    try:
        groupId = 0
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT MAX(GroupId) as maxId FROM DrScheduleTrack Where ScheduleCode='" + scheduleCode  + "'"
        cursor.execute(sql)
        for row in cursor:
            groupId = int(row[0])
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return groupId

###------------------- DrScheduleTrack Ends Here -----------------------------------------------------------------------------

###------------------- DrScannerInfo Star Here -----------------------------------------------------------------------------
def Insert_DrScannerInfo(macNo, macValue):
    isInserted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "INSERT INTO DrScannerInfo(MacNo, MacValue) VALUES ('" + macNo + "','" + macValue + "')"
        cursor.execute(sql)
        conn.commit()
        isInserted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isInserted

def Update_DrScannerInfo(macNo, macValue):
    isUpdated = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "UPDATE DrScannerInfo SET MacNo='" + macNo + "', MacValue='" + macValue + "' Where MacValue='" + macNo + "'"
        cursor.execute(sql)
        conn.commit()
        isUpdated = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isUpdated

def Delete_DrScannerInfo(macNo):
    isDeleted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM DrScannerInfo Where MacNo='" + macNo + "'"
        cursor.execute(sql)
        conn.commit()
        isDeleted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isDeleted

def Clear_DrScannerInfo():
    isDeleted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM DrScannerInfo"
        cursor.execute(sql)
        conn.commit()
        isDeleted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isDeleted

def Select_DrScannerInfo():
    try:
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT macNo, macValue  FROM DrScannerInfo Order by macNo"
        cursor.execute(sql)
        data = cursor.fetchall()
        return data
    except Exception as e:
        print(e)
    finally:
        conn.close()

def GetRegistrerScannerId():
    scannerid = '0'
    try:
        cursorDrScanner = Select_DrScannerInfo()
        for drScannerInfo in cursorDrScanner:
            scannerid = drScannerInfo[1]
            print "scannerid=" + scannerid.strip()
    except Exception as e:
        print(e)
        AIMDatabase.Insert_DrLog("19." + e.message)
    finally:
        return scannerid
###------------------- DrScannerInfo Ends Here -----------------------------------------------------------------------------

###------------------- DrLog Star Here -------------------------------------------------------------------------------------
def Insert_DrLog(message):
    isInserted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "INSERT INTO DrLog(Log, LogTime) VALUES ('" + message + "','" + str(time.strftime("%d-%m-%Y %H:%M:%S")) + "')"
        cursor.execute(sql)
        conn.commit()
        isInserted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isInserted

def Reset_DrLog():
    isDeleted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM DrLog "
        cursor.execute(sql)
        conn.commit()
        isDeleted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isDeleted
###------------------- DrLog Ends Here -----------------------------------------------------------------------------

###------------------- DrDbLookup Star Here -------------------------------------------------------------------------------------
def Insert_DrDbLookup(spamreader):
    isInserted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        firstline = True
        for row in spamreader:
            try:
                if firstline:
                    firstline = False
                else:
                    #count = count + 1
                    #print str(count) + ". " + row[0]
                    sql = "INSERT INTO DrDbLookup(FlagTypes, Barcode, Description) VALUES ('" + str(row[0]).strip() + "','" + str(row[1]).strip() + "','" + str(row[2]).replace("'","\"") + "')"
                    cursor.execute(sql)
            except Exception as e:
                print(e)
        isInserted = True
    except Exception as e:
        print(e)
    finally:
        conn.commit()
        conn.close()
        return isInserted

def Reset_DrDbLookup():
    isDeleted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM DrDbLookup "
        cursor.execute(sql)
        conn.commit()
        isDeleted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isDeleted

def CheckDbLookUp(barcode, flgTypes):
    try:
        totalFound = 0
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT Count(Barcode) FROM DrDbLookup Where Barcode='" + barcode + "' AND FlagTypes='" + flgTypes + "'"
        cursor.execute(sql)
        for row in cursor:
            totalFound = int(row[0])
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return totalFound

def GetDbLookUpDescription(barcode, flgTypes):
    try:
        description = ''
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT Description FROM DrDbLookup Where Barcode='" + barcode + "' AND FlagTypes='" + flgTypes + "'"
        cursor.execute(sql)
        for row in cursor:
            description = str(row[0])
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return description
###------------------- DrDbLookup Ends Here -----------------------------------------------------------------------------

###------------------- Dr Report Functionality Star Here ----------------------------------------------------------------
def GetGTReportTotal(scheduleCode):
    try:
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "Select SUM(price * qty) as TotalPrice, SUM(qty) as TotalQty from DrData where schedulecode='" + scheduleCode + "' AND Active=1"
        cursor.execute(sql)
        data = cursor.fetchall()
        return data
    except Exception as e:
        print(e)
    finally:
        conn.close()

def GetGTReportData(scheduleCode, colName, grpFld, condition):
    try:
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT " + colName + " FROM DrData Where " +  condition + " group by " + grpFld + " order by GroupId"
        cursor.execute(sql)
        data = cursor.fetchall()
        return data
    except Exception as e:
        print(e)
    finally:
        conn.close()

def GetReportData(groupId, scheduleCode, colName, grpFld, condition):
    try:
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT " + colName + " FROM DrData Where " +  condition + " AND GroupId=" + groupId + " group by " + grpFld
        cursor.execute(sql)
        data = cursor.fetchall()
        return data
    except Exception as e:
        print(e)
    finally:
        conn.close()

def GetReviewReportData(scheduleCode, colName, grpFld, condition):
    try:
        conn = GetDbConnection()
        cursor = conn.cursor()
        sql = "SELECT " + colName + " FROM DrData Where " +  condition + " group by " + grpFld + " Order by GroupId"
        cursor.execute(sql)
        data = cursor.fetchall()
        return data
    except Exception as e:
        print(e)
    finally:
        conn.close()
###------------------- Dr Report Functionality End Here ----------------------------------------------------------------


def ResetDRTables():
    isDeleted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM DrData"
        cursor.execute(sql)
        conn.commit()
        sql1 = "DELETE FROM DrMainHead"
        cursor.execute(sql1)
        conn.commit()
        sql2 = "DELETE FROM DrColumnHead"
        cursor.execute(sql2)
        conn.commit()
        sql3 = "DELETE FROM DrDbLookup"
        cursor.execute(sql3)
        conn.commit()
        sql4 = "DELETE FROM DrScannerInfo"
        cursor.execute(sql4)
        conn.commit()
        sql5 = "DELETE FROM DrScheduleTrack"
        cursor.execute(sql5)
        conn.commit()
        isDeleted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isDeleted

def ResetDRBasicTables():
    isDeleted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM DrData"
        cursor.execute(sql)
        conn.commit()
        sql1 = "DELETE FROM DrMainHead"
        cursor.execute(sql1)
        conn.commit()
        sql2 = "DELETE FROM DrColumnHead"
        cursor.execute(sql2)
        conn.commit()
        sql5 = "DELETE FROM DrScheduleTrack"
        cursor.execute(sql5)
        conn.commit()
        isDeleted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isDeleted

def DeleteDRTransferTables():
    isDeleted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM DrData"
        cursor.execute(sql)
        conn.commit()
        sql1 = "DELETE FROM DrMainHead"
        cursor.execute(sql1)
        conn.commit()
        sql2 = "DELETE FROM DrColumnHead"
        cursor.execute(sql2)
        conn.commit()       
        isDeleted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isDeleted

def ResetDRTablesByTableName(tableName):
    isDeleted = False
    conn = GetDbConnection()
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM " + tableName
        cursor.execute(sql)
        conn.commit()        
        isDeleted = True
    except Exception as e:
        print(e)
    finally:
        conn.close()
        return isDeleted
    

if __name__ == '__main__':
    CreateAllTable()
#!/usr/bin/env python
# coding: utf-8
__version__ = "1.8"
__Date__ = "13JAN2019"

import logging
import socket
import time
from configfile import *

def WriteToLog(comments):
    if (IsLogging):
        try:
            now = time.time()
            struct_now = time.localtime(now)
            mlsec = repr(now).split('.')[1][:3]
            logData = " " + socket.gethostname() + " : " + str(time.strftime("%d-%m-%Y %H:%M:%S.{} %Z".format(mlsec), struct_now)) + " :  " + __file__ + " :  " + comments
            logging.debug(logData)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

LOG_FILENAME = 'aimdr.log'
logging.basicConfig(filename=LOG_FILENAME,level=logging.DEBUG)
WriteToLog('First Line Started')

try:
    from Tkinter import *   ## notice capitalized T in Tkinter
    import Tkinter as tk
    import pickle
    import os
    import threading
    from threading import Thread
    import DR_Key_GPIO as gpio
    import sys
    import FTPSync
    import XMLReader
    from AIMManualSync import *
    import tkMessageBox
except Exception as e:
    exc_type, exc_obj, exc_tb = sys.exc_info()
    logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

def center(toplevel):
    toplevel.update_idletasks()
    w = toplevel.winfo_screenwidth()
    h = toplevel.winfo_screenheight()
    size = tuple(int(_) for _ in toplevel.geometry().split('+')[0].split('x'))
    x = w/2 - size[0]/2
    y = h/2 - size[1]/2
    toplevel.geometry("%dx%d+%d+%d" % (size + (x, y)))

AimSyncPopup = tk.Tk()
AimSyncPopup.title("Syncing Confirmation")
AimSyncPopup.resizable(0, 0)
w, h = 400, 150
AimSyncPopup.geometry("%dx%d+0+0" % (w, h))
center(AimSyncPopup)
#AimSyncPopup.iconbitmap(iconPath)

#-------- Global Variable Start Here-----------------------------------------------------------------------------
fontName = "Helvetica"
fontSize = 16

lblReadyText = StringVar()
lblOKText = StringVar()
lblCancelText = StringVar()
lblSyncText = StringVar()
cData = {}
downloadCode = ''
isScheduleStarted = False
isProcessing = False
isFtpWorking = False
####------------- FTP Information------------------------------------------------------------------------------------
ftpHost = ''
ftpUser = ''
ftpPass = ''
#-------- Global Variable Ends Here---------------------------------------------------------------------------------

class ReadXMLData():
    @staticmethod
    def ReadAdminConfigData():
        WriteToLog('ReadAdminConfigData Function Starts')
        global ftpHost, ftpPass, ftpUser
       
        try:
            cData = XMLReader.ReadAdminConfigData()
            if (len(cData) > 0):
                ftpHost = cData.get('FTP_Host')
                ftpUser = cData.get('FTP_User')
                ftpPass = cData.get('FTP_Pass')
                print "ftpHost=" + ftpHost                
                print "ftpUser=" + ftpUser
                print "ftpPass=" + ftpPass
        except Exception as e:
           exc_type, exc_obj, exc_tb = sys.exc_info()
           logging.debug(str(exc_tb.tb_lineno) + " " + e.message)


    @staticmethod
    def ReadConfigData():
        global cData, downloadCode
        try:
            cData = XMLReader.ReadDRConfigData()
            if (len(cData) > 0):
                downloadCode = cData.get('DownloadCode')
                print("downloadCode=" + downloadCode)
        except Exception as e:
           exc_type, exc_obj, exc_tb = sys.exc_info()
           logging.debug(str(exc_tb.tb_lineno) + " " + e.message)

####---------------------- GPIO Starts ----------------------------------------------------------------------------------------
def select(value):
    try:
        print value        
        if value == "ESC":
            submitCancel()
        elif value == "F2":            
            submitOK()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
####---------------------- GPIO Ends ----------------------------------------------------------------------------------------

frameSync = Frame(AimSyncPopup, pady=5)
frameSync.pack()

frame1 = Frame(AimSyncPopup, pady=5)
frame1.pack()

lblReadyText.set("Transmit?")
lblReady = Label(frame1, textvariable =lblReadyText, font=(fontName, fontSize))
lblReady.pack()

frameButton = Frame(AimSyncPopup, pady=5)
frameButton.pack()

def submitOK():
    global isProcessing, DROutUnique_Id
    if (isProcessing == False):
        isProcessing = True
        try:
            CheckScheduleStarted()
            if (isFtpWorking):
                if (isScheduleStarted):
                    print "Test by Hasnat"
                    #AIMDatabase.CloseOpenLocation()
                    CloseOpenLocation()
                    #if (AIMDatabase.GetTotalLocationReadyForTransfer() > 0):
                    isDone = SyncService.SyncData()
                    if (isDone == "DONE" or isDone == ""):
                        DROutUnique_Id = DROutUnique_Id + 1
                        isProcessing = False
                        submitCancel()
                    else:
                        tkMessageBox.showinfo("Sync Error", isDone)
                    #else:
                        #tkMessageBox.showinfo("Sync Error", "Their is no close location for data trasnsfer")
                else:
                    tkMessageBox.showinfo("Sync Error", "Please start your schedule from base station")
            else:
                tkMessageBox.showinfo("Sync Error", "FTP not working properly, please contact administrator")
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        finally:
            isProcessing = False
         
def submitCancel():
   if (isProcessing == False):
        AimSyncPopup.destroy()

def CloseOpenLocation():
    print "CloseOpenLocation Called"
    print "Group Id=" + str(DROutUnique_Id)
    print "aimLocation=" + aimLocation
    print "ScheduleCode=" + ScheduleCode

    isDataFound =False, isMainHeadFound = False, isColumnHeadFound = False    
    try:
        cursorHead = AIMDatabase.GetOpenedLocation()
        for drDataHead in cursorHead:
            if (drDataHead[1].strip() !=''):
                print "CloseOpenLocation1 " + str(drDataHead[1])
                isDataFound = True
                cursorDrMainHead = AIMDatabase.Select_DrMainHeadByLocation(str(DROutUnique_Id), aimLocation, ScheduleCode)
                for drMainHead in cursorDrMainHead:
                    if (drMainHead[1] !=''):
                        print "CloseOpenLocation2 " + str(drMainHead[1])
                        isMainHeadFound = True
                cursorDrColumnHead = AIMDatabase.Select_DrColumnHeadByLocation(str(DROutUnique_Id), aimLocation, ScheduleCode)
                for drColumnHead in cursorDrColumnHead:            
                    if (drColumnHead[1] !=''):
                        print "CloseOpenLocation3 " + str(drColumnHead[1])
                        isColumnHeadFound = True
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    finally:
        dateTimes = str(time.strftime("%d-%m-%Y %H:%M:%S"))
        if (isMainHeadFound):
            AIMDatabase.Insert_DrMainHead(str(DROutUnique_Id), aimLocation, ScheduleCode, str(DRId), UserId, '0', dateTimes) 
        if (isColumnHeadFound):
            AIMDatabase.Insert_DrColumnHead(str(DROutUnique_Id), aimLocation, ScheduleCode, aimCSVHeader, str(totDataCount), '0', dateTimes)
        if (isDataFound):
            AIMDatabase.Update_DRDataLocationClosed(str(DROutUnique_Id), aimLocation, ScheduleCode)       


lblCancelText.set("Cancel")
btnCancel = Button(frameButton, textvariable =lblCancelText, width=12, font=(fontName, fontSize), command = submitCancel) 
btnCancel.bind("<Return>", lambda event:submitCancel())
btnCancel.pack(side = LEFT)

lblOKText.set("Confirm")
btnOK = Button(frameButton, textvariable =lblOKText, width=12, font=(fontName, fontSize), command = submitOK) 
btnOK.bind("<Return>", lambda event:submitOK())
btnOK.pack(side = RIGHT)

#----------------------------------------------------GPIO-----------------------------------------------------------------------
def ping():
    try:
        while 1:
            time.sleep(0.06)
            AimSyncPopup.event_generate('<<Ping>>', when='tail')
    except:
        pass

def gotPing(event):
    gpiovalue = gpio.get_keypad_value()
    try:
        if (gpiovalue.strip() !=''):
            select(gpiovalue)
    except:
        pass

AimSyncPopup.bind('<<Ping>>', gotPing)
th = threading.Thread(target=ping)
th.setDaemon(1)
th.start()
#------------------------------------------------------GPIO---------------------------------------------------------------------

def CheckScheduleStarted():
    print "FTP Checking"
    global isScheduleStarted, isFtpWorking
    isScheduleStarted = False
    isFtpWorking = False
    try:                 
        countFile = 0
        ftp = FTPSync.getFTPConnection(ftpHost, ftpUser, ftpPass, statusDirName)
        if (ftp !=None):
            isFtpWorking = True
            Ftpfiles = []
            Ftpfiles = FTPSync.getListofFile(ftp)
            for f in Ftpfiles:
                countFile= countFile + 1
                try:
                    if os.path.isfile(statusDirName + f):
                        os.unlink(statusDirName + f)
                    FTPSync.downloadFile(f, statusDirName, ftp)
                except Exception as e:
                    print(e)
            print "countFile=" + str(countFile)
            ftp.quit()
        
            timeFileSource = statusDirName + drStatusConfigFileName
            if os.path.isfile(timeFileSource):
                try:
                    file = open(timeFileSource, "r") 
                    bsDate = file.read() 
                    if (bsDate.strip() !=''):
                        if (bsDate.strip() == downloadCode.strip()):
                            isScheduleStarted = True
                            print "isScheduleStarted=" + str(isScheduleStarted)
                except Exception as e:
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        logging.debug(str(exc_tb.tb_lineno) + " " + e.message)
        
ReadXMLData.ReadAdminConfigData()
ReadXMLData.ReadConfigData()
AimSyncPopup.mainloop()
#!/usr/bin/env python
# coding: utf-8
import RPi.GPIO as GPIO
import time
import XMLReader

__version__ = "1.3"
__Date__ = "25MAR2018"

goodSound = "400,0.1,600,0.1,300,0.2"
badSound = "1047,0.1,988,0.1,659,0.2"
badArray = []
goodArray = []

class Buzzer(object):
 def __init__(self):
  GPIO.setmode(GPIO.BCM)
  GPIO.setwarnings(False)
  #self.buzzer_pin = 18 #This is used for wav file
  self.buzzer_pin = 12
  GPIO.setup(self.buzzer_pin, GPIO.IN)
  GPIO.setup(self.buzzer_pin, GPIO.OUT)
  print("buzzer ready")
  global goodSound, badSound, goodArray, badArray
  try:
    cData = XMLReader.ReadAdminConfigData()
    if (len(cData) > 0):
        goodSound = cData.get('GoodSoundPitch')
        badSound = cData.get('BadSoundPitch')
        
    goodArray = goodSound.split(',')
    badArray = badSound.split(',')        
    print "goodSound=" + goodSound
    print "badSound=" + badSound
  except Exception as e:
        print 'Exception: {}'.format(e)

 def __del__(self):
  class_name = self.__class__.__name__
  print (class_name, "finished")

 def buzz(self,pitch, duration):
  if(pitch==0):
   time.sleep(duration)
   return
  period = 1.0 / pitch
  delay = period / 2 
  cycles = int(duration * pitch)

  for i in range(cycles):
   GPIO.output(self.buzzer_pin, True)
   time.sleep(delay)
   GPIO.output(self.buzzer_pin, False)
   time.sleep(delay)

 def play(self, tune):
  GPIO.setmode(GPIO.BCM)
  GPIO.setup(self.buzzer_pin, GPIO.OUT)
  x=0

  #print("Playing tune ",tune)
  if(tune==1):
    pitches=[2000,2000,2000,2000,2000,2000,2000]
    duration=10
    for p in pitches:
      self.buzz(p, duration)
      time.sleep(duration *0.5)
    for p in reversed(pitches):
      self.buzz(p, duration)
      time.sleep(duration *0.5)

  elif(tune==2):
    pitches=[262,330,392,523,1047]
    duration=[0.2,0.2,0.2,0.2,0.2,0,5]
    for p in pitches:
      self.buzz(p, duration[x])
      time.sleep(duration[x] *0.5)
      x+=1
  elif(tune==3):
    mysound.play()  
    pitches=[392,294,0,392,294,0,392,0,392,392,392,0,1047,262]
    duration=[0.2,0.2,0.2,0.2,0.2,0.2,0.1,0.1,0.1,0.1,0.1,0.1,0.8,0.4]
    for p in pitches:
      self.buzz(p, duration[x])
      time.sleep(duration[x] *0.5)
      x+=1
    mysound.stop

  elif(tune==4):    
    for p in range(len(badArray)):
        if p % 2 == 0:
            self.buzz(float(badArray[p]), float(badArray[p+1]))
            time.sleep(float(badArray[p+1]) *0.5)
    
    #pitches=[1047, 988,659]
    #duration=[0.1,0.1,0.2]
    #for p in pitches:
    #  self.buzz(p, duration[x])
    #  time.sleep(duration[x] *0.5)
    #  x+=1

  elif(tune==5):
    for p in range(len(goodArray)):
        if p % 2 == 0:
            self.buzz(float(goodArray[p]), float(goodArray[p+1]))
            time.sleep(float(goodArray[p+1]) *0.5)

    #pitches=[400,600,300]
    #duration=[0.1,0.1,0.2]
    #for p in pitches:
    #  self.buzz(p, duration[x])
    #  time.sleep(duration[x] *0.5)
    #  x+=1

  #GPIO.setup(self.buzzer_pin, GPIO.IN)

#try:
#    buzzer = Buzzer()
#    buzzer.play(5)
#    #buzzer.play(4)
#finally:
#    GPIO.cleanup()
import os
import RPi.GPIO as GPIO
import time
import sysv_ipc
#
# Set GPIO mode
GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)

# Set second_key for Keypad
SECOND_KEY_PIN = 4
SECOND_KEY_VALUE = 0
FLAG_KEY = 1

# Get the value of keypad.
def get_first_keypad_value():
    for i in range(5):
        for j in range(3):
            INPUT[i][j] = GPIO.input(PIN[i][j])
            if (not PREV_INPUT[i][j]) and INPUT[i][j]:
                if MATRIX_FIRST[i][j] == '2nd':
                    print MATRIX_FIRST[i][j]
                    pass

                else:
                    # print MATRIX_FIRST[i][j]
                    mq.send(str(MATRIX_FIRST[i][j]))
            PREV_INPUT[i][j] = INPUT[i][j]


# Get the value of keypad about second key
def get_second_keypad_value():
    for i in range(5):
        for j in range(3):
            INPUT[i][j] = GPIO.input(PIN[i][j])
            if (not PREV_INPUT[i][j]) and INPUT[i][j]:
                if MATRIX_SECOND[i][j] == '2nd':
                    print MATRIX_FIRST[i][j]
                    pass
                else:
                    # print MATRIX_SECOND[i][j]
                    mq.send(str(MATRIX_SECOND[i][j]))
            PREV_INPUT[i][j] = INPUT[i][j]


# Detect the second key.
def detect_second_key(*args):
    global FLAG_KEY
    global SECOND_KEY_VALUE
    FLAG_KEY += 1
    if (FLAG_KEY % 2) == 0:
        SECOND_KEY_VALUE = 0
    else:
        SECOND_KEY_VALUE = 1


# Get the value for Keypad.
def get_keypad_value():
    try:
        while(True):
            if SECOND_KEY_VALUE == 1:
                get_second_keypad_value()
                time.sleep(0.05)
            else:
                get_first_keypad_value()
                time.sleep(0.05)
    except KeyboardInterrupt:
            GPIO.cleanup()

# Main
if __name__ == '__main__':
    # Set Messagequeue
    GPIO.add_event_detect(SECOND_KEY_PIN, GPIO.RISING, callback=detect_second_key)
    get_keypad_value()

